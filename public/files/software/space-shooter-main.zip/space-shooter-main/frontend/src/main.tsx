// 【前端入口文件】- React 应用的启动点
import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';
import './assets/styles.css';

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);