from flask import Flask, render_template, jsonify, request
import pandas as pd
import os
from datetime import datetime
from quant_monitor import QuantMonitor

app = Flask(__name__)

# ======================================
# 配置区 - 请修改你的Token
# ======================================
TOKEN = "your_token_here"  # 请替换为你的实际Token
STOCK_CSV_PATH = 'data/stock_basic_list.csv'

# 全局监控器实例
monitor = QuantMonitor(token=TOKEN, interval=2)  # 抓取间隔2秒


# ======================================
# 路由定义
# ======================================

@app.route('/')
def index():
    """主页"""
    return render_template('index.html')


@app.route('/real_time')
def real_time():
    """实时监控配置页"""
    return render_template('real_time.html')


@app.route('/api/stocks', methods=['GET'])
def get_stocks():
    """
    获取股票列表API
    返回格式: [{"id": "600000.SH", "text": "600000.SH - 浦发银行"}, ...]
    """
    try:
        # 使用 utf-8-sig 处理 BOM
        df = pd.read_csv(STOCK_CSV_PATH, encoding='utf-8-sig')
        
        # 构造Select2需要的数据格式
        stocks = []
        for _, row in df.iterrows():
            stocks.append({
                'id': row['ts_code'],
                'text': f"{row['ts_code']} - {row['name']}"
            })
        
        return jsonify({
            'status': 'success',
            'data': stocks
        })
    except Exception as e:
        return jsonify({
            'status': 'error',
            'message': f'读取股票列表失败: {str(e)}'
        }), 500


@app.route('/api/run', methods=['POST'])
def run_monitor():
    """
    启动监控API
    请求体: {"stocks": ["600000.SH", "000001.SZ"], "date": "20260202"}
    """
    try:
        data = request.get_json()
        stocks = data.get('stocks', [])
        date = data.get('date', '')
        
        # 参数验证
        if not stocks:
            return jsonify({
                'status': 'error',
                'message': '请至少选择一只股票'
            }), 400
        
        if not date:
            return jsonify({
                'status': 'error',
                'message': '请选择监控日期'
            }), 400
        
        # 启动监控（在守护线程中，立即返回）
        result = monitor.start(stocks, date)
        
        return jsonify(result)
    
    except Exception as e:
        return jsonify({
            'status': 'error',
            'message': f'启动失败: {str(e)}'
        }), 500


@app.route('/api/stop', methods=['POST'])
def stop_monitor():
    """停止监控API"""
    try:
        result = monitor.stop()
        return jsonify(result)
    except Exception as e:
        return jsonify({
            'status': 'error',
            'message': f'停止失败: {str(e)}'
        }), 500


@app.route('/api/status', methods=['GET'])
def get_status():
    """获取监控状态API"""
    try:
        status = monitor.get_status()
        return jsonify({
            'status': 'success',
            'data': status
        })
    except Exception as e:
        return jsonify({
            'status': 'error',
            'message': f'获取状态失败: {str(e)}'
        }), 500


# ======================================
# 主程序入口
# ======================================

if __name__ == '__main__':
    # 确保data目录存在
    os.makedirs('data', exist_ok=True)
    
    print("""
    ╔═══════════════════════════════════════╗
    ║   🚀 My Quant Web - 量化监控系统    ║
    ╠═══════════════════════════════════════╣
    ║   访问地址: http://127.0.0.1:5000   ║
    ║   作者: Wise XiaoXu        ║
    ╚═══════════════════════════════════════╝
    """)
    
    # 启动Flask应用
    # debug=True: 开发模式，代码修改自动重启
    # threaded=True: 支持多线程，处理并发请求
    app.run(debug=True, host='0.0.0.0', port=5000, threaded=True)
