import time
import sqlite3
import pandas as pd
import tushare as ts
from datetime import datetime, timedelta, timezone
import threading


class QuantMonitor:
    """量化监控核心类 - 封装Tushare实时行情监控逻辑"""
    
    # 数据库白名单字段
    DB_COLUMNS = [
        'ts_code', 'name', 'date', 'time', 'open', 'pre_close', 'price',
        'high', 'low', 'bid', 'ask', 'volume', 'amount',
        'b1_v', 'b1_p', 'b2_v', 'b2_p', 'b3_v', 'b3_p', 'b4_v', 'b4_p', 'b5_v', 'b5_p',
        'a1_v', 'a1_p', 'a2_v', 'a2_p', 'a3_v', 'a3_p', 'a4_v', 'a4_p', 'a5_v', 'a5_p',
        'record_time'
    ]
    
    def __init__(self, token, interval=2):
        """
        初始化监控器
        :param token: Tushare API Token
        :param interval: 采集间隔(秒)，默认2秒
        """
        self.token = token
        self.interval = interval
        self.is_running = False
        self.thread = None
        self.stock_codes = None
        self.date = None
        self.db_name = None
        self.table_name = 'realtime_quotes'
        self.last_recorded_time = {}
        
        # 设置Tushare Token
        ts.set_token(self.token)
    
    def start(self, stock_list, date):
        """
        启动监控
        :param stock_list: 股票代码列表 ['600000.SH', '000001.SZ']
        :param date: 监控日期 'YYYYMMDD'
        """
        if self.is_running:
            return {"status": "error", "message": "监控已在运行中"}
        
        self.stock_codes = ','.join(stock_list)
        self.date = date
        self.db_name = f'market_data_{date}.db'
        self.is_running = True
        
        # 初始化数据库
        self._init_db()
        self._init_cache()
        
        # 在守护线程中运行
        self.thread = threading.Thread(target=self._run_loop, daemon=True)
        self.thread.start()
        
        return {
            "status": "success", 
            "message": f"监控已启动，监控 {len(stock_list)} 只股票",
            "db_name": self.db_name
        }
    
    def stop(self):
        """停止监控"""
        if not self.is_running:
            return {"status": "error", "message": "监控未运行"}
        
        self.is_running = False
        if self.thread:
            self.thread.join(timeout=5)
        
        return {"status": "success", "message": "监控已停止"}
    
    def get_status(self):
        """获取运行状态"""
        return {
            "is_running": self.is_running,
            "stock_codes": self.stock_codes,
            "date": self.date,
            "db_name": self.db_name,
            "monitored_stocks": len(self.last_recorded_time)
        }
    
    def _init_db(self):
        """初始化数据库"""
        conn = sqlite3.connect(self.db_name)
        cursor = conn.cursor()
        cursor.execute(f'''
            CREATE TABLE IF NOT EXISTS {self.table_name} (
                ts_code TEXT, name TEXT, date TEXT, time TEXT,
                open REAL, pre_close REAL, price REAL, high REAL, low REAL,
                bid REAL, ask REAL, volume INTEGER, amount REAL,
                b1_v REAL, b1_p REAL, b2_v REAL, b2_p REAL,
                b3_v REAL, b3_p REAL, b4_v REAL, b4_p REAL,
                b5_v REAL, b5_p REAL,
                a1_v REAL, a1_p REAL, a2_v REAL, a2_p REAL,
                a3_v REAL, a3_p REAL, a4_v REAL, a4_p REAL,
                a5_v REAL, a5_p REAL,
                record_time DATETIME
            )
        ''')
        cursor.execute(f'CREATE INDEX IF NOT EXISTS idx_code_time ON {self.table_name} (ts_code, time)')
        conn.commit()
        conn.close()
        print(f"✅ 数据库初始化完成: {self.db_name}")
    
    def _init_cache(self):
        """从数据库加载最后一条记录的时间，防止重复写入"""
        conn = sqlite3.connect(self.db_name)
        try:
            sql = f"SELECT ts_code, MAX(time) as last_t FROM {self.table_name} GROUP BY ts_code"
            df_last = pd.read_sql(sql, conn)
            if not df_last.empty:
                self.last_recorded_time = dict(zip(df_last['ts_code'], df_last['last_t']))
                print(f"📦 缓存已恢复，当前监控: {len(self.last_recorded_time)} 只股票")
        except Exception as e:
            print(f"ℹ️ 提示: 数据库尚无历史记录，将开始全新录入。")
        finally:
            conn.close()
    
    def _run_once(self):
        """执行一次数据采集"""
        try:
            df = ts.realtime_quote(ts_code=self.stock_codes)
            
            if df is not None and not df.empty:
                # 🔥 关键修复：将 Tushare 返回的大写列名统一转为小写
                df.columns = [col.lower() for col in df.columns]
                
                new_rows = []
                now_str = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                
                for _, row in df.iterrows():
                    symbol = row.get('ts_code')
                    raw_time_val = row.get('time')
                    
                    if raw_time_val is None:
                        continue
                    
                    raw_time = str(raw_time_val).strip()
                    
                    # 格式化时间 (例如 143000 -> 14:30:00)
                    if len(raw_time) == 6 and ':' not in raw_time:
                        tick_time = f"{raw_time[:2]}:{raw_time[2:4]}:{raw_time[4:]}"
                    else:
                        tick_time = raw_time.zfill(8) if len(raw_time) < 8 else raw_time
                    
                    # 增量判断：仅当时间戳大于最后记录时才写入
                    if symbol not in self.last_recorded_time or tick_time > self.last_recorded_time[symbol]:
                        data_dict = row.to_dict()
                        data_dict['record_time'] = now_str
                        data_dict['time'] = tick_time
                        new_rows.append(data_dict)
                        self.last_recorded_time[symbol] = tick_time
                
                if new_rows:
                    new_df = pd.DataFrame(new_rows)
                    
                    # 白名单过滤：补全缺失列，剔除冗余列
                    for col in self.DB_COLUMNS:
                        if col not in new_df.columns:
                            new_df[col] = None
                    
                    final_df = new_df[self.DB_COLUMNS]
                    
                    conn = sqlite3.connect(self.db_name)
                    try:
                        final_df.to_sql(self.table_name, conn, if_exists='append', index=False)
                        print(f"[{datetime.now().strftime('%H:%M:%S')}] ✅ 成功入库 {len(final_df)} 条数据")
                    except Exception as e:
                        print(f"❌ 数据库写入错误: {e}")
                    finally:
                        conn.close()
                else:
                    print(f"[{datetime.now().strftime('%H:%M:%S')}] 😴 暂无新 Tick 数据...", end='\r')
            else:
                print(f"⚠️ 警告: 接口未返回任何数据")
        except Exception as e:
            print(f"❌ 运行异常: {e}")
    
    def _run_loop(self):
        """主循环 - 在后台线程中运行"""
        beijing_tz = timezone(timedelta(hours=8))
        print("-" * 50)
        print(f"🚀 监控系统启动 | 目标库: {self.db_name}")
        print(f"📈 监控列表: {self.stock_codes}")
        print("-" * 50)
        
        while self.is_running:
            # 获取北京时间
            now = datetime.now(beijing_tz)
            
            # 定义关键时间点
            t_09_15 = now.replace(hour=9, minute=15, second=0, microsecond=0)
            t_11_30 = now.replace(hour=11, minute=30, second=0, microsecond=0)
            t_13_00 = now.replace(hour=13, minute=0, second=0, microsecond=0)
            t_15_05 = now.replace(hour=15, minute=5, second=0, microsecond=0)
            
            # 1. 交易结束
            if now > t_15_05:
                print(f"\n[{now.strftime('%H:%M:%S')}] 收盘时间已到，监控安全退出。")
                self.is_running = False
                break
            
            # 2. 盘前/午间智能休眠 (减少 CPU 占用和 API 消耗)
            if now < t_09_15:
                wait = (t_09_15 - now).total_seconds()
                print(f"[{now.strftime('%H:%M:%S')}] 距离开盘还早，休眠 {int(wait)} 秒...")
                time.sleep(min(wait, 60))  # 最多睡60秒，防止线程无法退出
                continue
            
            if t_11_30 < now < t_13_00:
                wait = (t_13_00 - now).total_seconds()
                print(f"[{now.strftime('%H:%M:%S')}] 午间休市，休眠 {int(wait)} 秒...")
                time.sleep(min(wait, 60))
                continue
            
            # 3. 正常轮询
            self._run_once()
            time.sleep(self.interval)
        
        print(f"💤 监控线程已退出")
