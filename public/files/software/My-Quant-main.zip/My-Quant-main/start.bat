@echo off
chcp 65001 > nul
cls

echo ==================================================
echo   🚀 My Quant Web - 量化监控系统启动脚本
echo ==================================================
echo.

:: 检查Python环境
python --version >nul 2>&1
if errorlevel 1 (
    echo ❌ 错误: 未找到 Python
    echo 请安装 Python 3.8 或更高版本
    pause
    exit /b 1
)

echo ✅ Python 环境检测通过

:: 检查依赖
echo.
echo 📦 安装依赖...
pip install -r requirements.txt --quiet

:: 检查数据文件
if not exist "data\stock_basic_list.csv" (
    echo.
    echo ⚠️  警告: 未找到 data\stock_basic_list.csv
    echo    请确保股票列表文件存在
)

:: 启动应用
echo.
echo 🎉 启动 Flask 应用...
echo    访问地址: http://127.0.0.1:5000
echo    按 Ctrl+C 停止服务
echo.
python app.py

pause
