# My Quant Web - 量化监控系统

## ⚡ v1.1.0 最新版本 - 包含关键修复！

> 🔥 **重要更新**: 修复Tushare列名大小写问题，延长收盘时间至15:05，优化日志输出
> 
> 详见 [CHANGELOG.md](CHANGELOG.md)

## 🚀 快速开始（3步启动）

### 第1步：安装依赖
```bash
pip install -r requirements.txt
```

如果遇到网络问题，使用国内镜像：
```bash
pip install -r requirements.txt -i https://pypi.tuna.tsinghua.edu.cn/simple
```

### 第2步：修改Token
编辑 `app.py` 文件的第 12 行，替换为你的 Tushare Token：

```python
TOKEN = "your_tushare_token_here"
```

💡 如何获取Token：访问 https://tushare.pro/register 注册账号

### 第3步：启动应用
```bash
python app.py
```

然后在浏览器打开：**http://127.0.0.1:5000**

---

## 📂 项目结构

```
quant_web/
├── app.py                    # Flask后端主程序
├── quant_monitor.py          # 核心监控类
├── requirements.txt          # Python依赖
├── data/
│   └── stock_basic_list.csv  # 股票列表（3191只）
├── templates/
│   ├── index.html            # 主页
│   └── real_time.html        # 配置页
└── static/
    ├── css/style.css         # 深色主题样式
    └── js/real_time.js       # 前端交互逻辑
```

---

## 🎯 使用流程

1. **访问主页** → http://127.0.0.1:5000
2. **点击按钮** → "实盘监控 (Real Time)"
3. **选择股票** → 搜索或多选（支持模糊搜索）
4. **选择日期** → 默认今天
5. **开始运行** → 点击按钮，后台启动监控
6. **查看数据** → 数据保存在 `market_data_YYYYMMDD.db`

---

## ✨ 核心功能

✅ **深色科技风UI** - Bootstrap 5专业设计  
✅ **Select2智能搜索** - 支持代码/名称模糊匹配  
✅ **后台线程运行** - Web界面不阻塞  
✅ **实时数据采集** - 基于Tushare API  
✅ **本地数据存储** - SQLite数据库  
✅ **智能时间控制** - 交易时间自动管理  

---

## 🔧 核心API

### 获取股票列表
```
GET /api/stocks
```

### 启动监控
```
POST /api/run
Body: {"stocks": ["600000.SH"], "date": "20260202"}
```

### 停止监控
```
POST /api/stop
```

### 查看状态
```
GET /api/status
```

---

## 📊 数据库查看

### 使用SQLite命令
```bash
sqlite3 market_data_20260202.db
```

```sql
-- 查看总记录数
SELECT COUNT(*) FROM realtime_quotes;

-- 查看最新10条数据
SELECT * FROM realtime_quotes 
ORDER BY record_time DESC 
LIMIT 10;

-- 按股票分组统计
SELECT ts_code, name, COUNT(*) 
FROM realtime_quotes 
GROUP BY ts_code;
```

### 使用Python
```python
import pandas as pd
import sqlite3

conn = sqlite3.connect('market_data_20260202.db')
df = pd.read_sql('SELECT * FROM realtime_quotes', conn)
print(df.head())
```

---

## ⚙️ 配置说明

### 修改采集间隔
编辑 `app.py` 第 15 行：
```python
monitor = QuantMonitor(token=TOKEN, interval=2)  # 默认2秒
```

### 修改监控时间
编辑 `quant_monitor.py` 的 `_run_loop()` 方法：
```python
t_09_15 = now.replace(hour=9, minute=15, ...)  # 开盘时间
t_15_05 = now.replace(hour=15, minute=5, ...)   # 收盘时间(15:05)
```

---

## ⚠️ 注意事项

1. **交易时间**：仅在 09:15-15:05 运行（已优化至15:05）
2. **网络连接**：需要稳定的互联网（访问Tushare）
3. **Token安全**：不要泄露或提交到公开仓库
4. **数据频率**：默认2秒采集间隔（可配置）
5. **列名修复**：v1.1已自动处理Tushare列名大小写问题

---

## 🐛 常见问题

### Q: 股票列表不显示？
**A**: 检查 `data/stock_basic_list.csv` 是否存在

### Q: 启动后没有数据？
**A**: 
- 检查Token是否有效
- 确认是否在交易时间
- 查看控制台错误日志

### Q: 按钮点击没反应？
**A**: 
- 打开浏览器控制台（F12）查看错误
- 检查后端是否正常运行

---

## 📝 技术栈

**后端**: Python 3.8+, Flask, Pandas, Tushare, SQLite  
**前端**: HTML5, Bootstrap 5, jQuery, Select2  
**架构**: 多线程异步，RESTful API

---

## 📄 许可证

MIT License - 自由使用和修改

---

## 🙏 致谢

- [Tushare](https://tushare.pro/) - 金融数据接口
- [Flask](https://flask.palletsprojects.com/) - Web框架
- [Bootstrap](https://getbootstrap.com/) - UI框架
- [Select2](https://select2.org/) - 下拉框插件

---

**🎉 祝您使用愉快！**

如有问题，请检查：
1. Python版本（需要3.8+）
2. 依赖是否正确安装
3. Token是否有效
4. 是否在交易时间

**版本**: v1.1.0 (包含关键修复)  
**更新**: 2026-02-02  
**作者**: Wise XiaoXu

---

## 📝 更新日志

查看 [CHANGELOG.md](CHANGELOG.md) 了解详细更新内容

### v1.1.0 主要更新
- 🔥 修复Tushare列名大小写问题（关键）
- ⏰ 收盘时间延长至15:05
- 📊 优化日志输出
- ⚡ 采集间隔优化为2秒
