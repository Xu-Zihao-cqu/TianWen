$(document).ready(function() {
    
    // ==========================================
    // 初始化Select2
    // ==========================================
    
    $('#stockSelect').select2({
        theme: 'bootstrap-5',
        placeholder: '搜索股票代码或名称...',
        allowClear: true,
        width: '100%',
        ajax: {
            url: '/api/stocks',
            dataType: 'json',
            delay: 250,
            processResults: function(response) {
                if (response.status === 'success') {
                    return {
                        results: response.data
                    };
                } else {
                    showAlert('加载股票列表失败', 'danger');
                    return { results: [] };
                }
            },
            cache: true
        },
        minimumInputLength: 0
    });
    
    // 页面加载时立即触发一次搜索，显示所有股票
    $('#stockSelect').select2('open');
    $('#stockSelect').select2('close');
    
    
    // ==========================================
    // 设置默认日期为今天
    // ==========================================
    
    const today = new Date();
    const year = today.getFullYear();
    const month = String(today.getMonth() + 1).padStart(2, '0');
    const day = String(today.getDate()).padStart(2, '0');
    $('#dateInput').val(`${year}-${month}-${day}`);
    
    
    // ==========================================
    // 表单提交事件
    // ==========================================
    
    $('#monitorForm').on('submit', function(e) {
        e.preventDefault();
        
        const selectedStocks = $('#stockSelect').val();
        const selectedDate = $('#dateInput').val();
        
        // 验证
        if (!selectedStocks || selectedStocks.length === 0) {
            showAlert('请至少选择一只股票', 'danger');
            return;
        }
        
        if (!selectedDate) {
            showAlert('请选择监控日期', 'danger');
            return;
        }
        
        // 转换日期格式 YYYY-MM-DD -> YYYYMMDD
        const dateStr = selectedDate.replace(/-/g, '');
        
        // 禁用按钮，显示加载状态
        const $runBtn = $('#runBtn');
        $runBtn.prop('disabled', true);
        $runBtn.html('<i class="bi bi-hourglass-split"></i> 正在启动...');
        
        // 发送AJAX请求
        $.ajax({
            url: '/api/run',
            type: 'POST',
            contentType: 'application/json',
            data: JSON.stringify({
                stocks: selectedStocks,
                date: dateStr
            }),
            success: function(response) {
                if (response.status === 'success') {
                    showAlert(
                        `✅ ${response.message}<br>数据库: ${response.db_name}`,
                        'success'
                    );
                    
                    // 修改按钮状态
                    $runBtn.html('<i class="bi bi-check-circle"></i> 运行中...');
                    $runBtn.removeClass('btn-primary').addClass('btn-success');
                } else {
                    showAlert(`❌ ${response.message}`, 'danger');
                    resetButton();
                }
            },
            error: function(xhr, status, error) {
                let errorMsg = '启动失败';
                if (xhr.responseJSON && xhr.responseJSON.message) {
                    errorMsg = xhr.responseJSON.message;
                }
                showAlert(`❌ ${errorMsg}`, 'danger');
                resetButton();
            }
        });
    });
    
    
    // ==========================================
    // 停止监控按钮
    // ==========================================
    
    $('#stopBtn').on('click', function() {
        if (!confirm('确定要停止当前监控任务吗？')) {
            return;
        }
        
        $.ajax({
            url: '/api/stop',
            type: 'POST',
            success: function(response) {
                if (response.status === 'success') {
                    showAlert(`🛑 ${response.message}`, 'info');
                    resetButton();
                } else {
                    showAlert(`⚠️ ${response.message}`, 'danger');
                }
            },
            error: function(xhr) {
                let errorMsg = '停止失败';
                if (xhr.responseJSON && xhr.responseJSON.message) {
                    errorMsg = xhr.responseJSON.message;
                }
                showAlert(`❌ ${errorMsg}`, 'danger');
            }
        });
    });
    
    
    // ==========================================
    // 查看状态按钮
    // ==========================================
    
    $('#statusBtn').on('click', function() {
        $.ajax({
            url: '/api/status',
            type: 'GET',
            success: function(response) {
                if (response.status === 'success') {
                    const data = response.data;
                    const statusHtml = `
                        <strong>运行状态:</strong> ${data.is_running ? '✅ 运行中' : '⏸️ 未运行'}<br>
                        <strong>监控股票:</strong> ${data.monitored_stocks} 只<br>
                        <strong>监控日期:</strong> ${data.date || 'N/A'}<br>
                        <strong>数据库:</strong> ${data.db_name || 'N/A'}
                    `;
                    showAlert(statusHtml, 'info');
                } else {
                    showAlert('获取状态失败', 'danger');
                }
            },
            error: function() {
                showAlert('获取状态失败', 'danger');
            }
        });
    });
    
    
    // ==========================================
    // 工具函数
    // ==========================================
    
    function showAlert(message, type) {
        const $alert = $('#statusAlert');
        $alert.removeClass('alert-info alert-success alert-danger alert-warning');
        $alert.addClass(`alert-${type}`);
        $('#statusText').html(message);
        $alert.removeClass('d-none').hide().fadeIn();
        
        // 8秒后自动隐藏
        setTimeout(function() {
            $alert.fadeOut();
        }, 8000);
    }
    
    function resetButton() {
        const $runBtn = $('#runBtn');
        $runBtn.prop('disabled', false);
        $runBtn.html('<i class="bi bi-play-fill"></i> 开始运行');
        $runBtn.removeClass('btn-success').addClass('btn-primary');
    }
    
});
