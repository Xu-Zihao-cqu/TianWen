#!/bin/bash

echo "=================================================="
echo "  🚀 My Quant Web - 量化监控系统启动脚本"
echo "=================================================="
echo ""

# 检查Python环境
if ! command -v python3 &> /dev/null
then
    echo "❌ 错误: 未找到 Python3"
    exit 1
fi

echo "✅ Python3 环境检测通过"

# 检查依赖
echo ""
echo "📦 安装依赖..."
pip3 install -r requirements.txt --quiet

# 检查数据文件
if [ ! -f "data/stock_basic_list.csv" ]; then
    echo ""
    echo "⚠️  警告: 未找到 data/stock_basic_list.csv"
    echo "   请确保股票列表文件存在"
fi

# 启动应用
echo ""
echo "🎉 启动 Flask 应用..."
echo "   访问地址: http://127.0.0.1:5000"
echo "   按 Ctrl+C 停止服务"
echo ""
python3 app.py
