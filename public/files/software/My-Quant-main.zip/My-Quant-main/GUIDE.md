# 完整使用指南

## 📖 目录

1. [项目介绍](#项目介绍)
2. [安装部署](#安装部署)
3. [详细使用](#详细使用)
4. [功能说明](#功能说明)
5. [数据查看](#数据查看)
6. [常见问题](#常见问题)
7. [高级配置](#高级配置)

---

## 项目介绍

My Quant Web 是一个基于 Flask + Bootstrap 5 的专业股票实时监控系统。

### 核心特性

- 🎨 **深色科技风UI** - 专业量化交易终端风格
- 🔍 **Select2智能搜索** - 支持股票代码/名称模糊匹配
- ⚡ **后台线程运行** - Web界面不阻塞，用户体验流畅
- 💾 **本地数据存储** - SQLite数据库，33字段完整记录
- 📊 **实时行情采集** - 基于Tushare API
- ⏰ **智能时间控制** - 交易时间自动管理

### 技术架构

```
前端: Bootstrap 5 + jQuery + Select2
  ↓ AJAX
后端: Flask + Pandas + Tushare
  ↓ 守护线程
监控: QuantMonitor 类（后台运行）
  ↓ 数据采集
数据库: SQLite (market_data_YYYYMMDD.db)
```

---

## 安装部署

### 环境要求

- Python 3.8 或更高版本
- pip 包管理器
- 稳定的网络连接（访问Tushare API）

### 安装步骤

#### 方式1：使用启动脚本（推荐）

**Linux/Mac:**
```bash
./start.sh
```

**Windows:**
```cmd
start.bat
```

#### 方式2：手动安装

```bash
# 1. 安装依赖
pip install -r requirements.txt

# 2. 修改Token（app.py 第12行）
# TOKEN = "your_token_here"

# 3. 启动应用
python app.py
```

### 获取Tushare Token

1. 访问 https://tushare.pro/register
2. 注册账号
3. 进入个人中心
4. 复制Token
5. 粘贴到 `app.py` 的 `TOKEN` 变量

---

## 详细使用

### 步骤1: 启动应用

运行启动脚本或执行 `python app.py`，看到以下输出：

```
╔═══════════════════════════════════════╗
║   🚀 My Quant Web - 量化监控系统    ║
╠═══════════════════════════════════════╣
║   访问地址: http://127.0.0.1:5000   ║
║   作者: AI Full Stack Engineer        ║
╚═══════════════════════════════════════╝
```

### 步骤2: 访问主页

在浏览器打开 `http://127.0.0.1:5000`

主页特色：
- 渐变标题 "My Quant Web"
- 大按钮 "实盘监控 (Real Time)"
- 3个特性卡片展示

### 步骤3: 进入配置页

点击 **"实盘监控 (Real Time)"** 按钮

### 步骤4: 选择股票

#### 方法A：搜索选择
1. 点击下拉框
2. 输入股票代码（如：600000）
3. 或输入名称（如：浦发银行）
4. 点击选择

#### 方法B：多选
- **Windows**: 按住 Ctrl + 点击多个股票
- **Mac**: 按住 Command + 点击多个股票

#### 搜索示例
- 输入 "600" → 显示所有600开头的股票
- 输入 "银行" → 显示所有银行类股票
- 输入 "600000.SH" → 精确定位

### 步骤5: 选择日期

- 默认选中今天
- 可点击日历图标选择其他日期

### 步骤6: 启动监控

点击 **"开始运行"** 按钮

按钮会变为：
- 文字：**"运行中..."**
- 颜色：绿色
- 状态：不可点击

顶部会显示成功提示：
```
✅ 监控已启动，监控 5 只股票
数据库: market_data_20260202.db
```

### 步骤7: 管理监控

**查看状态**
- 点击右上角 **"查看状态"** 按钮
- 显示：运行状态、监控股票数、日期、数据库

**停止监控**
- 点击右上角 **"停止监控"** 按钮
- 确认后停止

---

## 功能说明

### 后台运行机制

```python
# 用户点击"开始运行"
↓
# Flask接收请求
monitor.start(stocks, date)
↓
# 创建守护线程
thread = threading.Thread(target=_run_loop, daemon=True)
thread.start()
↓
# 立即返回（不阻塞！）
return {"status": "success"}
↓
# 线程在后台运行
while is_running:
    采集数据 → 写入数据库 → 休眠
```

### 智能时间控制

```python
# 09:15 之前
→ 自动休眠，等待开盘

# 09:15 - 11:30
→ 正常采集数据

# 11:30 - 13:00
→ 午间休市，自动休眠

# 13:00 - 15:00
→ 正常采集数据

# 15:00 之后
→ 自动停止，收盘退出
```

### 增量数据采集

```python
# 只记录新数据，避免重复
if time > last_recorded_time[stock]:
    写入数据库
    更新最后时间
else:
    跳过（已采集过）
```

---

## 数据查看

### 数据库文件

- **位置**: 项目根目录
- **命名**: `market_data_YYYYMMDD.db`
- **格式**: SQLite3
- **表名**: `realtime_quotes`

### 字段说明

| 字段 | 类型 | 说明 |
|------|------|------|
| ts_code | TEXT | 股票代码 |
| name | TEXT | 股票名称 |
| date | TEXT | 日期 |
| time | TEXT | 时间 |
| open | REAL | 开盘价 |
| price | REAL | 最新价 |
| high | REAL | 最高价 |
| low | REAL | 最低价 |
| volume | INTEGER | 成交量 |
| amount | REAL | 成交额 |
| b1_p - b5_p | REAL | 买1-5价 |
| a1_p - a5_p | REAL | 卖1-5价 |
| record_time | DATETIME | 记录时间 |

### 查询示例

#### 使用SQLite命令行

```bash
# 进入数据库
sqlite3 market_data_20260202.db

# 查看表结构
.schema realtime_quotes

# 查看总记录数
SELECT COUNT(*) FROM realtime_quotes;

# 查看最新10条
SELECT ts_code, name, time, price, volume 
FROM realtime_quotes 
ORDER BY record_time DESC 
LIMIT 10;

# 按股票统计
SELECT ts_code, name, COUNT(*) as count, 
       MIN(price) as min_price, 
       MAX(price) as max_price
FROM realtime_quotes 
GROUP BY ts_code;

# 查看某只股票的历史
SELECT time, price, volume 
FROM realtime_quotes 
WHERE ts_code='600000.SH' 
ORDER BY time;
```

#### 使用Python

```python
import pandas as pd
import sqlite3

# 连接数据库
conn = sqlite3.connect('market_data_20260202.db')

# 读取所有数据
df = pd.read_sql('SELECT * FROM realtime_quotes', conn)

# 基本统计
print(df.describe())

# 按股票分组
grouped = df.groupby('ts_code')['price'].agg(['min', 'max', 'mean'])
print(grouped)

# 绘制价格走势
import matplotlib.pyplot as plt
stock_data = df[df['ts_code'] == '600000.SH']
plt.plot(stock_data['time'], stock_data['price'])
plt.show()
```

---

## 常见问题

### Q1: ImportError: No module named 'flask'

**原因**: 依赖未安装

**解决**:
```bash
pip install -r requirements.txt
```

### Q2: 股票列表不显示

**原因**: CSV文件缺失或路径错误

**解决**:
1. 检查 `data/stock_basic_list.csv` 是否存在
2. 检查文件编码是否为 UTF-8

### Q3: Token错误 401

**原因**: Tushare Token无效

**解决**:
1. 检查Token是否正确复制
2. 访问 https://tushare.pro 确认Token有效
3. 确保没有多余空格

### Q4: 启动后没有数据

**可能原因**:
- 不在交易时间（09:15-15:00）
- Token权限不足
- 网络连接问题

**解决**:
1. 查看控制台日志
2. 确认交易时间
3. 测试网络连接

### Q5: 端口5000被占用

**解决**:
编辑 `app.py` 最后一行：
```python
app.run(debug=True, host='0.0.0.0', port=5001)  # 改为其他端口
```

---

## 高级配置

### 修改采集间隔

编辑 `app.py`:
```python
monitor = QuantMonitor(token=TOKEN, interval=2.5)  # 改为其他值（秒）
```

建议值：
- 快速采集：1.0 秒
- 标准采集：2.5 秒
- 慢速采集：5.0 秒

### 修改监控时间

编辑 `quant_monitor.py` 的 `_run_loop()` 方法：

```python
# 修改开盘时间
t_09_15 = now.replace(hour=9, minute=15, second=0, microsecond=0)

# 修改收盘时间
t_15_00 = now.replace(hour=15, minute=0, second=0, microsecond=0)
```

### 添加日志记录

在 `app.py` 顶部添加：

```python
import logging

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('quant_web.log'),
        logging.StreamHandler()
    ]
)
```

### 部署到服务器

使用 Gunicorn（生产环境推荐）:

```bash
# 安装 gunicorn
pip install gunicorn

# 启动（4个工作进程）
gunicorn -w 4 -b 0.0.0.0:5000 app:app

# 后台运行
nohup gunicorn -w 4 -b 0.0.0.0:5000 app:app > gunicorn.log 2>&1 &
```

---

## 性能优化

### 数据库优化

```sql
-- 添加更多索引
CREATE INDEX idx_time ON realtime_quotes(time);
CREATE INDEX idx_price ON realtime_quotes(price);

-- 定期清理历史数据
DELETE FROM realtime_quotes WHERE date < '20260101';

-- 优化数据库
VACUUM;
```

### 内存优化

编辑 `quant_monitor.py`:

```python
# 限制缓存大小
if len(self.last_recorded_time) > 1000:
    self.last_recorded_time.clear()
    self._init_cache()
```

---

## 安全建议

1. **Token安全**
   - 不要提交到Git
   - 使用环境变量
   - 定期更换

2. **网络安全**
   - 仅监听127.0.0.1（本地）
   - 生产环境使用HTTPS
   - 添加身份验证

3. **数据安全**
   - 定期备份数据库
   - 限制文件访问权限
   - 加密敏感数据

---

**🎉 祝您使用愉快！**

有任何问题欢迎反馈！
