# Code of Conduct

We are committed to a professional, respectful, and inclusive project environment.

Contributors are expected to communicate constructively, review technical work on its merits, respect differing experience levels, avoid harassment or discriminatory behavior, and protect private or security-sensitive information.

Maintainers may edit, reject, or remove content that violates these expectations and may restrict participation when necessary to protect the community. Report conduct concerns through the repository's private maintainer contact channel or GitHub reporting tools.
