# Architecture

## Data path

1. `camera_init` configures the OV5640 over the two-wire control interface.
2. `DVP_Capture` receives pixel data, frame sync, and line-valid signals in the camera pixel-clock domain.
3. RGB565 pixels are expanded to RGB888 and processed by `image_enhance_top`.
4. The enhancement path performs color conversion, statistics, tone mapping, and gesture analysis.
5. `gesture_recognizer` produces a frame-level finger-count candidate and applies temporal stabilization.
6. Processed RGB data is packed back to RGB565 and stored through `sdram_control_top`.
7. `disp_driver` reads the frame at the display rate, while `hdmi_osd_lite` overlays status information.
8. `dvi_encoder` serializes the video into differential TMDS outputs.

```mermaid
flowchart TB
    subgraph Camera clock domain
      A[OV5640] --> B[DVP_Capture]
      B --> C[RGB565 to RGB888]
      C --> D[image_enhance_top]
      D --> E[gesture_recognizer]
      D --> F[RGB888 to RGB565]
    end
    F --> G[SDRAM controller]
    subgraph HDMI pixel clock domain
      G --> H[disp_driver]
      E --> I[2-stage status synchronizer]
      H --> J[hdmi_osd_lite]
      I --> J
      J --> K[dvi_encoder]
    end
```

## Clock domains

| Domain | Source | Main consumers | Notes |
|---|---|---|---|
| Board input clock | `clk` | PLLs, camera initialization | Frequency is board-specific. |
| Camera pixel clock | `camera_pclk` | capture, enhancement, gesture recognition, SDRAM write | Frame-level gesture status originates here. |
| SDRAM control clock | PLL `c0` | SDRAM controller | Must satisfy the installed SDRAM timing. |
| HDMI pixel clock | PLL HDMI `c0` | display timing and OSD | Nominally 74.25 MHz for 720p. |
| HDMI 5× clock | PLL HDMI `c1` | TMDS serializer | Nominally 371.25 MHz. |

The 4-bit frame-stable gesture state is synchronized into the HDMI pixel domain through two register stages before being displayed. This status crossing does not transfer pixel data.

## Module map

| Area | Main modules | Responsibility |
|---|---|---|
| Top level | `vision_gesture_controller` | Board interfaces and system integration |
| Camera | `camera_init`, `i2c_control`, `DVP_Capture` | Sensor setup and pixel capture |
| Algorithm | `image_enhance_top`, `image_stats`, `adaptive_tone_mapping`, `gesture_recognizer` | Enhancement and frame-level recognition |
| Memory | `sdram_control_top`, FIFOs, SDRAM controller | Clock-domain buffering and frame storage |
| Display | `disp_driver`, `hdmi_osd_lite`, `dvi_encoder` | Timing, overlay, and TMDS output |
| Clocking | `pll`, `pll_hdmi` | Internal clock generation |

## Gesture stabilization

A seven-frame sliding window is used. Ties retain the current stable state. Acquisition requires 4/7 votes, while a state switch or ordinary release requires 5/7. Strong fist evidence remains a fast release path. See [MULTI_FRAME_VOTING.md](MULTI_FRAME_VOTING.md).
