# Board Porting Guide

The RTL is organized for reuse, but `vision_gesture_controller.qsf`, the PLL blocks, SDRAM parameters, and several interface assumptions are board-specific.

## 1. Select the target device

Update the Quartus family and device assignments. Confirm available PLLs, memory blocks, I/O banks, differential-output capability, and voltage standards.

## 2. Replace pin constraints

Review every `set_location_assignment` and `set_instance_assignment` in the QSF. Never reuse the reference pin map on another board without checking the schematic. Verify:

- input oscillator and reset polarity;
- camera DVP, I²C, reset, power-down, and XCLK;
- SDRAM address, bank, data, byte masks, clock, and control pins;
- LED/control output polarity;
- TMDS/HDMI routing and required electrical standard.

## 3. Regenerate PLLs

Regenerate `pll` and `pll_hdmi` for the new input oscillator and device family. Preserve the intended functional clocks or update all dependent timing parameters. The reference display path expects a 74.25 MHz pixel clock and a 5× serialization clock.

## 4. Adapt external memory

Review `rtl/sdram/Sdram_Params.h`, controller timing, geometry, bus width, and maximum frame address. A different memory technology or geometry requires controller-level work, not only pin changes.

## 5. Adapt the camera

For a different sensor, replace the initialization table and verify pixel ordering, frame/line polarity, resolution, blanking, and pixel-clock limits. The current capture path expects 8-bit DVP data and RGB565 output from the configured OV5640 mode.

## 6. Review output control semantics

The reference 4-bit `led` output is active-low. When connecting relays, drivers, dimmers, or another controller, add suitable isolation and electrical protection outside the FPGA. Do not drive power loads directly from FPGA I/O.

## 7. Re-verify

Run the repository checks, then perform a clean Quartus compile, TimeQuest analysis, and hardware testing. Record the board revision, oscillator, memory part, camera module, Quartus version, and constraint changes in the pull request or release notes.
