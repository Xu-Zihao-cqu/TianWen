# GitHub Repository Setup

Recommended repository metadata for the first public release:

- **Repository name:** `fpga-vision-gesture-controller`
- **Description:** `Real-time Verilog FPGA pipeline for OV5640 capture, image enhancement, gesture recognition, temporal voting, SDRAM buffering, and 720p HDMI visualization.`
- **Website:** optional project documentation or demo page
- **Topics:** `fpga`, `verilog`, `computer-vision`, `gesture-recognition`, `ov5640`, `cyclone-iv`, `quartus`, `sdram`, `hdmi`, `embedded-vision`
- **Default branch:** `main`

## Recommended GitHub features

Enable Issues, Discussions, Projects, Private vulnerability reporting, branch protection, and automatic deletion of merged branches. Require the `Repository checks` workflow before merging to `main`.

## First upload

```bash
git init
git add .
git commit -m "feat: publish FPGA vision gesture controller v1.0.0"
git branch -M main
git remote add origin <your-repository-url>
git push -u origin main
```

Create the first release after completing the hardware checks:

```bash
git tag -a v1.0.0 -m "FPGA Vision Gesture Controller v1.0.0"
git push origin v1.0.0
```

The tag triggers `.github/workflows/release.yml`, which runs repository checks, creates a source archive, writes a SHA-256 checksum, and publishes both as GitHub release assets.

## Branch protection baseline

For `main`, require pull requests, at least one approval, conversation resolution, and the `static-checks` status. Restrict force pushes and branch deletion. Small personal repositories may allow maintainers to bypass these rules for emergency recovery.
