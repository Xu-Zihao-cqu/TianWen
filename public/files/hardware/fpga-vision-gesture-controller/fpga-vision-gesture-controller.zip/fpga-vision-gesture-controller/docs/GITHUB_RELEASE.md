# GitHub Publication and Release Guide

## First push

```bash
git init
git add .
git commit -m "chore: publish FPGA Vision Gesture Controller v1.0.0"
git branch -M main
git remote add origin <your-repository-url>
git push -u origin main
```

Recommended repository topics: `fpga`, `verilog`, `computer-vision`, `gesture-recognition`, `ov5640`, `sdram`, `hdmi`, `cyclone-iv`, `quartus`.

Enable GitHub Actions, Issues, Discussions if desired, and **Private vulnerability reporting** under the repository security settings. Protect `main` by requiring the `Repository checks` workflow and at least one pull-request review.

## First release

1. Complete [RELEASE_CHECKLIST.md](../RELEASE_CHECKLIST.md).
2. Tag the source commit: `git tag -s v1.0.0 -m "v1.0.0"`.
3. Push the tag: `git push origin v1.0.0`.
4. Create a GitHub Release using the matching changelog section.
5. Attach board-specific programming files only after full compile and hardware verification. Include checksums and clearly identify the board/device/tool version.

Do not publish generated FPGA binaries as universal artifacts; a `.sof` is only valid for the exact supported hardware and constraint set.
