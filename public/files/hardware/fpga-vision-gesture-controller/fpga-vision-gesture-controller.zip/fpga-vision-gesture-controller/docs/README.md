# Documentation

- [Architecture](ARCHITECTURE.md): data path, clocks, module responsibilities, and control flow.
- [Porting Guide](PORTING.md): steps required for a new FPGA board or sensor.
- [Algorithm](ALGORITHM.md): image-processing and recognition optimizations.
- [Multi-frame Voting](MULTI_FRAME_VOTING.md): temporal hysteresis and thresholds.
- [Fist Suppression](FIST_SUPPRESSION.md): strong and fragmented fist handling.
- [Validation Results](VALIDATION_RESULTS.txt): checks executed in the delivery environment.
- [Repository Setup](REPOSITORY_SETUP.md): metadata, topics, branch protection, and automated releases.
- [GitHub Release Guide](GITHUB_RELEASE.md): concise first-push and release recommendations.

The images under `assets/` include prototype demonstrations and an original application-oriented reference diagram. The RTL repository itself is intentionally named and documented as a general-purpose vision gesture controller.
