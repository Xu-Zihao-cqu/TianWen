# Project Governance

FPGA Vision Gesture Controller follows a lightweight, maintainer-led governance model.

## Decision process

Maintainers evaluate changes based on correctness, synthesizability, portability, verification quality, documentation, timing/resource impact, and compatibility with the reference design. Routine changes may be merged after review and successful checks. Changes to public interfaces, clocking, reset behavior, repository licensing, or release policy require explicit maintainer approval.

## Releases

Releases follow semantic versioning where practical:

- **major**: incompatible interface, project, or behavior changes;
- **minor**: backward-compatible features or supported-platform additions;
- **patch**: fixes, documentation, and non-breaking maintenance.

A hardware release is not considered validated until the relevant Quartus, timing, and board-level items in [RELEASE_CHECKLIST.md](RELEASE_CHECKLIST.md) are complete.

## Conduct and security

Participation is governed by [CODE_OF_CONDUCT.md](CODE_OF_CONDUCT.md). Vulnerabilities must be reported according to [SECURITY.md](SECURITY.md).
