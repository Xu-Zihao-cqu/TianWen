# Release Checklist

## Repository
- [ ] `make check` passes.
- [ ] Version and changelog are updated.
- [ ] No `.bak`, `db/`, `incremental_db/`, `output_files/`, `.sof`, `.pof`, or local workspace files are committed.
- [ ] README screenshots and documentation links render correctly on GitHub.

## Quartus
- [ ] Full clean compilation completes without errors.
- [ ] TimeQuest setup and hold requirements pass for all constrained clocks.
- [ ] Device, top-level entity, and pin assignments match the target board.
- [ ] PLL outputs and SDRAM timing are reviewed for the installed oscillator and memory.
- [ ] Compilation report, resource utilization, and warnings are archived with the release.

## Hardware
- [ ] Reset and power-up sequence are repeatable.
- [ ] Camera configuration and frame synchronization are stable.
- [ ] SDRAM frame buffering shows no tearing or corruption.
- [ ] HDMI output is stable at the intended resolution.
- [ ] 0–5 finger states and fist release are exercised under bright, backlit, low-light, and moving-hand conditions.
- [ ] LED/control polarity and external load interface are independently verified.

## Release assets
- [ ] Source archive is generated from a clean checkout.
- [ ] Programming file is labeled with board, FPGA device, Quartus version, commit, and checksum.
- [ ] Hardware limitations and unverified configurations are stated in the release notes.
