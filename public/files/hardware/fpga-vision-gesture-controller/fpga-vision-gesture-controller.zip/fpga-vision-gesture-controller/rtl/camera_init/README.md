# Camera Initialization

`camera_init` configures the image sensor through the two-wire control interface. The current top-level reference uses an OV5640 in RGB mode.

Supported top-level parameters:

```verilog
parameter CAMERA_TYPE     = "ov5640";
parameter IMAGE_TYPE      = 0;  // 0: RGB, 1: JPEG
parameter IMAGE_WIDTH     = 1280;
parameter IMAGE_HEIGHT    = 720;
parameter IMAGE_FLIP_EN   = 0;
parameter IMAGE_MIRROR_EN = 0;
```

When changing sensor, resolution, flip, mirror, or output format, review the corresponding initialization table and verify DVP timing on hardware.
