/***************************************************
*   Module Name     :   vision_gesture_controller       
*   Target Device   :   EP4CE10F17C8
*   Create Date     :   2021-12-20
*   Description     :  OV5640 video capture, SDRAM buffering, image enhancement, gesture recognition, and 720p HDMI output
**************************************************/
module vision_gesture_controller(
    input           clk,
    input           rst_n,
    output [3:0] led, // 改为 4 个 LED 用于显示手指数量 //led[1]反应PLL是否正常工作，led[0]反应摄像头是否工作
    
    //sdram control
    output          sdram_clk,
    output          sdram_cke,
    output          sdram_cs_n,
    output          sdram_we_n,
    output          sdram_cas_n,
    output          sdram_ras_n,
    output  [1:0]   sdram_dqm,
    output  [1:0]   sdram_ba,
    output  [12:0]  sdram_addr,
    inout   [15:0]  sdram_dq,
    
    //cmos interface
    output          camera_sclk,
    inout           camera_sdat,
    input           camera_vsync,
    input           camera_href,
    input           camera_pclk,
    output          camera_xclk,
    input   [7:0]   camera_data,
    output          camera_rst_n,
    output          camera_pwdn,
    
    //hdmi output
    output          tmds_clk_p,
    output          tmds_clk_n,
    output  [2:0]   tmds_data_p,    //rgb
    output  [2:0]   tmds_data_n     //rgb
);
    wire clk_sdr_ctrl;
    wire clk_50m;
    wire clk_24m;
    wire locked;
    wire Init_Done;
    assign camera_xclk = clk_24m;
    
    pll pll_inst (
        .inclk0(clk),
        .areset(!rst_n),
        .locked(locked),
        .c0(clk_sdr_ctrl),
        .c1(sdram_clk),
        .c2(clk_50m),
        .c3(clk_24m)
    );
    
    wire clk_vga;   //74.25m
    wire clk_vgax5; //371.25m
    pll_hdmi pll_hdmi_inst(
        .inclk0(clk),
        .c0(clk_vga),
        .c1(clk_vgax5)
    );
    
    localparam RGB = 0;
    localparam JPEG = 1;
    
    parameter IMAGE_WIDTH  = 1280; //图片宽度  
    parameter IMAGE_HEIGHT = 720;  //图片高度(≤720) 
    parameter IMAGE_FLIP   = 0;   //0：不翻转，1：上下翻转
    parameter IMAGE_MIRROR = 0;   //0：不镜像，1：左右镜像

    //摄像头初始化配置
    camera_init
    #(
        .CAMERA_TYPE    ("ov5640"),       
        .IMAGE_TYPE     (RGB),
        .IMAGE_WIDTH    (IMAGE_WIDTH),
        .IMAGE_HEIGHT   (IMAGE_HEIGHT),
        .IMAGE_FLIP_EN  (IMAGE_FLIP),     
        .IMAGE_MIRROR_EN(IMAGE_MIRROR)    
    )
    camera_init_inst(                     
        .Clk            (clk),     // 修正了大小写错误
        .Rst_n          (rst_n),   // 修正了大小写错误
        .Init_Done      (Init_Done),
        .camera_rst_n   (camera_rst_n),
        .camera_pwdn    (camera_pwdn),
        .i2c_sclk       (camera_sclk),
        .i2c_sdat       (camera_sdat)
    );
    
    //-----------------------------------------------
    //摄像头图像输出
    wire fifo_aclr;
    wire fifo_wrreq;
    wire [15:0] fifo_wrdata;
    DVP_Capture DVP_Capture(
        .Rst_n(Init_Done),
        .PCLK(camera_pclk),
        .Vsync(camera_vsync),
        .Href(camera_href),
        .Data(camera_data),
        .ImageState(fifo_aclr),
        .DataValid(fifo_wrreq),
        .DataPixel(fifo_wrdata),
        .Xaddr(),
        .Yaddr()
    );
	 
	 // --- 定义中间连接线 ---
    // 原始 RGB888 信号
    wire [7:0] isp_r, isp_g, isp_b;
    wire       isp_de; 
    
    // 处理后的 RGB888 信号
    wire [7:0] proc_r, proc_g, proc_b;
    wire       proc_de;

    // 1. 将 DVP 输出的 16-bit RGB565 扩展为 24-bit RGB888
    assign isp_r = {fifo_wrdata[15:11], fifo_wrdata[15:13]};
    assign isp_g = {fifo_wrdata[10:5], fifo_wrdata[10:9]};
    assign isp_b = {fifo_wrdata[4:0], fifo_wrdata[4:2]};
    assign isp_de = fifo_wrreq; // 将采集端的有效信号作为 ISP 的 DE
	 
	 wire [3:0] gesture_led;

	 assign led = gesture_led;

    // 2. 图像增强模块实例化 (高曝光处理)
    image_enhance_top u_image_enhance (
        .clk      (camera_pclk),  // 核心！必须使用摄像头像素时钟
        .rst_n    (Init_Done),
        
        .orig_r   (isp_r),
        .orig_g   (isp_g),
        .orig_b   (isp_b),
        .orig_hs  (camera_href), // 真实行有效信号
        .orig_vs  (camera_vsync),// 真实帧同步，手势算法必须使用
        .orig_de  (isp_de),
        
        .proc_r   (proc_r),
        .proc_g   (proc_g),
        .proc_b   (proc_b),
        .proc_hs  (),             // 悬空
        .proc_vs  (),             // 悬空
        .proc_de  (proc_de),
		  .led_out  (gesture_led)
    );
	 

    // 3. 将处理后的 24-bit RGB888 重新压缩回 16-bit RGB565
    // 注意：这里需要替换原本送往 sdram_control_top 的 fifo_wrdata 和 fifo_wrreq
    wire [15:0] fifo_wrdata_proc;
    assign fifo_wrdata_proc = {proc_r[7:3], proc_g[7:2], proc_b[7:3]};
    
    wire [15:0] RGB_DATA;
    wire DataReq;
    sdram_control_top sdram_control_top(
        .Clk(clk_sdr_ctrl),
        .Rst_n(rst_n),
        .Wr_data(fifo_wrdata_proc), // 使用处理后的数据
		  .Wr_en(proc_de),
        .Wr_addr(0),
        .Wr_max_addr(IMAGE_WIDTH*IMAGE_HEIGHT),
        .Wr_load(!Init_Done),
        .Wr_clk(camera_pclk),
        .Wr_full(),
        .Wr_use(),
        .Rd_data(RGB_DATA),
        .Rd_en(DataReq),
        .Rd_addr(0),
        .Rd_max_addr(IMAGE_WIDTH*IMAGE_HEIGHT),
        .Rd_load(!Init_Done),
        .Rd_clk(clk_vga),
        .Rd_empty(),
        .Rd_use(),
        .Sa(sdram_addr),
        .Ba(sdram_ba),
        .Cs_n(sdram_cs_n),
        .Cke(sdram_cke),
        .Ras_n(sdram_ras_n),
        .Cas_n(sdram_cas_n),
        .We_n(sdram_we_n),
        .Dq(sdram_dq),
        .Dqm(sdram_dqm)
    );
    
    wire        video_hs_raw;
    wire        video_vs_raw;
    wire        video_de_raw;
    wire [7:0]  video_r_raw;
    wire [7:0]  video_g_raw;
    wire [7:0]  video_b_raw;
    wire        video_hs;
    wire        video_vs;
    wire        video_de;
    wire [7:0]  video_r;
    wire [7:0]  video_g;
    wire [7:0]  video_b;
    wire [11:0] H_Addr;
    wire [11:0] V_Addr;
    
    // 生成标准的VGA时序信号和RGB数据
    disp_driver disp_driver(
        .ClkDisp(clk_vga),
        .Rst_n(rst_n),
        .Data({RGB_DATA[15:11],3'd0,RGB_DATA[10:5],2'd0,RGB_DATA[4:0],3'd0}),
        .DataReq(DataReq),
        .H_Addr(H_Addr),
        .V_Addr(V_Addr),
        .Disp_HS(video_hs_raw),
        .Disp_VS(video_vs_raw),
        .Disp_Red(video_r_raw),
        .Disp_Green(video_g_raw),
        .Disp_Blue(video_b_raw),
        .Disp_DE(video_de_raw),
        .Disp_PCLK()
    );

    // Synchronize only frame-stable status bits into the HDMI pixel domain.
    // The original gesture algorithm and image pipeline are unchanged.
    reg [3:0] gesture_led_meta;
    reg [3:0] gesture_led_vga;
    reg [1:0] ready_meta;
    reg [1:0] ready_vga;
    always @(posedge clk_vga or negedge rst_n) begin
        if (!rst_n) begin
            gesture_led_meta <= 4'b1111;
            gesture_led_vga  <= 4'b1111;
            ready_meta <= 2'b00;
            ready_vga  <= 2'b00;
        end else begin
            gesture_led_meta <= gesture_led;
            gesture_led_vga  <= gesture_led_meta;
            ready_meta <= {locked, Init_Done};
            ready_vga  <= ready_meta;
        end
    end

    hdmi_osd_lite u_hdmi_osd_lite(
        .clk(clk_vga),
        .rst_n(rst_n),
        .h_addr(H_Addr),
        .v_addr(V_Addr),
        .in_hs(video_hs_raw),
        .in_vs(video_vs_raw),
        .in_de(video_de_raw),
        .in_r(video_r_raw),
        .in_g(video_g_raw),
        .in_b(video_b_raw),
        .gesture_led(gesture_led_vga),
        .camera_ready(ready_vga[0]),
        .pll_locked(ready_vga[1]),
        .out_hs(video_hs),
        .out_vs(video_vs),
        .out_de(video_de),
        .out_r(video_r),
        .out_g(video_g),
        .out_b(video_b)
    );

   
    dvi_encoder u_dvi_encoder(
		.pixelclk(clk_vga),		// system clock
		.pixelclk5x(clk_vgax5),	// system clock x5
		.rst_n(rst_n),				// reset
		.blue_din(video_b),		// Blue data in
		.green_din(video_g),		// Green data in
		.red_din(video_r),		// Red data in
		.hsync(video_hs),			// hsync data
		.vsync(video_vs),			// vsync data
		.de(video_de),				// data enable
		.tmds_clk_p(tmds_clk_p),
		.tmds_clk_n(tmds_clk_n),
		.tmds_data_p(tmds_data_p),//rgb
		.tmds_data_n(tmds_data_n) //rgb
	);

    
endmodule