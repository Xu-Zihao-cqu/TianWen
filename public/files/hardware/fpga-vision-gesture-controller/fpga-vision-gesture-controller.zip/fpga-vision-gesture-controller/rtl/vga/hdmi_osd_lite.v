/*============================================================================
* Lightweight HDMI OSD overlay.
*
* Design goals:
*   1) Keep the original camera picture and HDMI timing path intact.
*   2) Use only rectangles, lines and seven-segment digits.
*   3) No font ROM, no image ROM and no large dashboard combinational tree.
*   4) One registered output stage; RGB/HS/VS/DE stay aligned.
*
* gesture_led is the existing active-low indication from the stable gesture
* vote: 1110=1, 1100=2, 1000=3, 0000=4/5, 1111=no valid gesture/fist.
============================================================================*/
module hdmi_osd_lite(
    input  wire        clk,
    input  wire        rst_n,
    input  wire [11:0] h_addr,
    input  wire [11:0] v_addr,
    input  wire        in_hs,
    input  wire        in_vs,
    input  wire        in_de,
    input  wire [7:0]  in_r,
    input  wire [7:0]  in_g,
    input  wire [7:0]  in_b,
    input  wire [3:0]  gesture_led,
    input  wire        camera_ready,
    input  wire        pll_locked,
    output reg         out_hs,
    output reg         out_vs,
    output reg         out_de,
    output reg  [7:0]  out_r,
    output reg  [7:0]  out_g,
    output reg  [7:0]  out_b
);

    reg [2:0] gesture_code;
    always @(*) begin
        case (gesture_led)
            4'b1110: gesture_code = 3'd1;
            4'b1100: gesture_code = 3'd2;
            4'b1000: gesture_code = 3'd3;
            4'b0000: gesture_code = 3'd4; // 4/5 fingers share max level
            default: gesture_code = 3'd0;
        endcase
    end

    function [6:0] seg_mask;
        input [2:0] value;
        begin
            case (value)
                3'd0: seg_mask = 7'b0000001; // dash/no gesture
                3'd1: seg_mask = 7'b0110000;
                3'd2: seg_mask = 7'b1101101;
                3'd3: seg_mask = 7'b1111001;
                3'd4: seg_mask = 7'b0110011;
                3'd5: seg_mask = 7'b1011011;
                default: seg_mask = 7'b0000001;
            endcase
        end
    endfunction

    function digit_pixel;
        input [11:0] x;
        input [11:0] y;
        input [11:0] x0;
        input [11:0] y0;
        input [2:0]  value;
        input [3:0]  scale;
        reg [11:0] lx;
        reg [11:0] ly;
        reg [6:0]  m;
        reg [11:0] t;
        reg [11:0] w;
        reg [11:0] h;
        begin
            t = scale;
            w = scale * 8;
            h = scale * 14;
            lx = x - x0;
            ly = y - y0;
            m = seg_mask(value);
            digit_pixel = 1'b0;
            if ((x >= x0) && (x < x0 + w) && (y >= y0) && (y < y0 + h)) begin
                if ((m[6] && (ly < t) && (lx >= t) && (lx < w-t)) ||
                    (m[5] && (lx >= w-t) && (ly >= t) && (ly < (h>>1)-1)) ||
                    (m[4] && (lx >= w-t) && (ly > (h>>1)) && (ly < h-t)) ||
                    (m[3] && (ly >= h-t) && (lx >= t) && (lx < w-t)) ||
                    (m[2] && (lx < t) && (ly > (h>>1)) && (ly < h-t)) ||
                    (m[1] && (lx < t) && (ly >= t) && (ly < (h>>1)-1)) ||
                    (m[0] && (ly >= (h>>1)-1) && (ly <= (h>>1)+1) &&
                              (lx >= t) && (lx < w-t)))
                    digit_pixel = 1'b1;
            end
        end
    endfunction

    wire result_digit = digit_pixel(h_addr, v_addr, 12'd72, 12'd102,
                                    gesture_code, 4'd5);
    wire map_digit1 = digit_pixel(h_addr, v_addr, 12'd88, 12'd657, 3'd1, 4'd2);
    wire map_digit2 = digit_pixel(h_addr, v_addr, 12'd386, 12'd657, 3'd2, 4'd2);
    wire map_digit3 = digit_pixel(h_addr, v_addr, 12'd684, 12'd657, 3'd3, 4'd2);
    wire map_digit4 = digit_pixel(h_addr, v_addr, 12'd982, 12'd657, 3'd4, 4'd2);
    wire map_digit5 = digit_pixel(h_addr, v_addr, 12'd1004, 12'd657, 3'd5, 4'd2);

    reg [7:0] r_comb;
    reg [7:0] g_comb;
    reg [7:0] b_comb;

    always @(*) begin
        r_comb = in_r;
        g_comb = in_g;
        b_comb = in_b;

        if (!in_de) begin
            r_comb = 8'd0;
            g_comb = 8'd0;
            b_comb = 8'd0;
        end else begin
            // Thin medical-blue header; camera remains visible below it.
            if (v_addr < 12'd42) begin
                r_comb = 8'd4;
                g_comb = 8'd38;
                b_comb = 8'd88;
            end
            if ((v_addr >= 12'd40) && (v_addr < 12'd43)) begin
                r_comb = 8'd28;
                g_comb = 8'd153;
                b_comb = 8'd242;
            end

            // Top status lamps.
            if ((v_addr >= 12'd14) && (v_addr < 12'd28)) begin
                if ((h_addr >= 12'd24) && (h_addr < 12'd38)) begin
                    r_comb = camera_ready ? 8'd45 : 8'd220;
                    g_comb = camera_ready ? 8'd225 : 8'd70;
                    b_comb = camera_ready ? 8'd70 : 8'd55;
                end else if ((h_addr >= 12'd50) && (h_addr < 12'd64)) begin
                    r_comb = pll_locked ? 8'd45 : 8'd220;
                    g_comb = pll_locked ? 8'd225 : 8'd70;
                    b_comb = pll_locked ? 8'd70 : 8'd55;
                end
            end

            // Five small level blocks in the header.
            if ((v_addr >= 12'd14) && (v_addr < 12'd29)) begin
                if ((h_addr >= 12'd1040) && (h_addr < 12'd1074)) begin
                    r_comb = (gesture_code >= 3'd1) ? 8'd92 : 8'd54;
                    g_comb = (gesture_code >= 3'd1) ? 8'd176 : 8'd70;
                    b_comb = (gesture_code >= 3'd1) ? 8'd255 : 8'd91;
                end else if ((h_addr >= 12'd1080) && (h_addr < 12'd1114)) begin
                    r_comb = (gesture_code >= 3'd2) ? 8'd85 : 8'd54;
                    g_comb = (gesture_code >= 3'd2) ? 8'd185 : 8'd70;
                    b_comb = (gesture_code >= 3'd2) ? 8'd255 : 8'd91;
                end else if ((h_addr >= 12'd1120) && (h_addr < 12'd1154)) begin
                    r_comb = (gesture_code >= 3'd2) ? 8'd255 : 8'd54;
                    g_comb = (gesture_code >= 3'd2) ? 8'd162 : 8'd70;
                    b_comb = (gesture_code >= 3'd2) ? 8'd24 : 8'd91;
                end else if ((h_addr >= 12'd1160) && (h_addr < 12'd1194)) begin
                    r_comb = (gesture_code >= 3'd3) ? 8'd255 : 8'd54;
                    g_comb = (gesture_code >= 3'd3) ? 8'd191 : 8'd70;
                    b_comb = (gesture_code >= 3'd3) ? 8'd20 : 8'd91;
                end else if ((h_addr >= 12'd1200) && (h_addr < 12'd1234)) begin
                    r_comb = (gesture_code >= 3'd4) ? 8'd255 : 8'd54;
                    g_comb = (gesture_code >= 3'd4) ? 8'd222 : 8'd70;
                    b_comb = (gesture_code >= 3'd4) ? 8'd18 : 8'd91;
                end
            end

            // Compact left result card; deliberately small to preserve video.
            if ((h_addr >= 12'd24) && (h_addr < 12'd268) &&
                (v_addr >= 12'd78) && (v_addr < 12'd284)) begin
                // 50% camera + dark blue tint, shift-only arithmetic.
                r_comb = (in_r >> 1);
                g_comb = (in_g >> 1) + 8'd12;
                b_comb = (in_b >> 1) + 8'd38;
            end
            if (((h_addr >= 12'd24) && (h_addr < 12'd268) &&
                 ((v_addr == 12'd78) || (v_addr == 12'd79) ||
                  (v_addr == 12'd282) || (v_addr == 12'd283))) ||
                ((v_addr >= 12'd78) && (v_addr < 12'd284) &&
                 ((h_addr == 12'd24) || (h_addr == 12'd25) ||
                  (h_addr == 12'd266) || (h_addr == 12'd267)))) begin
                r_comb = 8'd30;
                g_comb = 8'd158;
                b_comb = 8'd242;
            end

            // Large recognized gesture digit.
            if (result_digit) begin
                if (gesture_code == 3'd0) begin
                    r_comb = 8'd155; g_comb = 8'd170; b_comb = 8'd188;
                end else begin
                    r_comb = 8'd255; g_comb = 8'd207; b_comb = 8'd22;
                end
            end

            // Five vertical brightness bars inside result card.
            if ((h_addr >= 12'd146) && (h_addr < 12'd246) &&
                (v_addr >= 12'd112) && (v_addr < 12'd248)) begin
                if ((h_addr >= 12'd146) && (h_addr < 12'd160) && (v_addr >= 12'd218)) begin
                    r_comb=(gesture_code>=1)?8'd83:8'd64; g_comb=(gesture_code>=1)?8'd180:8'd78; b_comb=(gesture_code>=1)?8'd255:8'd96;
                end else if ((h_addr >= 12'd166) && (h_addr < 12'd180) && (v_addr >= 12'd196)) begin
                    r_comb=(gesture_code>=2)?8'd76:8'd64; g_comb=(gesture_code>=2)?8'd185:8'd78; b_comb=(gesture_code>=2)?8'd255:8'd96;
                end else if ((h_addr >= 12'd186) && (h_addr < 12'd200) && (v_addr >= 12'd174)) begin
                    r_comb=(gesture_code>=2)?8'd255:8'd64; g_comb=(gesture_code>=2)?8'd165:8'd78; b_comb=(gesture_code>=2)?8'd22:8'd96;
                end else if ((h_addr >= 12'd206) && (h_addr < 12'd220) && (v_addr >= 12'd152)) begin
                    r_comb=(gesture_code>=3)?8'd255:8'd64; g_comb=(gesture_code>=3)?8'd191:8'd78; b_comb=(gesture_code>=3)?8'd20:8'd96;
                end else if ((h_addr >= 12'd226) && (h_addr < 12'd240) && (v_addr >= 12'd130)) begin
                    r_comb=(gesture_code>=4)?8'd255:8'd64; g_comb=(gesture_code>=4)?8'd222:8'd78; b_comb=(gesture_code>=4)?8'd18:8'd96;
                end
            end

            // Gesture ROI corner guides; do not cover the hand image.
            if ((((h_addr >= 12'd680) && (h_addr < 12'd716)) ||
                 ((h_addr >= 12'd1194) && (h_addr < 12'd1230))) &&
                (((v_addr >= 12'd70) && (v_addr < 12'd73)) ||
                 ((v_addr >= 12'd676) && (v_addr < 12'd679)))) begin
                r_comb = 8'd56; g_comb = 8'd235; b_comb = 8'd88;
            end
            if ((((v_addr >= 12'd70) && (v_addr < 12'd106)) ||
                 ((v_addr >= 12'd644) && (v_addr < 12'd680))) &&
                (((h_addr >= 12'd680) && (h_addr < 12'd683)) ||
                 ((h_addr >= 12'd1227) && (h_addr < 12'd1230)))) begin
                r_comb = 8'd56; g_comb = 8'd235; b_comb = 8'd88;
            end

            // Bottom gesture-to-level mapping strip.
            if ((v_addr >= 12'd640) && (v_addr < 12'd704)) begin
                r_comb = 8'd5;
                g_comb = 8'd30;
                b_comb = 8'd67;
            end
            if ((v_addr >= 12'd640) && (v_addr < 12'd643)) begin
                r_comb = 8'd28; g_comb = 8'd145; b_comb = 8'd232;
            end

            // Four mapping cards with active highlight.
            if ((v_addr >= 12'd648) && (v_addr < 12'd698)) begin
                if ((h_addr >= 12'd24) && (h_addr < 12'd316)) begin
                    if ((gesture_code==1) && ((v_addr<12'd652)||(v_addr>=12'd694)||(h_addr<12'd28)||(h_addr>=12'd312))) begin
                        r_comb=8'd38; g_comb=8'd185; b_comb=8'd255;
                    end
                end else if ((h_addr >= 12'd322) && (h_addr < 12'd614)) begin
                    if ((gesture_code==2) && ((v_addr<12'd652)||(v_addr>=12'd694)||(h_addr<12'd326)||(h_addr>=12'd610))) begin
                        r_comb=8'd38; g_comb=8'd185; b_comb=8'd255;
                    end
                end else if ((h_addr >= 12'd620) && (h_addr < 12'd912)) begin
                    if ((gesture_code==3) && ((v_addr<12'd652)||(v_addr>=12'd694)||(h_addr<12'd624)||(h_addr>=12'd908))) begin
                        r_comb=8'd38; g_comb=8'd185; b_comb=8'd255;
                    end
                end else if ((h_addr >= 12'd918) && (h_addr < 12'd1256)) begin
                    if ((gesture_code==4) && ((v_addr<12'd652)||(v_addr>=12'd694)||(h_addr<12'd922)||(h_addr>=12'd1252))) begin
                        r_comb=8'd38; g_comb=8'd185; b_comb=8'd255;
                    end
                end
            end

            // Small digits for mapping cards.
            if (map_digit1 || map_digit2 || map_digit3 || map_digit4 || map_digit5) begin
                r_comb = 8'd222; g_comb = 8'd238; b_comb = 8'd255;
            end

            // Level strips in the four cards.
            if ((v_addr >= 12'd674) && (v_addr < 12'd686)) begin
                if ((h_addr >= 12'd142) && (h_addr < 12'd286)) begin
                    r_comb = (h_addr < 12'd174) ? 8'd82 : 8'd68;
                    g_comb = (h_addr < 12'd174) ? 8'd164 : 8'd83;
                    b_comb = (h_addr < 12'd174) ? 8'd240 : 8'd101;
                end else if ((h_addr >= 12'd440) && (h_addr < 12'd584)) begin
                    r_comb = (h_addr < 12'd520) ? 8'd113 : 8'd68;
                    g_comb = (h_addr < 12'd520) ? 8'd178 : 8'd83;
                    b_comb = (h_addr < 12'd520) ? 8'd236 : 8'd101;
                end else if ((h_addr >= 12'd738) && (h_addr < 12'd882)) begin
                    r_comb = (h_addr < 12'd850) ? 8'd255 : 8'd95;
                    g_comb = (h_addr < 12'd850) ? 8'd181 : 8'd91;
                    b_comb = (h_addr < 12'd850) ? 8'd22 : 8'd76;
                end else if ((h_addr >= 12'd1064) && (h_addr < 12'd1228)) begin
                    r_comb = 8'd255; g_comb = 8'd218; b_comb = 8'd18;
                end
            end
        end
    end

    // Single output register. The video and all timing signals are delayed by
    // exactly one pixel together, so TMDS timing remains aligned.
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            out_hs <= 1'b0;
            out_vs <= 1'b0;
            out_de <= 1'b0;
            out_r  <= 8'd0;
            out_g  <= 8'd0;
            out_b  <= 8'd0;
        end else begin
            out_hs <= in_hs;
            out_vs <= in_vs;
            out_de <= in_de;
            out_r  <= r_comb;
            out_g  <= g_comb;
            out_b  <= b_comb;
        end
    end
endmodule
