module piecewise_tone_mapping (
    input  wire        clk,
    input  wire        rst_n,
    
    input  wire [7:0]  in_y,
    input  wire [7:0]  in_cb,
    input  wire [7:0]  in_cr,
    input  wire        in_hs,
    input  wire        in_vs,
    input  wire        in_de,
    
    output reg  [7:0]  out_y,
    output reg  [7:0]  out_cb,
    output reg  [7:0]  out_cr,
    output reg         out_hs,
    output reg         out_vs,
    output reg         out_de
);

    // 声明内置 ROM，综合工具会自动将其映射为 M9K 块
    (* ram_init_file = "tone_map.mif" *) reg [7:0] piecewise_rom [0:255]; 

    // [第1拍] 查表读取新的 Y 值，同时对 Cb, Cr 和同步信号打拍对齐
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            out_y  <= 8'd0;
            out_cb <= 8'd128;
            out_cr <= 8'd128;
            {out_hs, out_vs, out_de} <= 0;
        end else begin
            out_y  <= piecewise_rom[in_y]; // LUT 映射恢复高曝光
            out_cb <= in_cb;           // 色度保持不变
            out_cr <= in_cr;
            out_hs <= in_hs;
            out_vs <= in_vs;
            out_de <= in_de;
        end
    end
endmodule