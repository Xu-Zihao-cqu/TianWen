module image_stats #(
    parameter H_ACTIVE    = 1280,
    parameter V_ACTIVE    = 720,
    parameter AE_X_MARGIN = 160,
    parameter AE_Y_MARGIN = 90,
    parameter DARK_Y      = 40,
    parameter BRIGHT_Y    = 220
)(
    input  wire       clk,
    input  wire       rst_n,
    input  wire [7:0] y_in,
    input  wire       de_in,
    input  wire       vs_in,
    output reg  [1:0] mode,      // 00: normal, 01: highlight compression, 10: low-light lift
    output reg  [1:0] strength   // 00/01/10/11: 25%/50%/75%/100% blend strength
);

    // Frame coordinates are derived from the real video sync instead of assuming
    // an exact number of valid pixels. Statistics use a centered metering window,
    // which avoids letting black borders or bright edge objects dominate exposure.
    reg vs_d;
    wire frame_start = vs_in & ~vs_d;

    reg [10:0] x_cnt;
    reg [9:0]  y_cnt;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            vs_d  <= 1'b0;
            x_cnt <= 11'd0;
            y_cnt <= 10'd0;
        end else begin
            vs_d <= vs_in;
            if (frame_start) begin
                x_cnt <= 11'd0;
                y_cnt <= 10'd0;
            end else if (de_in) begin
                if (x_cnt == H_ACTIVE - 1) begin
                    x_cnt <= 11'd0;
                    if (y_cnt == V_ACTIVE - 1)
                        y_cnt <= 10'd0;
                    else
                        y_cnt <= y_cnt + 10'd1;
                end else begin
                    x_cnt <= x_cnt + 11'd1;
                end
            end
        end
    end

    wire in_meter_window =
        (x_cnt >= AE_X_MARGIN) && (x_cnt < H_ACTIVE - AE_X_MARGIN) &&
        (y_cnt >= AE_Y_MARGIN) && (y_cnt < V_ACTIVE - AE_Y_MARGIN);

    // 1/8 spatial sampling (one pixel in four horizontally and one line in two)
    // keeps the counters small while retaining more than enough exposure samples.
    wire sample_en = de_in && in_meter_window &&
                     (x_cnt[1:0] == 2'b00) && (y_cnt[0] == 1'b0);

    reg [23:0] y_sum;
    reg [16:0] sample_count;
    reg [16:0] dark_count;
    reg [16:0] bright_count;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            y_sum        <= 24'd0;
            sample_count <= 17'd0;
            dark_count   <= 17'd0;
            bright_count <= 17'd0;
        end else if (frame_start) begin
            y_sum        <= 24'd0;
            sample_count <= 17'd0;
            dark_count   <= 17'd0;
            bright_count <= 17'd0;
        end else if (sample_en) begin
            y_sum <= y_sum + y_in;
            if (sample_count != 17'h1ffff)
                sample_count <= sample_count + 17'd1;
            if ((y_in <= DARK_Y) && (dark_count != 17'h1ffff))
                dark_count <= dark_count + 17'd1;
            if ((y_in >= BRIGHT_Y) && (bright_count != 17'h1ffff))
                bright_count <= bright_count + 17'd1;
        end
    end

    // Compare sum(Y) directly against sample_count * target_mean. Constant
    // multiplication is expressed as shifts/adds, so no divider is required.
    wire [24:0] count_ext = {8'd0, sample_count};
    wire [24:0] mean_48  = (count_ext << 5) + (count_ext << 4);
    wire [24:0] mean_64  = (count_ext << 6);
    wire [24:0] mean_72  = (count_ext << 6) + (count_ext << 3);
    wire [24:0] mean_92  = (count_ext << 6) + (count_ext << 4) +
                           (count_ext << 3) + (count_ext << 2);
    wire [24:0] mean_105 = (count_ext << 6) + (count_ext << 5) +
                           (count_ext << 3) + count_ext;
    wire [24:0] mean_140 = (count_ext << 7) + (count_ext << 3) +
                           (count_ext << 2);
    wire [24:0] mean_145 = (count_ext << 7) + (count_ext << 4) + count_ext;
    wire [24:0] mean_168 = (count_ext << 7) + (count_ext << 5) +
                           (count_ext << 3);
    wire [24:0] mean_180 = (count_ext << 7) + (count_ext << 5) +
                           (count_ext << 4) + (count_ext << 2);
    wire [24:0] mean_195 = (count_ext << 7) + (count_ext << 6) +
                           (count_ext << 1) + count_ext;
    wire [24:0] sum_ext  = {1'b0, y_sum};

    wire [16:0] one_sixteenth = sample_count >> 4;
    wire [16:0] one_eighth    = sample_count >> 3;
    wire [16:0] one_quarter   = sample_count >> 2;
    wire [16:0] three_eighths = (sample_count >> 2) + (sample_count >> 3);
    wire [16:0] one_half      = sample_count >> 1;

    wire stats_valid = (sample_count >= 17'd1024);

    wire high_enter = (sum_ext > mean_168) ||
                      ((bright_count >= one_eighth) && (sum_ext > mean_140));
    wire high_exit  = (sum_ext < mean_145) &&
                      (bright_count < one_sixteenth);

    wire low_enter  = (sum_ext < mean_72) ||
                      ((dark_count >= three_eighths) && (sum_ext < mean_105));
    wire low_exit   = (sum_ext > mean_92) &&
                      (dark_count < one_quarter);

    reg [1:0] desired_mode;
    reg [1:0] desired_strength;

    always @(*) begin
        desired_mode = mode;
        case (mode)
            2'b00: begin
                if (high_enter)
                    desired_mode = 2'b01;
                else if (low_enter)
                    desired_mode = 2'b10;
            end
            2'b01: begin
                if (high_exit)
                    desired_mode = 2'b00;
            end
            2'b10: begin
                if (low_exit)
                    desired_mode = 2'b00;
            end
            default: desired_mode = 2'b00;
        endcase

        desired_strength = 2'b00;
        if (desired_mode == 2'b01) begin
            if ((sum_ext > mean_195) || (bright_count >= one_quarter))
                desired_strength = 2'b11;
            else if ((sum_ext > mean_180) || (bright_count >= one_eighth))
                desired_strength = 2'b10;
            else
                desired_strength = 2'b01;
        end else if (desired_mode == 2'b10) begin
            if ((sum_ext < mean_48) || (dark_count >= one_half))
                desired_strength = 2'b11;
            else if ((sum_ext < mean_64) || (dark_count >= three_eighths))
                desired_strength = 2'b10;
            else
                desired_strength = 2'b01;
        end
    end

    // Two-frame confirmation prevents mode chatter. Strength is slewed by one
    // step per frame so the visible tone curve changes smoothly.
    reg [1:0] pending_mode;
    reg       pending_seen;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            mode         <= 2'b00;
            strength     <= 2'b00;
            pending_mode <= 2'b00;
            pending_seen <= 1'b0;
        end else if (frame_start && stats_valid) begin
            if (desired_mode == mode) begin
                pending_seen <= 1'b0;
                if (mode == 2'b00) begin
                    strength <= 2'b00;
                end else if (strength < desired_strength) begin
                    strength <= strength + 2'b01;
                end else if (strength > desired_strength) begin
                    strength <= strength - 2'b01;
                end
            end else if (pending_seen && (pending_mode == desired_mode)) begin
                mode         <= desired_mode;
                strength     <= 2'b00;
                pending_seen <= 1'b0;
            end else begin
                pending_mode <= desired_mode;
                pending_seen <= 1'b1;
            end
        end
    end

endmodule
