module gesture_recognizer #(
    parameter H_ACTIVE = 1280,
    parameter V_ACTIVE = 720,

    // 固定检测区：尽量只让手进入该区域，避免脸和背景参与检测
    parameter ROI_X_MIN = 680,
    parameter ROI_X_MAX = 1230,
    parameter ROI_Y_MIN = 30,
    parameter ROI_Y_MAX = 700,

    // YCbCr 肤色阈值：面向中国用户样本做偏保守标定。
    // 中国用户在常见室内光下手部肤色通常表现为 Cb 偏低、Cr 偏高、Cr-Cb 为正。
    // 这里收紧 Cb/Cr 和 Cr-Cb 差值，主要是为了降低米黄色墙面、木桌、暖色灯光背景误判为手。
    // 若现场偏暗，可优先把 SKIN_Y_MIN 降到 35~40；若手部漏检，可先把 SKIN_CR_MIN 降到 132。
    parameter SKIN_Y_MIN  = 45,
    parameter SKIN_Y_MAX  = 235,
    parameter SKIN_CB_MIN = 80,
    parameter SKIN_CB_MAX = 125,
    parameter SKIN_CR_MIN = 134,
    parameter SKIN_CR_MAX = 176,
    parameter CR_CB_GAP    = 14,

    // 一行至少包含多少肤色像素/跨度，才认为这一行属于手，而不是噪点
    parameter ROW_MIN_SKIN = 12,
    parameter ROW_MIN_SPAN = 18,
    parameter ROW_GAP_TOL  = 2,

    // 手区域最小约束
    parameter MIN_SKIN_AREA   = 1200,
    parameter MIN_HAND_WIDTH  = 70,
    parameter MIN_HAND_HEIGHT = 80,

    // 现实场景增强参数：短时漏检保持、快速移动时手框直接跟随、
    // 拳头解除前保持少量帧，避免拳头阴影瞬间被误识别成手指。
    parameter HAND_MISS_TOL    = 2,
    parameter BOX_SNAP_DELTA   = 48,
    parameter FIST_HOLD_FRAMES = 2,

    // 默认保留真实增强画面，仅叠加手框；扫描线和肤色掩膜可独立开启。
    parameter SHOW_SCAN_LINES = 0,
    parameter SHOW_HAND_BOX   = 1,
    parameter SHOW_SKIN_MASK  = 0,

    // 扫描线中允许的小黑洞宽度
    parameter GAP_TOL = 8,

    // 7 帧投票窗口的三级门限。首次获得有效手势只需简单多数，
    // 已有稳定结果后切换/清零使用更高门限，形成时间滞回。
    parameter VOTE_ACQUIRE_MIN = 4,
    parameter VOTE_SWITCH_MIN  = 5,
    parameter VOTE_RELEASE_MIN = 5
)(
    input  wire        clk,
    input  wire        rst_n,

    input  wire [7:0]  in_y,
    input  wire [7:0]  in_cb,
    input  wire [7:0]  in_cr,
    input  wire        in_hs,
    input  wire        in_vs,
    input  wire        in_de,

    output reg  [7:0]  out_y,
    output reg  [7:0]  out_cb,
    output reg  [7:0]  out_cr,
    output reg         out_hs,
    output reg         out_vs,
    output reg         out_de,
    output reg  [3:0]  led
);

    // ================================================================
    // 1. 使用真实 VSYNC 建立帧坐标，不能再用 921600 个像素猜帧尾
    // ================================================================
    reg vs_d;
    wire frame_start = in_vs & ~vs_d;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n)
            vs_d <= 1'b0;
        else
            vs_d <= in_vs;
    end

    reg [10:0] x_cnt;
    reg [9:0]  y_cnt;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            x_cnt <= 11'd0;
            y_cnt <= 10'd0;
        end else if (frame_start) begin
            x_cnt <= 11'd0;
            y_cnt <= 10'd0;
        end else if (in_de) begin
            if (x_cnt == H_ACTIVE - 1) begin
                x_cnt <= 11'd0;
                if (y_cnt == V_ACTIVE - 1)
                    y_cnt <= 10'd0;
                else
                    y_cnt <= y_cnt + 10'd1;
            end else begin
                x_cnt <= x_cnt + 11'd1;
            end
        end
    end

    wire line_end = in_de && (x_cnt == H_ACTIVE - 1);

    // ================================================================
    // 2. 肤色判定：亮度范围 + Cb/Cr 矩形 + Cr-Cb 关系
    // ================================================================
    wire in_roi = (x_cnt >= ROI_X_MIN) && (x_cnt <= ROI_X_MAX) &&
                  (y_cnt >= ROI_Y_MIN) && (y_cnt <= ROI_Y_MAX);

    // 核心肤色模型保持偏保守；同时增加仅在阴影/高光亮度区间启用的
    // 小范围扩展模型。这样能改善高亮照明场景中的强反光和手部阴影下的断裂，
    // 又不会在正常亮度下无条件放宽色度阈值。
    wire skin_chroma_core =
                    (in_cb >= SKIN_CB_MIN) && (in_cb <= SKIN_CB_MAX) &&
                    (in_cr >= SKIN_CR_MIN) && (in_cr <= SKIN_CR_MAX) &&
                    ({1'b0, in_cr} > ({1'b0, in_cb} + CR_CB_GAP));

    wire skin_chroma_shadow =
                    (in_y  >= 8'd35) && (in_y < SKIN_Y_MIN) &&
                    (in_cb >= 8'd82) && (in_cb <= 8'd130) &&
                    (in_cr >= 8'd132) && (in_cr <= 8'd182) &&
                    ({1'b0, in_cr} > ({1'b0, in_cb} + 9'd10));

    wire skin_chroma_highlight =
                    (in_y  > SKIN_Y_MAX) && (in_y <= 8'd245) &&
                    (in_cb >= 8'd88) && (in_cb <= 8'd132) &&
                    (in_cr >= 8'd128) && (in_cr <= 8'd172) &&
                    ({1'b0, in_cr} > ({1'b0, in_cb} + 9'd6));

    wire skin_raw = in_de && in_roi &&
                    (((in_y >= SKIN_Y_MIN) && (in_y <= SKIN_Y_MAX) &&
                      skin_chroma_core) ||
                     skin_chroma_shadow || skin_chroma_highlight);

    // 水平方向 3 点多数滤波：去掉孤立白点，同时填补单像素黑洞。
    // 当前时刻得到的结果对应 x_cnt-1 像素。
    reg skin_d1;
    reg skin_d2;
    wire skin_filter_valid = in_de && (x_cnt != 0);
    wire [10:0] skin_filter_x = x_cnt - 11'd1;
    wire skin_filtered = skin_filter_valid &&
                         ((skin_d2 & skin_d1) |
                          (skin_d2 & skin_raw) |
                          (skin_d1 & skin_raw));

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            skin_d1 <= 1'b0;
            skin_d2 <= 1'b0;
        end else if (frame_start) begin
            skin_d1 <= 1'b0;
            skin_d2 <= 1'b0;
        end else if (in_de) begin
            if (line_end) begin
                skin_d1 <= 1'b0;
                skin_d2 <= 1'b0;
            end else begin
                skin_d2 <= skin_d1;
                skin_d1 <= skin_raw;
            end
        end
    end

    // ================================================================
    // 3. 行级过滤 + 最大连续行带
    //
    // 原算法只要一个肤色噪点就会改变 y_min/y_max。
    // 这里先判断“整行是否像手”，再从一帧中选择面积最大的连续行带。
    // ================================================================
    reg [10:0] row_skin_count;
    reg        row_has_skin;
    reg [10:0] row_x_min;
    reg [10:0] row_x_max;

    wire [10:0] row_skin_final = row_skin_count + (skin_filtered ? 11'd1 : 11'd0);
    wire        row_has_final  = row_has_skin | skin_filtered;
    wire [10:0] row_x_min_final = row_has_skin ? row_x_min :
                                    (skin_filtered ? skin_filter_x : 11'd0);
    wire [10:0] row_x_max_final = skin_filtered ? skin_filter_x : row_x_max;
    wire [10:0] row_span_final  = row_has_final ?
                                    (row_x_max_final - row_x_min_final + 11'd1) : 11'd0;

    // 肤色像素至少占跨度的 1/4，排除一行中到处散落的肤色噪点。
    wire row_valid_final = (y_cnt >= ROI_Y_MIN) && (y_cnt <= ROI_Y_MAX) &&
                           (row_skin_final >= ROW_MIN_SKIN) &&
                           (row_span_final >= ROW_MIN_SPAN) &&
                           ({row_skin_final, 2'b00} >= {2'b00, row_span_final});

    reg        band_active;
    reg [19:0] band_area;
    reg [10:0] band_x_min;
    reg [10:0] band_x_max;
    reg [9:0]  band_y_min;
    reg [9:0]  band_y_max;
    reg [3:0]  band_gap;

    reg [19:0] best_area;
    reg [10:0] best_x_min;
    reg [10:0] best_x_max;
    reg [9:0]  best_y_min;
    reg [9:0]  best_y_max;

    // 正常情况下 ROI 下方的无效行会结束 band；下面仍兼容帧尾时 band 未结束的情况。
    wire use_live_band = band_active && (band_area > best_area);
    wire [19:0] selected_area  = use_live_band ? band_area  : best_area;
    wire [10:0] selected_x_min = use_live_band ? band_x_min : best_x_min;
    wire [10:0] selected_x_max = use_live_band ? band_x_max : best_x_max;
    wire [9:0]  selected_y_min = use_live_band ? band_y_min : best_y_min;
    wire [9:0]  selected_y_max = use_live_band ? band_y_max : best_y_max;

    wire [10:0] selected_width  = (selected_x_max >= selected_x_min) ?
                                  (selected_x_max - selected_x_min + 11'd1) : 11'd0;
    wire [9:0]  selected_height = (selected_y_max >= selected_y_min) ?
                                  (selected_y_max - selected_y_min + 10'd1) : 10'd0;

    // 胳膊/手腕误检抑制：单纯胳膊通常是很细很长的一条肤色带，
    // 而手掌/拳头/伸指手势的外接框不会出现极端长宽比。
    // 这里只做温和几何门限，避免破坏 1/2/3 指的原有识别。
    wire selected_shape_valid =
        ({3'b000, selected_height} <= ({2'b00, selected_width} << 2)) &&
        ({2'b00, selected_width}  <= (({3'b000, selected_height} << 2) + {3'b000, selected_height}));

    // 当前帧是否真的检测到手。后面的手指数统计和 LED 输出都必须受它约束，
    // 否则“上一帧的稳定结果”会在手离开后继续点亮 LED。
    wire selected_hand_valid = (selected_area >= MIN_SKIN_AREA) &&
                               (selected_width >= MIN_HAND_WIDTH) &&
                               (selected_height >= MIN_HAND_HEIGHT) &&
                               selected_shape_valid;

    reg [10:0] hand_x_min;
    reg [10:0] hand_x_max;
    reg [9:0]  hand_y_min;
    reg [9:0]  hand_y_max;
    reg        hand_valid;
    reg [2:0]  hand_miss_count;

    wire box_jump_large =
        (selected_x_min > hand_x_min + BOX_SNAP_DELTA) ||
        (hand_x_min > selected_x_min + BOX_SNAP_DELTA) ||
        (selected_x_max > hand_x_max + BOX_SNAP_DELTA) ||
        (hand_x_max > selected_x_max + BOX_SNAP_DELTA) ||
        (selected_y_min > hand_y_min + BOX_SNAP_DELTA) ||
        (hand_y_min > selected_y_min + BOX_SNAP_DELTA) ||
        (selected_y_max > hand_y_max + BOX_SNAP_DELTA) ||
        (hand_y_max > selected_y_max + BOX_SNAP_DELTA);

    // 一两帧分割中断时仍允许使用上一帧手框和本帧扫描结果，避免
    // 强反光或运动模糊造成 LED 与手框闪烁。
    wire decision_hand_valid = selected_hand_valid ||
                               (hand_valid && (hand_miss_count < HAND_MISS_TOL));

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            row_skin_count <= 11'd0;
            row_has_skin   <= 1'b0;
            row_x_min      <= 11'd0;
            row_x_max      <= 11'd0;

            band_active <= 1'b0;
            band_area   <= 20'd0;
            band_x_min  <= 11'd0;
            band_x_max  <= 11'd0;
            band_y_min  <= 10'd0;
            band_y_max  <= 10'd0;
            band_gap    <= 4'd0;

            best_area  <= 20'd0;
            best_x_min <= 11'd0;
            best_x_max <= 11'd0;
            best_y_min <= 10'd0;
            best_y_max <= 10'd0;

            hand_x_min <= 11'd0;
            hand_x_max <= 11'd0;
            hand_y_min <= 10'd0;
            hand_y_max <= 10'd0;
            hand_valid <= 1'b0;
            hand_miss_count <= 3'd0;
        end else if (frame_start) begin
            // 锁存上一帧最大的连续肤色区域，供当前帧扫描。
            if (selected_hand_valid) begin
                hand_miss_count <= 3'd0;
                if (hand_valid && !box_jump_large) begin
                    // 小幅变化做 1/2 帧间平滑；快速移动或距离突变时直接
                    // 跟随新手框，避免平滑滞后导致扫描线落到手外。
                    hand_x_min <= ({1'b0, hand_x_min} + {1'b0, selected_x_min}) >> 1;
                    hand_x_max <= ({1'b0, hand_x_max} + {1'b0, selected_x_max}) >> 1;
                    hand_y_min <= ({1'b0, hand_y_min} + {1'b0, selected_y_min}) >> 1;
                    hand_y_max <= ({1'b0, hand_y_max} + {1'b0, selected_y_max}) >> 1;
                end else begin
                    hand_x_min <= selected_x_min;
                    hand_x_max <= selected_x_max;
                    hand_y_min <= selected_y_min;
                    hand_y_max <= selected_y_max;
                end
                hand_valid <= 1'b1;
            end else if (hand_valid && (hand_miss_count < HAND_MISS_TOL)) begin
                hand_miss_count <= hand_miss_count + 3'd1;
                hand_valid <= 1'b1;
            end else begin
                hand_miss_count <= 3'd0;
                hand_valid <= 1'b0;
            end

            row_skin_count <= 11'd0;
            row_has_skin   <= 1'b0;
            row_x_min      <= 11'd0;
            row_x_max      <= 11'd0;

            band_active <= 1'b0;
            band_area   <= 20'd0;
            band_x_min  <= 11'd0;
            band_x_max  <= 11'd0;
            band_y_min  <= 10'd0;
            band_y_max  <= 10'd0;
            band_gap    <= 4'd0;

            best_area  <= 20'd0;
            best_x_min <= 11'd0;
            best_x_max <= 11'd0;
            best_y_min <= 10'd0;
            best_y_max <= 10'd0;
        end else if (in_de) begin
            if (line_end) begin
                // 完成当前行后，先做行合法性判断，再维护连续行带。
                if (row_valid_final) begin
                    band_gap <= 4'd0;
                    if (!band_active) begin
                        band_active <= 1'b1;
                        band_area   <= row_skin_final;
                        band_x_min  <= row_x_min_final;
                        band_x_max  <= row_x_max_final;
                        band_y_min  <= y_cnt;
                        band_y_max  <= y_cnt;
                    end else begin
                        band_area  <= band_area + row_skin_final;
                        band_y_max <= y_cnt;
                        if (row_x_min_final < band_x_min)
                            band_x_min <= row_x_min_final;
                        if (row_x_max_final > band_x_max)
                            band_x_max <= row_x_max_final;
                    end
                end else if (band_active) begin
                    // 允许连续少量坏行，防止一条噪声行把手区域从中间切断。
                    if (band_gap < ROW_GAP_TOL) begin
                        band_gap <= band_gap + 4'd1;
                    end else begin
                        if (band_area > best_area) begin
                            best_area  <= band_area;
                            best_x_min <= band_x_min;
                            best_x_max <= band_x_max;
                            best_y_min <= band_y_min;
                            best_y_max <= band_y_max;
                        end
                        band_active <= 1'b0;
                        band_area   <= 20'd0;
                        band_gap    <= 4'd0;
                    end
                end

                row_skin_count <= 11'd0;
                row_has_skin   <= 1'b0;
                row_x_min      <= 11'd0;
                row_x_max      <= 11'd0;
            end else if (skin_filtered) begin
                if (row_skin_count != 11'h7ff)
                    row_skin_count <= row_skin_count + 11'd1;
                if (!row_has_skin) begin
                    row_has_skin <= 1'b1;
                    row_x_min    <= skin_filter_x;
                    row_x_max    <= skin_filter_x;
                end else begin
                    if (skin_filter_x < row_x_min)
                        row_x_min <= skin_filter_x;
                    if (skin_filter_x > row_x_max)
                        row_x_max <= skin_filter_x;
                end
            end
        end
    end

    // ================================================================
    // 4. 五条扫描线统计手指。每条线只数合格的连续肤色段，
    //    允许小黑洞，但不会把掌心等超宽区域误认为多根手指。
    // ================================================================
    wire [9:0]  hand_height = hand_y_max - hand_y_min + 10'd1;
    wire [10:0] hand_width  = hand_x_max - hand_x_min + 11'd1;

    // 前 5 条线位于手框上部用于数手指；第 6 条线位于 5/8 高度，
    // 作为掌心密度参考。拳头上部与掌心都很紧密，而张开的手指区
    // 相对掌心会出现明显空隙，这是抑制拳头误判的关键特征。
    wire [9:0] scan_y0 = hand_y_min + (hand_height >> 3);
    wire [9:0] scan_y1 = hand_y_min + (hand_height >> 3) + (hand_height >> 4);
    wire [9:0] scan_y2 = hand_y_min + (hand_height >> 2);
    wire [9:0] scan_y3 = hand_y_min + (hand_height >> 2) + (hand_height >> 4);
    wire [9:0] scan_y4 = hand_y_min + (hand_height >> 2) + (hand_height >> 3);
    wire [9:0] scan_y5 = hand_y_min + (hand_height >> 1) + (hand_height >> 3);

    wire [10:0] scan_x_lo = (hand_x_min > ROI_X_MIN + 12) ?
                            (hand_x_min - 11'd12) : ROI_X_MIN;
    wire [10:0] scan_x_hi = (hand_x_max + 11'd12 < ROI_X_MAX) ?
                            (hand_x_max + 11'd12) : ROI_X_MAX;

    wire is_finger_scan_y = hand_valid &&
                     ((y_cnt == scan_y0) || (y_cnt == scan_y1) ||
                      (y_cnt == scan_y2) || (y_cnt == scan_y3) ||
                      (y_cnt == scan_y4));
    wire is_scan_y = is_finger_scan_y || (hand_valid && (y_cnt == scan_y5));

    wire scan_start = skin_filter_valid && is_scan_y && (skin_filter_x == scan_x_lo);
    wire scan_body  = skin_filter_valid && is_scan_y &&
                      (skin_filter_x > scan_x_lo) && (skin_filter_x <= scan_x_hi);
    // x_hi 最大 1230，因此 x_hi+1 仍处于 1280 像素有效区内。
    wire scan_flush = skin_filter_valid && is_scan_y &&
                      (skin_filter_x == scan_x_hi + 11'd1);

    reg        run_active;
    reg [10:0] run_skin_width;
    reg [10:0] run_span_width;
    reg [3:0]  run_gap;
    reg [2:0]  line_fingers;

    reg [3:0] line_count0;
    reg [3:0] line_count1;
    reg [3:0] line_count2;
    reg [3:0] line_count3;
    reg [3:0] line_count4;
    reg [3:0] line_count5;

    // 每条扫描线的肤色总量，用于区分“张开的手指”和
    // “拳头/手臂上的碎裂肤色块”。拳头通常肤色密度很高，
    // 只是被阴影切成多段；张开手指则会有明显黑色间隙。
    reg [10:0] line_skin_total;
    reg [10:0] line_skin0;
    reg [10:0] line_skin1;
    reg [10:0] line_skin2;
    reg [10:0] line_skin3;
    reg [10:0] line_skin4;
    reg [10:0] line_skin5;

    function [2:0] classify_run;
        input [10:0] skin_w;
        input [10:0] span_w;
        input [10:0] hand_w;
        reg   [10:0] min_w;
        reg   [10:0] max_w;
        begin
            // 最小宽度随手框增大，范围限制在 4~14 像素。
            min_w = hand_w >> 5;
            if (min_w < 11'd4)
                min_w = 11'd4;
            else if (min_w > 11'd14)
                min_w = 11'd14;

            // 最大单指宽度约为手框 1/4，范围限制在 25~110 像素。
            max_w = hand_w >> 2;
            if (max_w < 11'd25)
                max_w = 11'd25;
            else if (max_w > 11'd110)
                max_w = 11'd110;

            if ((skin_w >= min_w) && (skin_w <= max_w) &&
                ({skin_w, 1'b0} >= {1'b0, span_w}))
                classify_run = 3'd1;
            else
                classify_run = 3'd0;
        end
    endfunction

    function [2:0] sat_add5;
        input [2:0] a;
        input [2:0] b;
        reg   [3:0] s;
        begin
            s = a + b;
            if (s > 4'd5)
                sat_add5 = 3'd5;
            else
                sat_add5 = s[2:0];
        end
    endfunction

    wire [2:0] run_value = classify_run(run_skin_width, run_span_width, hand_width);
    wire [2:0] line_value_with_tail = sat_add5(line_fingers, run_value);

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            run_active    <= 1'b0;
            run_skin_width <= 11'd0;
            run_span_width <= 11'd0;
            run_gap        <= 4'd0;
            line_fingers   <= 3'd0;
            line_count0    <= 4'd0;
            line_count1    <= 4'd0;
            line_count2    <= 4'd0;
            line_count3    <= 4'd0;
            line_count4    <= 4'd0;
            line_count5    <= 4'd0;
            line_skin_total <= 11'd0;
            line_skin0      <= 11'd0;
            line_skin1      <= 11'd0;
            line_skin2      <= 11'd0;
            line_skin3      <= 11'd0;
            line_skin4      <= 11'd0;
            line_skin5      <= 11'd0;
        end else if (frame_start) begin
            run_active    <= 1'b0;
            run_skin_width <= 11'd0;
            run_span_width <= 11'd0;
            run_gap        <= 4'd0;
            line_fingers   <= 3'd0;
            line_count0    <= 4'd0;
            line_count1    <= 4'd0;
            line_count2    <= 4'd0;
            line_count3    <= 4'd0;
            line_count4    <= 4'd0;
            line_count5    <= 4'd0;
            line_skin_total <= 11'd0;
            line_skin0      <= 11'd0;
            line_skin1      <= 11'd0;
            line_skin2      <= 11'd0;
            line_skin3      <= 11'd0;
            line_skin4      <= 11'd0;
            line_skin5      <= 11'd0;
        end else if (scan_start) begin
            line_fingers    <= 3'd0;
            run_gap         <= 4'd0;
            line_skin_total <= skin_filtered ? 11'd1 : 11'd0;
            if (skin_filtered) begin
                run_active     <= 1'b1;
                run_skin_width <= 11'd1;
                run_span_width <= 11'd1;
            end else begin
                run_active     <= 1'b0;
                run_skin_width <= 11'd0;
                run_span_width <= 11'd0;
            end
        end else if (scan_body) begin
            if (skin_filtered) begin
                if (line_skin_total != 11'h7ff)
                    line_skin_total <= line_skin_total + 11'd1;
                if (!run_active) begin
                    run_active     <= 1'b1;
                    run_skin_width <= 11'd1;
                    run_span_width <= 11'd1;
                end else begin
                    if (run_skin_width != 11'h7ff)
                        run_skin_width <= run_skin_width + 11'd1;
                    if (run_span_width != 11'h7ff)
                        run_span_width <= run_span_width + 11'd1;
                end
                run_gap <= 4'd0;
            end else if (run_active) begin
                if (run_gap < GAP_TOL) begin
                    run_gap <= run_gap + 4'd1;
                    if (run_span_width != 11'h7ff)
                        run_span_width <= run_span_width + 11'd1;
                end else begin
                    line_fingers  <= sat_add5(line_fingers, run_value);
                    run_active     <= 1'b0;
                    run_skin_width <= 11'd0;
                    run_span_width <= 11'd0;
                    run_gap        <= 4'd0;
                end
            end
        end else if (scan_flush) begin
            if (y_cnt == scan_y0) begin
                line_count0 <= {1'b0, line_value_with_tail};
                line_skin0  <= line_skin_total;
            end else if (y_cnt == scan_y1) begin
                line_count1 <= {1'b0, line_value_with_tail};
                line_skin1  <= line_skin_total;
            end else if (y_cnt == scan_y2) begin
                line_count2 <= {1'b0, line_value_with_tail};
                line_skin2  <= line_skin_total;
            end else if (y_cnt == scan_y3) begin
                line_count3 <= {1'b0, line_value_with_tail};
                line_skin3  <= line_skin_total;
            end else if (y_cnt == scan_y4) begin
                line_count4 <= {1'b0, line_value_with_tail};
                line_skin4  <= line_skin_total;
            end else begin
                line_count5 <= {1'b0, line_value_with_tail};
                line_skin5  <= line_skin_total;
            end

            run_active      <= 1'b0;
            run_skin_width  <= 11'd0;
            run_span_width  <= 11'd0;
            run_gap         <= 4'd0;
            line_fingers    <= 3'd0;
            line_skin_total <= 11'd0;
        end
    end

    function [3:0] median5;
        input [3:0] a;
        input [3:0] b;
        input [3:0] c;
        input [3:0] d;
        input [3:0] e;
        reg [3:0] v0, v1, v2, v3, v4, t;
        begin
            v0 = a; v1 = b; v2 = c; v3 = d; v4 = e;
            if (v0 > v1) begin t=v0; v0=v1; v1=t; end
            if (v1 > v2) begin t=v1; v1=v2; v2=t; end
            if (v2 > v3) begin t=v2; v2=v3; v3=t; end
            if (v3 > v4) begin t=v3; v3=v4; v4=t; end
            if (v0 > v1) begin t=v0; v0=v1; v1=t; end
            if (v1 > v2) begin t=v1; v1=v2; v2=t; end
            if (v2 > v3) begin t=v2; v2=v3; v3=t; end
            if (v0 > v1) begin t=v0; v0=v1; v1=t; end
            if (v1 > v2) begin t=v1; v1=v2; v2=t; end
            if (v0 > v1) begin t=v0; v0=v1; v1=t; end
            median5 = v2;
        end
    endfunction

    // 5 条扫描线的普通中位数会偏向较低的统计值：
    // 五指张开时，下方扫描线经常已经并入掌心，只能数到 2~3 段，
    // 导致 median5 输出 3。这里改取“第二大值”，要求至少两条线支持高计数，
    // 同时避免单条噪声线直接决定结果。
    function [3:0] second_largest5;
        input [3:0] a;
        input [3:0] b;
        input [3:0] c;
        input [3:0] d;
        input [3:0] e;
        reg [3:0] v0, v1, v2, v3, v4, t;
        begin
            v0 = a; v1 = b; v2 = c; v3 = d; v4 = e;
            if (v0 > v1) begin t=v0; v0=v1; v1=t; end
            if (v1 > v2) begin t=v1; v1=v2; v2=t; end
            if (v2 > v3) begin t=v2; v2=v3; v3=t; end
            if (v3 > v4) begin t=v3; v3=v4; v4=t; end
            if (v0 > v1) begin t=v0; v0=v1; v1=t; end
            if (v1 > v2) begin t=v1; v1=v2; v2=t; end
            if (v2 > v3) begin t=v2; v2=v3; v3=t; end
            if (v0 > v1) begin t=v0; v0=v1; v1=t; end
            if (v1 > v2) begin t=v1; v1=v2; v2=t; end
            if (v0 > v1) begin t=v0; v0=v1; v1=t; end
            second_largest5 = v3;
        end
    endfunction

    wire [10:0] scan_width = (scan_x_hi >= scan_x_lo) ?
                             (scan_x_hi - scan_x_lo + 11'd1) : 11'd0;

    // 拳头特征采用“段数 + 密度 + 掌心参考”联合判断：
    // 1) 紧密拳头通常在上部多条线都占据较高比例；
    // 2) 阴影可能把拳头切成 3 段以上，但总肤色密度仍然很高；
    // 3) 张开手指的上部密度通常明显低于 5/8 高度的掌心参考线。
    function dense_three_eighths_line;
        input [10:0] skin_sum;
        input [10:0] width_sum;
        begin
            dense_three_eighths_line = ({skin_sum, 3'b000} >=
                                        ({width_sum, 1'b0} + width_sum));
        end
    endfunction

    function dense_half_line;
        input [10:0] skin_sum;
        input [10:0] width_sum;
        begin
            dense_half_line = ({skin_sum, 1'b0} >= {1'b0, width_sum});
        end
    endfunction

    function low_count_dense_line;
        input [3:0]  cnt;
        input [10:0] skin_sum;
        input [10:0] width_sum;
        begin
            low_count_dense_line = (cnt <= 4'd2) &&
                                   dense_three_eighths_line(skin_sum, width_sum);
        end
    endfunction

    function fragment_dense_line;
        input [3:0]  cnt;
        input [10:0] skin_sum;
        input [10:0] width_sum;
        begin
            fragment_dense_line = (cnt >= 4'd3) &&
                                  dense_half_line(skin_sum, width_sum);
        end
    endfunction

    function palm_like_line;
        input [10:0] skin_sum;
        input [10:0] palm_sum;
        begin
            // 上部线达到掌心肤色量的 3/4，说明轮廓更接近紧凑拳头。
            palm_like_line = ({skin_sum, 2'b00} >=
                              ({1'b0, palm_sum, 1'b0} + {2'b00, palm_sum}));
        end
    endfunction

    function near_palm_line;
        input [10:0] skin_sum;
        input [10:0] palm_sum;
        begin
            // 阴影碎裂拳头使用更严格的 7/8 掌心密度门限。真正张开的
            // 三至五指即使靠近镜头，指间空隙通常仍会降低上部总占空比。
            near_palm_line = ({skin_sum, 3'b000} >=
                              (({palm_sum, 3'b000}) - {2'b00, palm_sum}));
        end
    endfunction

    // ================================================================
    // 5. 分级流水化帧决策、拳头抑制与七帧滞回投票。
    // 手指数排序、密度特征、候选资格和时间投票分级完成，避免把新增
    // 形状判定重新串成一条超长组合路径。
    // ================================================================
    reg decision_p0, decision_p1, decision_p2;

    reg        valid_s0;
    reg [3:0]  line_count0_s0, line_count1_s0, line_count2_s0;
    reg [3:0]  line_count3_s0, line_count4_s0, line_count5_s0;
    reg [10:0] line_skin0_s0, line_skin1_s0, line_skin2_s0;
    reg [10:0] line_skin3_s0, line_skin4_s0, line_skin5_s0;
    reg [10:0] scan_width_s0;

    wire [3:0] raw_candidate_from_s0 = second_largest5(
        line_count0_s0, line_count1_s0, line_count2_s0,
        line_count3_s0, line_count4_s0);

    wire [2:0] dense_vote_from_s0 =
        {2'b00, dense_three_eighths_line(line_skin0_s0, scan_width_s0)} +
        {2'b00, dense_three_eighths_line(line_skin1_s0, scan_width_s0)} +
        {2'b00, dense_three_eighths_line(line_skin2_s0, scan_width_s0)} +
        {2'b00, dense_three_eighths_line(line_skin3_s0, scan_width_s0)} +
        {2'b00, dense_three_eighths_line(line_skin4_s0, scan_width_s0)};

    wire [2:0] very_dense_vote_from_s0 =
        {2'b00, dense_half_line(line_skin0_s0, scan_width_s0)} +
        {2'b00, dense_half_line(line_skin1_s0, scan_width_s0)} +
        {2'b00, dense_half_line(line_skin2_s0, scan_width_s0)} +
        {2'b00, dense_half_line(line_skin3_s0, scan_width_s0)} +
        {2'b00, dense_half_line(line_skin4_s0, scan_width_s0)};

    wire [2:0] low_count_dense_vote_from_s0 =
        {2'b00, low_count_dense_line(line_count0_s0, line_skin0_s0, scan_width_s0)} +
        {2'b00, low_count_dense_line(line_count1_s0, line_skin1_s0, scan_width_s0)} +
        {2'b00, low_count_dense_line(line_count2_s0, line_skin2_s0, scan_width_s0)} +
        {2'b00, low_count_dense_line(line_count3_s0, line_skin3_s0, scan_width_s0)} +
        {2'b00, low_count_dense_line(line_count4_s0, line_skin4_s0, scan_width_s0)};

    wire [2:0] fragment_dense_vote_from_s0 =
        {2'b00, fragment_dense_line(line_count0_s0, line_skin0_s0, scan_width_s0)} +
        {2'b00, fragment_dense_line(line_count1_s0, line_skin1_s0, scan_width_s0)} +
        {2'b00, fragment_dense_line(line_count2_s0, line_skin2_s0, scan_width_s0)} +
        {2'b00, fragment_dense_line(line_count3_s0, line_skin3_s0, scan_width_s0)} +
        {2'b00, fragment_dense_line(line_count4_s0, line_skin4_s0, scan_width_s0)};

    wire [2:0] palm_like_vote_from_s0 =
        {2'b00, palm_like_line(line_skin0_s0, line_skin5_s0)} +
        {2'b00, palm_like_line(line_skin1_s0, line_skin5_s0)} +
        {2'b00, palm_like_line(line_skin2_s0, line_skin5_s0)} +
        {2'b00, palm_like_line(line_skin3_s0, line_skin5_s0)} +
        {2'b00, palm_like_line(line_skin4_s0, line_skin5_s0)};

    wire [2:0] near_palm_vote_from_s0 =
        {2'b00, near_palm_line(line_skin0_s0, line_skin5_s0)} +
        {2'b00, near_palm_line(line_skin1_s0, line_skin5_s0)} +
        {2'b00, near_palm_line(line_skin2_s0, line_skin5_s0)} +
        {2'b00, near_palm_line(line_skin3_s0, line_skin5_s0)} +
        {2'b00, near_palm_line(line_skin4_s0, line_skin5_s0)};

    wire palm_dense_from_s0 = dense_half_line(line_skin5_s0, scan_width_s0);

    // 强证据：完整紧凑拳头，至少三条线上只有 0~2 个有效段，且上部
    // 密度接近掌心。候选限制在 0~2，避免近距离张开的 3/4/5 指误杀。
    wire strong_fist_from_s0 = palm_dense_from_s0 &&
        (raw_candidate_from_s0 <= 4'd2) &&
        (palm_like_vote_from_s0 >= 3'd3) &&
        (low_count_dense_vote_from_s0 >= 3'd3);

    // 弱证据：阴影把拳头切成多个段。这里使用更严格的 7/8 掌心密度，
    // 并限制第二大段数不超过 3；后级还要求连续两帧确认。
    wire weak_fragment_fist_from_s0 = palm_dense_from_s0 &&
        (raw_candidate_from_s0 <= 4'd3) &&
        (near_palm_vote_from_s0 >= 3'd3) &&
        (fragment_dense_vote_from_s0 >= 3'd2);

    reg        valid_s1;
    reg [3:0]  raw_candidate_s1;
    reg        strong_fist_s1;
    reg        weak_fist_s1;

    reg        valid_s2;
    reg [3:0]  candidate_s2;
    reg        strong_fist_s2;
    reg        weak_fist_s2;

    reg [3:0] hist0, hist1, hist2, hist3, hist4, hist5;
    reg [3:0] stable_fingers;
    reg [2:0] fist_hold;
    reg [1:0] weak_fist_streak;

    function [2:0] count7;
        input [3:0] value;
        input [3:0] a;
        input [3:0] b;
        input [3:0] c;
        input [3:0] d;
        input [3:0] e;
        input [3:0] f;
        input [3:0] g;
        begin
            count7 = {2'b00, (a == value)} + {2'b00, (b == value)} +
                     {2'b00, (c == value)} + {2'b00, (d == value)} +
                     {2'b00, (e == value)} + {2'b00, (f == value)} +
                     {2'b00, (g == value)};
        end
    endfunction

    // 这是移入当前候选值之后的七帧窗口。0 表示“检测到手，但没有
    // 可靠伸指”；无手/拳头强证据在时序逻辑中另行处理。
    wire [2:0] vote0 = count7(4'd0, candidate_s2, hist0, hist1, hist2, hist3, hist4, hist5);
    wire [2:0] vote1 = count7(4'd1, candidate_s2, hist0, hist1, hist2, hist3, hist4, hist5);
    wire [2:0] vote2 = count7(4'd2, candidate_s2, hist0, hist1, hist2, hist3, hist4, hist5);
    wire [2:0] vote3 = count7(4'd3, candidate_s2, hist0, hist1, hist2, hist3, hist4, hist5);
    wire [2:0] vote4 = count7(4'd4, candidate_s2, hist0, hist1, hist2, hist3, hist4, hist5);
    wire [2:0] vote5 = count7(4'd5, candidate_s2, hist0, hist1, hist2, hist3, hist4, hist5);

    reg [2:0] stable_vote_count;
    always @(*) begin
        case (stable_fingers)
            4'd1: stable_vote_count = vote1;
            4'd2: stable_vote_count = vote2;
            4'd3: stable_vote_count = vote3;
            4'd4: stable_vote_count = vote4;
            4'd5: stable_vote_count = vote5;
            default: stable_vote_count = vote0;
        endcase
    end

    reg [2:0] best_votes;
    reg [3:0] voted_fingers;
    always @(*) begin
        // 平票时从当前稳定结果开始比较，并只接受严格更多的票，
        // 因此不会再因平票而偏向 0 或较小的手指数。
        best_votes    = stable_vote_count;
        voted_fingers = stable_fingers;
        if ((stable_fingers != 4'd0) && (vote0 > best_votes)) begin best_votes = vote0; voted_fingers = 4'd0; end
        if ((stable_fingers != 4'd1) && (vote1 > best_votes)) begin best_votes = vote1; voted_fingers = 4'd1; end
        if ((stable_fingers != 4'd2) && (vote2 > best_votes)) begin best_votes = vote2; voted_fingers = 4'd2; end
        if ((stable_fingers != 4'd3) && (vote3 > best_votes)) begin best_votes = vote3; voted_fingers = 4'd3; end
        if ((stable_fingers != 4'd4) && (vote4 > best_votes)) begin best_votes = vote4; voted_fingers = 4'd4; end
        if ((stable_fingers != 4'd5) && (vote5 > best_votes)) begin best_votes = vote5; voted_fingers = 4'd5; end
    end

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            decision_p0 <= 1'b0;
            decision_p1 <= 1'b0;
            decision_p2 <= 1'b0;

            valid_s0 <= 1'b0;
            line_count0_s0 <= 4'd0;
            line_count1_s0 <= 4'd0;
            line_count2_s0 <= 4'd0;
            line_count3_s0 <= 4'd0;
            line_count4_s0 <= 4'd0;
            line_count5_s0 <= 4'd0;
            line_skin0_s0 <= 11'd0;
            line_skin1_s0 <= 11'd0;
            line_skin2_s0 <= 11'd0;
            line_skin3_s0 <= 11'd0;
            line_skin4_s0 <= 11'd0;
            line_skin5_s0 <= 11'd0;
            scan_width_s0 <= 11'd0;

            valid_s1 <= 1'b0;
            raw_candidate_s1 <= 4'd0;
            strong_fist_s1 <= 1'b0;
            weak_fist_s1 <= 1'b0;
            valid_s2 <= 1'b0;
            candidate_s2 <= 4'd0;
            strong_fist_s2 <= 1'b0;
            weak_fist_s2 <= 1'b0;

            hist0 <= 4'd0;
            hist1 <= 4'd0;
            hist2 <= 4'd0;
            hist3 <= 4'd0;
            hist4 <= 4'd0;
            hist5 <= 4'd0;
            stable_fingers <= 4'd0;
            fist_hold <= 3'd0;
            weak_fist_streak <= 2'd0;
        end else begin
            decision_p0 <= frame_start;
            decision_p1 <= decision_p0;
            decision_p2 <= decision_p1;

            // Stage 0: snapshot the completed frame before the scan counters reset.
            if (frame_start) begin
                valid_s0 <= decision_hand_valid;
                line_count0_s0 <= line_count0;
                line_count1_s0 <= line_count1;
                line_count2_s0 <= line_count2;
                line_count3_s0 <= line_count3;
                line_count4_s0 <= line_count4;
                line_count5_s0 <= line_count5;
                line_skin0_s0 <= line_skin0;
                line_skin1_s0 <= line_skin1;
                line_skin2_s0 <= line_skin2;
                line_skin3_s0 <= line_skin3;
                line_skin4_s0 <= line_skin4;
                line_skin5_s0 <= line_skin5;
                scan_width_s0 <= scan_width;
            end

            // Stage 1: 手指数排序与强/弱拳头特征并行计算。
            if (decision_p0) begin
                valid_s1 <= valid_s0;
                raw_candidate_s1 <= raw_candidate_from_s0;
                strong_fist_s1 <= strong_fist_from_s0;
                weak_fist_s1 <= weak_fragment_fist_from_s0;
            end

            // Stage 2: 强拳头候选直接置 0；碎裂型弱证据保留原候选，
            // 由下一阶段做连续两帧确认，避免单帧阴影误杀正常手势。
            if (decision_p1) begin
                valid_s2 <= valid_s1;
                strong_fist_s2 <= valid_s1 && strong_fist_s1;
                weak_fist_s2 <= valid_s1 && weak_fist_s1 && !strong_fist_s1;
                if (!valid_s1 || strong_fist_s1)
                    candidate_s2 <= 4'd0;
                else
                    candidate_s2 <= raw_candidate_s1;
            end

            // Stage 3: 不对称时序滤波。完整拳头立即清零；阴影碎裂型
            // 拳头需连续两帧确认。解除后保持少量帧，正常手势使用
            // 7 帧投票：首次 4/7，切换与普通清零 5/7，平票保持现值。
            if (decision_p2) begin
                if (!valid_s2) begin
                    hist0 <= 4'd0;
                    hist1 <= 4'd0;
                    hist2 <= 4'd0;
                    hist3 <= 4'd0;
                    hist4 <= 4'd0;
                    hist5 <= 4'd0;
                    stable_fingers <= 4'd0;
                    fist_hold <= 3'd0;
                    weak_fist_streak <= 2'd0;
                end else if (strong_fist_s2 ||
                             (weak_fist_s2 && (weak_fist_streak != 2'd0))) begin
                    hist0 <= 4'd0;
                    hist1 <= 4'd0;
                    hist2 <= 4'd0;
                    hist3 <= 4'd0;
                    hist4 <= 4'd0;
                    hist5 <= 4'd0;
                    stable_fingers <= 4'd0;
                    fist_hold <= FIST_HOLD_FRAMES;
                    if (strong_fist_s2)
                        weak_fist_streak <= 2'd0;
                    else
                        weak_fist_streak <= 2'd2;
                end else begin
                    if (weak_fist_s2)
                        weak_fist_streak <= 2'd1;
                    else
                        weak_fist_streak <= 2'd0;

                    hist5 <= hist4;
                    hist4 <= hist3;
                    hist3 <= hist2;
                    hist2 <= hist1;
                    hist1 <= hist0;
                    hist0 <= candidate_s2;
                    if (fist_hold != 3'd0) begin
                        fist_hold <= fist_hold - 3'd1;
                        stable_fingers <= 4'd0;
                    end else if (stable_fingers == 4'd0) begin
                        // 从无手势状态进入有效手势：简单多数即可，兼顾响应速度。
                        if ((voted_fingers != 4'd0) &&
                            (best_votes >= VOTE_ACQUIRE_MIN))
                            stable_fingers <= voted_fingers;
                    end else if (voted_fingers != stable_fingers) begin
                        // 已稳定后采用更强门限。偶发 0 值不会让 LED 熄灭，
                        // 偶发其他手指数也不会造成来回跳变。
                        if (((voted_fingers == 4'd0) &&
                             (best_votes >= VOTE_RELEASE_MIN)) ||
                            ((voted_fingers != 4'd0) &&
                             (best_votes >= VOTE_SWITCH_MIN)))
                            stable_fingers <= voted_fingers;
                    end
                end
            end
        end
    end

    // 低电平点亮。4 个 LED 无法区分“4 指”和“5 指”，5 指仍显示全亮。
    wire [3:0] led_fingers = hand_valid ? stable_fingers : 4'd0;
    always @(*) begin
        case (led_fingers)
            4'd1: led = 4'b1110;
            4'd2: led = 4'b1100;
            4'd3: led = 4'b1000;
            4'd4: led = 4'b0000;
            4'd5: led = 4'b0000;
            default: led = 4'b1111;
        endcase
    end

    // ================================================================
    // 6. HDMI 视图：默认保留真实增强画面并只显示绿色/黄色手框。
    // 扫描线和 ROI 黑白肤色掩膜都作为可选调试层。
    // ================================================================
    wire show_scan = SHOW_SCAN_LINES && hand_valid && is_finger_scan_y &&
                     (x_cnt >= scan_x_lo) && (x_cnt <= scan_x_hi);

    wire show_box = SHOW_HAND_BOX && hand_valid &&
                    (((x_cnt == hand_x_min || x_cnt == hand_x_max) &&
                      (y_cnt >= hand_y_min && y_cnt <= hand_y_max)) ||
                     ((y_cnt == hand_y_min || y_cnt == hand_y_max) &&
                      (x_cnt >= hand_x_min && x_cnt <= hand_x_max)));

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            out_y  <= 8'd16;
            out_cb <= 8'd128;
            out_cr <= 8'd128;
            out_hs <= 1'b0;
            out_vs <= 1'b0;
            out_de <= 1'b0;
        end else begin
            out_hs <= in_hs;
            out_vs <= in_vs;
            out_de <= in_de;

            if (in_roi) begin
                if (show_scan) begin
                    // 红色
                    out_y  <= 8'd81;
                    out_cb <= 8'd90;
                    out_cr <= 8'd240;
                end else if (show_box) begin
                    if (stable_fingers == 4'd0) begin
                        // 黄色：检测到手/拳头/胳膊，但有效伸指数为 0
                        out_y  <= 8'd210;
                        out_cb <= 8'd16;
                        out_cr <= 8'd146;
                    end else begin
                        // 绿色：检测到有效伸指手势
                        out_y  <= 8'd145;
                        out_cb <= 8'd54;
                        out_cr <= 8'd34;
                    end
                end else if (SHOW_SKIN_MASK && skin_raw) begin
                    // 可选调试：肤色显示为白色。
                    out_y  <= 8'd235;
                    out_cb <= 8'd128;
                    out_cr <= 8'd128;
                end else if (SHOW_SKIN_MASK) begin
                    // 可选调试：非肤色显示为黑色。
                    out_y  <= 8'd16;
                    out_cb <= 8'd128;
                    out_cr <= 8'd128;
                end else begin
                    // 默认显示真实增强画面，只保留手框和扫描线叠加。
                    out_y  <= in_y;
                    out_cb <= in_cb;
                    out_cr <= in_cr;
                end
            end else begin
                out_y  <= in_y;
                out_cb <= in_cb;
                out_cr <= in_cr;
            end
        end
    end

endmodule
