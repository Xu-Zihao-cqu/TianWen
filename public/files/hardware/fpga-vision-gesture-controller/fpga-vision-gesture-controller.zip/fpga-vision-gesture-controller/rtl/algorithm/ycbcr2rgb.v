module ycbcr2rgb (
    input  wire        clk,
    input  wire        rst_n,

    input  wire [7:0]  in_y,
    input  wire [7:0]  in_cb,
    input  wire [7:0]  in_cr,
    input  wire        in_hs,
    input  wire        in_vs,
    input  wire        in_de,

    output reg  [7:0]  out_r,
    output reg  [7:0]  out_g,
    output reg  [7:0]  out_b,
    output reg         out_hs,
    output reg         out_vs,
    output reg         out_de
);

    reg [2:0] sync_hs, sync_vs, sync_de;

    reg signed [19:0] mult_r_d1;
    reg signed [19:0] mult_g_cb_d1;
    reg signed [19:0] mult_g_cr_d1;
    reg signed [19:0] mult_b_d1;
    reg        [7:0]  y_d1;

    reg signed [19:0] add_r_d2;
    reg signed [19:0] add_g_d2;
    reg signed [19:0] add_b_d2;

    function [7:0] clamp_shift8;
        input signed [19:0] value;
        reg signed [19:0] shifted;
        begin
            shifted = value >>> 8;
            if (shifted < 0)
                clamp_shift8 = 8'd0;
            else if (shifted > 20'sd255)
                clamp_shift8 = 8'd255;
            else
                clamp_shift8 = shifted[7:0];
        end
    endfunction

    // Stage 1: chroma products. Coefficients are scaled by 256.
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            y_d1         <= 8'd0;
            mult_r_d1    <= 20'sd0;
            mult_g_cb_d1 <= 20'sd0;
            mult_g_cr_d1 <= 20'sd0;
            mult_b_d1    <= 20'sd0;
        end else begin
            y_d1 <= in_y;
            mult_r_d1    <= ($signed({2'b00, in_cr}) - 10'sd128) * 10'sd359;
            mult_g_cb_d1 <= ($signed({2'b00, in_cb}) - 10'sd128) * 10'sd88;
            mult_g_cr_d1 <= ($signed({2'b00, in_cr}) - 10'sd128) * 10'sd183;
            mult_b_d1    <= ($signed({2'b00, in_cb}) - 10'sd128) * 10'sd454;
        end
    end

    // Stage 2: add luma and a half-LSB rounding term.
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            add_r_d2 <= 20'sd0;
            add_g_d2 <= 20'sd0;
            add_b_d2 <= 20'sd0;
        end else begin
            add_r_d2 <= $signed({4'b0000, y_d1, 8'd0}) + mult_r_d1 + 20'sd128;
            add_g_d2 <= $signed({4'b0000, y_d1, 8'd0}) - mult_g_cb_d1 - mult_g_cr_d1 + 20'sd128;
            add_b_d2 <= $signed({4'b0000, y_d1, 8'd0}) + mult_b_d1 + 20'sd128;
        end
    end

    // Stage 3: arithmetic shift and saturation.
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            out_r  <= 8'd0;
            out_g  <= 8'd0;
            out_b  <= 8'd0;
            out_hs <= 1'b0;
            out_vs <= 1'b0;
            out_de <= 1'b0;
        end else begin
            out_r <= clamp_shift8(add_r_d2);
            out_g <= clamp_shift8(add_g_d2);
            out_b <= clamp_shift8(add_b_d2);
            out_hs <= sync_hs[1];
            out_vs <= sync_vs[1];
            out_de <= sync_de[1];
        end
    end

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            sync_hs <= 3'b000;
            sync_vs <= 3'b000;
            sync_de <= 3'b000;
        end else begin
            sync_hs <= {sync_hs[1:0], in_hs};
            sync_vs <= {sync_vs[1:0], in_vs};
            sync_de <= {sync_de[1:0], in_de};
        end
    end

endmodule
