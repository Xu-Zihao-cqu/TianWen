module rgb2ycbcr (
    input  wire        clk,
    input  wire        rst_n,

    input  wire [7:0]  in_r,
    input  wire [7:0]  in_g,
    input  wire [7:0]  in_b,
    input  wire        in_hs,
    input  wire        in_vs,
    input  wire        in_de,

    output reg  [7:0]  out_y,
    output reg  [7:0]  out_cb,
    output reg  [7:0]  out_cr,
    output reg         out_hs,
    output reg         out_vs,
    output reg         out_de
);

    // Full-range BT.601-style integer approximation:
    // Y  = ( 77R + 150G +  29B + 128) / 256
    // Cb = (-43R -  85G + 128B + 32768 + 128) / 256
    // Cr = (128R - 107G -  21B + 32768 + 128) / 256
    reg [15:0] r_y_d1, g_y_d1, b_y_d1;
    reg [15:0] r_cb_d1, g_cb_d1, b_cb_d1;
    reg [15:0] r_cr_d1, g_cr_d1, b_cr_d1;

    reg signed [18:0] y_sum_d2;
    reg signed [18:0] cb_sum_d2;
    reg signed [18:0] cr_sum_d2;

    reg [2:0] sync_hs, sync_vs, sync_de;

    function [7:0] clamp_shift8;
        input signed [18:0] value;
        reg signed [18:0] shifted;
        begin
            shifted = value >>> 8;
            if (shifted < 0)
                clamp_shift8 = 8'd0;
            else if (shifted > 19'sd255)
                clamp_shift8 = 8'd255;
            else
                clamp_shift8 = shifted[7:0];
        end
    endfunction

    // Stage 1: coefficient products.
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            r_y_d1  <= 16'd0; g_y_d1  <= 16'd0; b_y_d1  <= 16'd0;
            r_cb_d1 <= 16'd0; g_cb_d1 <= 16'd0; b_cb_d1 <= 16'd0;
            r_cr_d1 <= 16'd0; g_cr_d1 <= 16'd0; b_cr_d1 <= 16'd0;
        end else begin
            r_y_d1  <= in_r * 8'd77;
            g_y_d1  <= in_g * 8'd150;
            b_y_d1  <= in_b * 8'd29;
            r_cb_d1 <= in_r * 8'd43;
            g_cb_d1 <= in_g * 8'd85;
            b_cb_d1 <= in_b * 8'd128;
            r_cr_d1 <= in_r * 8'd128;
            g_cr_d1 <= in_g * 8'd107;
            b_cr_d1 <= in_b * 8'd21;
        end
    end

    // Stage 2: signed accumulation with rounding offset.
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            y_sum_d2  <= 19'sd0;
            cb_sum_d2 <= 19'sd0;
            cr_sum_d2 <= 19'sd0;
        end else begin
            y_sum_d2 <= $signed({3'b000, r_y_d1}) +
                        $signed({3'b000, g_y_d1}) +
                        $signed({3'b000, b_y_d1}) + 19'sd128;
            cb_sum_d2 <= 19'sd32896 + $signed({3'b000, b_cb_d1}) -
                         $signed({3'b000, r_cb_d1}) -
                         $signed({3'b000, g_cb_d1});
            cr_sum_d2 <= 19'sd32896 + $signed({3'b000, r_cr_d1}) -
                         $signed({3'b000, g_cr_d1}) -
                         $signed({3'b000, b_cr_d1});
        end
    end

    // Stage 3: arithmetic shift and saturation.
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            out_y  <= 8'd0;
            out_cb <= 8'd128;
            out_cr <= 8'd128;
            out_hs <= 1'b0;
            out_vs <= 1'b0;
            out_de <= 1'b0;
        end else begin
            out_y  <= clamp_shift8(y_sum_d2);
            out_cb <= clamp_shift8(cb_sum_d2);
            out_cr <= clamp_shift8(cr_sum_d2);
            out_hs <= sync_hs[1];
            out_vs <= sync_vs[1];
            out_de <= sync_de[1];
        end
    end

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            sync_hs <= 3'b000;
            sync_vs <= 3'b000;
            sync_de <= 3'b000;
        end else begin
            sync_hs <= {sync_hs[1:0], in_hs};
            sync_vs <= {sync_vs[1:0], in_vs};
            sync_de <= {sync_de[1:0], in_de};
        end
    end

endmodule
