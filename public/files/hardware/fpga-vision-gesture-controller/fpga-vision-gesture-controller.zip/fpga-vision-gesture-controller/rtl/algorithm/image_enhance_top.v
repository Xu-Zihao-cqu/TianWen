module image_enhance_top (
    input  wire        clk,
    input  wire        rst_n,

    input  wire [7:0]  orig_r, orig_g, orig_b,
    input  wire        orig_hs, orig_vs, orig_de,

    output wire [7:0]  proc_r, proc_g, proc_b,
    output wire        proc_hs, proc_vs, proc_de,

    output wire [3:0]  led_out
);

    wire [7:0] y1, cb1, cr1;
    wire hs1, vs1, de1;
    wire [7:0] y2, cb2, cr2;
    wire hs2, vs2, de2;
    wire [7:0] y3, cb3, cr3;
    wire hs3, vs3, de3;
    wire [1:0] auto_mode;
    wire [1:0] tone_strength;

    // 1. RGB -> YCbCr (fixed-point, rounded and pipelined)
    rgb2ycbcr rgb2ycbcr_inst (
        .clk(clk), .rst_n(rst_n),
        .in_r(orig_r), .in_g(orig_g), .in_b(orig_b),
        .in_hs(orig_hs), .in_vs(orig_vs), .in_de(orig_de),
        .out_y(y1), .out_cb(cb1), .out_cr(cr1),
        .out_hs(hs1), .out_vs(vs1), .out_de(de1)
    );

    // 2. Center-weighted exposure statistics with hysteresis.
    image_stats stats_inst (
        .clk(clk), .rst_n(rst_n),
        .y_in(y1), .de_in(de1), .vs_in(vs1),
        .mode(auto_mode), .strength(tone_strength)
    );

    // 3. Gesture recognition runs on the unmodified camera YCbCr stream.
    // This keeps skin thresholds stable when the exposure/tone mode changes.
    gesture_recognizer gesture_inst (
        .clk(clk), .rst_n(rst_n),
        .in_y(y1), .in_cb(cb1), .in_cr(cr1),
        .in_hs(hs1), .in_vs(vs1), .in_de(de1),
        .out_y(y2), .out_cb(cb2), .out_cr(cr2),
        .out_hs(hs2), .out_vs(vs2), .out_de(de2),
        .led(led_out)
    );

    // 4. Adaptive luminance recovery is applied after recognition. The
    // enhanced real image is preserved, while exposure changes can no longer
    // move pixels across the gesture detector's luma thresholds.
    adaptive_tone_mapping adaptive_map_inst (
        .clk(clk), .rst_n(rst_n),
        .mode(auto_mode), .strength(tone_strength),
        .in_y(y2), .in_cb(cb2), .in_cr(cr2),
        .in_hs(hs2), .in_vs(vs2), .in_de(de2),
        .out_y(y3), .out_cb(cb3), .out_cr(cr3),
        .out_hs(hs3), .out_vs(vs3), .out_de(de3)
    );

    // 5. YCbCr -> RGB.
    ycbcr2rgb ycbcr2rgb_inst (
        .clk(clk), .rst_n(rst_n),
        .in_y(y3), .in_cb(cb3), .in_cr(cr3),
        .in_hs(hs3), .in_vs(vs3), .in_de(de3),
        .out_r(proc_r), .out_g(proc_g), .out_b(proc_b),
        .out_hs(proc_hs), .out_vs(proc_vs), .out_de(proc_de)
    );

endmodule
