module adaptive_tone_mapping (
    input  wire        clk,
    input  wire        rst_n,
    input  wire [1:0]  mode,
    input  wire [1:0]  strength,

    input  wire [7:0]  in_y, in_cb, in_cr,
    input  wire        in_hs, in_vs, in_de,

    output reg  [7:0]  out_y, out_cb, out_cr,
    output reg         out_hs, out_vs, out_de
);

    (* ram_init_file = "tone_map_high.mif" *) reg [7:0] high_rom [0:255];
    (* ram_init_file = "tone_map_low.mif"  *) reg [7:0] low_rom  [0:255];

    reg [7:0] y_high_d1, y_low_d1, y_orig_d1;
    reg [7:0] cb_d1, cr_d1;
    reg       hs_d1, vs_d1, de_d1;
    reg [1:0] mode_d1, strength_d1;

    // Blend the original luma with the selected curve using only shifts/adds.
    // strength 00/01/10/11 corresponds to 25/50/75/100 percent correction.
    function [7:0] blend_luma;
        input [7:0] original;
        input [7:0] mapped;
        input [1:0] amount;
        reg signed [9:0] delta;
        reg signed [10:0] mixed;
        begin
            delta = $signed({1'b0, mapped}) - $signed({1'b0, original});
            case (amount)
                2'b00: mixed = $signed({1'b0, original}) + (delta >>> 2);
                2'b01: mixed = $signed({1'b0, original}) + (delta >>> 1);
                2'b10: mixed = $signed({1'b0, original}) +
                               (delta >>> 1) + (delta >>> 2);
                default: mixed = $signed({1'b0, mapped});
            endcase

            if (mixed < 0)
                blend_luma = 8'd0;
            else if (mixed > 11'sd255)
                blend_luma = 8'd255;
            else
                blend_luma = mixed[7:0];
        end
    endfunction

    // Stage 1: synchronous LUT read and control/data alignment.
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            y_high_d1  <= 8'd0;
            y_low_d1   <= 8'd0;
            y_orig_d1  <= 8'd0;
            cb_d1      <= 8'd128;
            cr_d1      <= 8'd128;
            hs_d1      <= 1'b0;
            vs_d1      <= 1'b0;
            de_d1      <= 1'b0;
            mode_d1    <= 2'b00;
            strength_d1 <= 2'b00;
        end else begin
            y_high_d1 <= high_rom[in_y];
            y_low_d1  <= low_rom[in_y];
            y_orig_d1 <= in_y;
            cb_d1     <= in_cb;
            cr_d1     <= in_cr;
            hs_d1     <= in_hs;
            vs_d1     <= in_vs;
            de_d1     <= in_de;
            mode_d1   <= mode;
            strength_d1 <= strength;
        end
    end

    // Stage 2: blend and output. Chroma is intentionally unchanged.
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            out_y  <= 8'd0;
            out_cb <= 8'd128;
            out_cr <= 8'd128;
            out_hs <= 1'b0;
            out_vs <= 1'b0;
            out_de <= 1'b0;
        end else begin
            case (mode_d1)
                2'b01: out_y <= blend_luma(y_orig_d1, y_high_d1, strength_d1);
                2'b10: out_y <= blend_luma(y_orig_d1, y_low_d1, strength_d1);
                default: out_y <= y_orig_d1;
            endcase
            out_cb <= cb_d1;
            out_cr <= cr_d1;
            out_hs <= hs_d1;
            out_vs <= vs_d1;
            out_de <= de_d1;
        end
    end

endmodule
