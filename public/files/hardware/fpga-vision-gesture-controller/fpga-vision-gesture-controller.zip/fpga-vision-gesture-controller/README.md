<div align="center">

# FPGA Vision Gesture Controller

**基于 Verilog RTL 的实时 FPGA 计算机视觉、手势识别与控制参考设计**

[![Repository checks](https://github.com/Xu-Zihao-cqu/fpga-vision-gesture-controller/actions/workflows/ci.yml/badge.svg)](https://github.com/Xu-Zihao-cqu/fpga-vision-gesture-controller/actions/workflows/ci.yml)
![HDL](https://img.shields.io/badge/HDL-Verilog-2f74c0?style=flat-square)
![FPGA](https://img.shields.io/badge/FPGA-Cyclone%20IV%20E-005ca9?style=flat-square)
![Video](https://img.shields.io/badge/Video-720p%20HDMI-0a7f5a?style=flat-square)
![License](https://img.shields.io/badge/License-MIT-yellow?style=flat-square)

[English](README.en.md) · [架构说明](docs/ARCHITECTURE.md) · [算法说明](docs/ALGORITHM.md) · [移植指南](docs/PORTING.md) · [贡献指南](CONTRIBUTING.md)

</div>

![Real-time hand gesture recognition demo](docs/assets/demo-gesture-3.jpg)

## 项目简介

FPGA Vision Gesture Controller 是一套面向嵌入式人机交互的**纯硬件实时视觉控制系统**。工程使用 OV5640 摄像头采集图像，在 FPGA 内完成 RGB/YCbCr 色彩转换、自适应亮度统计、分段色调映射、肤色分割、手部区域提取、手指数识别、拳头抑制和多帧投票，并通过 SDRAM 帧缓存输出 1280 × 720 HDMI 图像及 4 位控制状态。

本项目采用传统计算机视觉与定点 RTL 实现，不依赖嵌入式 CPU、操作系统或神经网络推理框架，适合作为以下方向的参考设计：

- FPGA computer vision / image processing
- Verilog hand gesture recognition
- 实时非接触式开关、模式选择与档位控制
- 智能照明、设备控制和人机交互终端
- OV5640、SDRAM、HDMI/TMDS 综合教学实验
- 资源受限 FPGA 上的轻量级硬件加速算法研究

当前仓库提供 Intel/Altera Cyclone IV E `EP4CE10F17C8` 的参考工程。算法模块与板级接口保持分层，可在重新配置引脚、时钟、存储和视频接口后迁移到其他 FPGA 平台。

## 主要特性

| 能力 | 实现 |
|---|---|
| 实时视频链路 | OV5640 DVP → FPGA 图像处理 → SDRAM → 720p HDMI |
| 纯 RTL 手势识别 | 基于 YCbCr 肤色模型、区域统计和多扫描线段计数 |
| 光照自适应 | 中心测光、暗/亮像素比例、模式滞回和渐进式色调映射 |
| 稳定控制输出 | 7 帧滑动投票，首次获取 4/7，切换与普通释放 5/7 |
| 拳头快速释放 | 完整拳头立即清零，阴影碎裂拳头连续两帧确认 |
| 抗短时漏检 | 手框平滑、快速移动直接跟随、短帧保持机制 |
| 可视化调试 | HDMI OSD、手框、可选扫描线和肤色掩膜 |
| 工程化仓库 | GitHub Actions、静态检查、参考算法测试、发布脚本与文档 |

## 系统架构

主 README 保留一张**通用数据流图**，便于快速理解模块边界；`docs/assets/system-block-diagram.pdf` 中的详细框图包含参考板卡、SDRAM 通道和具体应用映射，更适合作为工程设计附件，而不宜替代主页面中的通用架构图。

```mermaid
flowchart LR
    CAM[OV5640 Camera<br/>8-bit DVP] --> CAP[DVP Capture<br/>RGB565]
    CAP --> RGB[RGB565 → RGB888]

    RGB --> CSC1[RGB → YCbCr]
    CSC1 --> STATS[Exposure Statistics]
    CSC1 --> GEST[Gesture Recognition]
    STATS --> TONE[Adaptive Tone Mapping]
    GEST --> TONE
    TONE --> CSC2[YCbCr → RGB]

    GEST --> VOTE[7-frame Voting<br/>Temporal Hysteresis]
    VOTE --> CTRL[4-bit Control Output]

    CSC2 --> FB[SDRAM Frame Buffer]
    FB --> DISP[720p Timing + OSD]
    CTRL --> DISP
    DISP --> TMDS[TMDS / HDMI]
```

系统划分为三个主要时钟域：摄像头像素时钟域负责采集和视觉算法，SDRAM 控制时钟域负责帧缓存读写，HDMI 像素时钟域负责显示时序和 OSD。帧级手势状态通过两级寄存器同步到显示域，像素数据则通过 SDRAM 完成跨时钟域缓存。

- [详细架构与时钟域说明](docs/ARCHITECTURE.md)
- [参考板级系统框图（PDF）](docs/assets/system-block-diagram.pdf)
- [可编辑系统框图源文件（Visio）](docs/assets/system-block-diagram.vsdx)

<details>
<summary><strong>查看当前参考应用展示</strong></summary>

> 下图展示手势到设备档位的一个参考应用。项目核心本身不限定为照明设备，可映射为继电器、菜单、模式选择、机械执行器或其他控制接口。

![Reference use case](docs/assets/reference-use-case-overview-v3.png)

</details>

## 核心算法

### 1. 定点色彩转换

摄像头输出的 RGB565 先通过位复制扩展为 RGB888，再转换为 YCbCr：

```text
RGB565 → RGB888 → YCbCr
```

- RGB565 使用高位复制补齐低位，较低位补零具有更完整的 8 位动态范围。
- RGB/YCbCr 转换采用定点整数系数、统一舍入和 0–255 饱和钳位。
- 亮度 `Y` 用于曝光统计，`Cb/Cr` 用于肤色判定。

手势识别在色调映射之前运行，因此曝光增强不会反向改变肤色阈值和识别边界。

### 2. 中心测光与自适应色调映射

`image_stats.v` 在画面中心区域进行 1/8 空间抽样，同时统计：

- 亮度累加值与有效样本数；
- 暗像素比例；
- 高亮像素比例。

算法不执行逐帧除法，而是将 `ΣY` 与 `sample_count × threshold` 直接比较。模式切换采用进入/退出双阈值，并要求连续两帧确认，以避免临界光照下反复跳变。

`adaptive_tone_mapping.v` 根据统计结果选择：

| 模式 | 行为 |
|---|---|
| 正常 | Y 通道直通 |
| 高光压缩 | 保留暗部，压缩中高亮度 |
| 低照提升 | 保留黑位与高光，提升中低亮度 |

两张 256 项 MIF LUT 保存基础曲线，并按 25%、50%、75%、100% 强度与原始 Y 通道渐进混合。强度每帧最多变化一级，从而降低整帧亮度突变。

### 3. 亮度约束的肤色分割

手部检测在可配置 ROI 内进行。基础肤色模型使用：

```text
Y 范围 + Cb 范围 + Cr 范围 + (Cr - Cb) 下限
```

在正常亮度下使用较保守的色度范围；仅在阴影和高光小区间启用受限扩展模型，以补偿强反光、手背阴影和局部去饱和，同时避免对整幅画面无条件放宽阈值。

肤色二值流经过水平方向 3 点多数滤波：

```text
skin_filtered = majority(skin[x-2], skin[x-1], skin[x])
```

该滤波可移除孤立噪点并填补单像素空洞，硬件代价仅为少量寄存器和组合逻辑。

### 4. 手部区域提取与手框稳定

算法不保存完整二值帧，而是逐行统计肤色像素数量、水平跨度和连续有效行带：

1. 判断当前行是否具有足够肤色数量和占空比例；
2. 允许少量无效行间隙，连接被阴影分割的区域；
3. 选择一帧中面积最大的连续行带作为手部候选；
4. 使用最小面积、宽高和温和长宽比约束排除噪点及细长手臂区域；
5. 小幅边界变化进行前后帧 1/2 平滑；
6. 变化超过 `BOX_SNAP_DELTA` 时直接跟随，避免快速移动产生明显滞后；
7. 允许 `HAND_MISS_TOL` 帧短时保持，抑制运动模糊和瞬时分割断裂。

这种流式区域提取方式不需要额外完整帧掩膜存储，适合资源受限 FPGA。

### 5. 多扫描线手指数估计

识别器根据稳定手框生成 6 条水平扫描线：

- 上部 5 条扫描线用于手指连续段统计；
- 位于手框约 5/8 高度的第 6 条线作为掌心密度参考。

每条上部扫描线执行游程统计。小于等于 `GAP_TOL` 的黑色间隙被合并，以降低高光和阴影造成的指段碎裂。每条线得到 0–5 个有效连续段后，算法取 5 条线的**第二大值**作为帧级候选：

```text
candidate = second_largest(line_count[0..4])
```

相比普通中位数，第二大值能够在五指下方扫描线已经并入掌心、计数偏低时保留高指数量；相比最大值，又不会让单条噪声线直接决定结果。

### 6. 拳头抑制

拳头与张手的区分同时使用段数、上部肤色密度和掌心参考密度。

**强拳头证据**要求多条上部扫描线接近掌心密度，且第二大段数较低。满足时立即输出 0，确保快速关闭。

**阴影碎裂拳头证据**允许扫描线被分割成多个段，但要求更高的上部/掌心密度相似度，并连续两帧成立后才清零。这样可以抑制拳头阴影误判，同时减少近距离三至五指被错误关闭的风险。

清零后通过 `FIST_HOLD_FRAMES` 短暂保持，避免松拳过渡过程中的碎片区域立即形成假手指。

### 7. 七帧投票与时间滞回

帧级候选不会直接驱动 LED，而是进入 7 帧滑动窗口。窗口统计 0–5 指各自票数，并使用不对称门限：

| 状态变化 | 默认门限 | 目的 |
|---|---:|---|
| 0 → 1–5 指 | 4/7 | 保持较快首次响应 |
| 1–5 指 → 新手势 | 5/7 | 抑制分类边界抖动 |
| 1–5 指 → 普通 0 | 5/7 | 抑制短时漏检导致的熄灭 |
| 票数相同 | 保持当前状态 | 避免平票偏向 0 或较小手指数 |

核心逻辑可概括为：

```text
window ← newest_candidate + previous_6_candidates
winner ← highest_vote_candidate, tie keeps stable_state

if stable_state == 0:
    acquire winner only when votes >= 4
else:
    switch to another gesture only when votes >= 5
    release to ordinary zero only when votes >= 5
```

完整拳头、连续确认的碎裂拳头和超过容忍时间的真正无手仍使用快速清零路径，不受普通投票延迟限制。

详细说明：

- [手势与图像算法说明](docs/ALGORITHM.md)
- [多帧投票算法](docs/MULTI_FRAME_VOTING.md)
- [拳头抑制与现实场景优化](docs/FIST_SUPPRESSION.md)

## 控制输出映射

4 位 LED 为**低电平有效**。当前参考映射如下：

| 稳定结果 | `led[3:0]` | 显示效果 |
|---:|:---:|---|
| 0 / 无手 / 拳头 | `1111` | 全灭 |
| 1 指 | `1110` | 1 个 LED 点亮 |
| 2 指 | `1100` | 2 个 LED 点亮 |
| 3 指 | `1000` | 3 个 LED 点亮 |
| 4 指 | `0000` | 4 个 LED 点亮 |
| 5 指 | `0000` | 4 个 LED 点亮 |

由于当前只有 4 位输出，4 指和 5 指共享全亮编码。迁移到继电器、PWM、DAC、MCU 总线或其他执行器时，可直接替换顶层输出映射，而无需修改视觉识别核心。

## 参考硬件

| 项目 | 当前参考配置 |
|---|---|
| FPGA | Intel/Altera Cyclone IV E `EP4CE10F17C8` |
| 摄像头 | OV5640，8-bit DVP，RGB565 |
| 图像尺寸 | 1280 × 720 |
| 帧缓存 | 16-bit SDRAM |
| 视频输出 | 720p HDMI/TMDS |
| 控制输出 | 4-bit LED，低电平有效 |
| Quartus 工程 | `vision_gesture_controller.qpf` |
| 顶层模块 | `vision_gesture_controller` |

> `vision_gesture_controller.qsf` 中的引脚分配、PLL 和电气标准针对当前参考板。移植到其他硬件前必须重新确认输入时钟、摄像头接口、SDRAM 时序、TMDS 引脚和 I/O 电压。

## 快速开始

### 1. 克隆仓库

```bash
git clone https://github.com/Xu-Zihao-cqu/fpga-vision-gesture-controller.git
cd fpga-vision-gesture-controller
```

### 2. 执行无需 Quartus 的检查

```bash
python3 tests/test_algorithm_reference.py
python3 tests/static_project_check.py
```

也可以统一执行：

```bash
make check
```

### 3. 打开 Quartus 工程

```text
vision_gesture_controller.qpf
```

安装 Quartus 命令行工具后，也可运行：

```bash
quartus_sh --flow compile vision_gesture_controller
```

首次完整编译会生成 `db/`、`incremental_db/` 和 `output_files/`。这些生成目录已由 `.gitignore` 排除，不应提交到 Git 仓库。

### 4. 板级验证

建议按以下顺序检查：

1. PLL 锁定及各时钟频率；
2. OV5640 I²C 初始化和 DVP 数据；
3. SDRAM 写入、读取和跨时钟域稳定性；
4. 720p HDMI/TMDS 输出；
5. 手框、手指数、拳头清零和 LED 映射；
6. 正常、背光、过曝、低照和快速运动场景。

完整发布检查见 [RELEASE_CHECKLIST.md](RELEASE_CHECKLIST.md)。

## 关键参数

主要参数位于 `rtl/algorithm/gesture_recognizer.v`：

```verilog
parameter HAND_MISS_TOL     = 2,
parameter BOX_SNAP_DELTA    = 48,
parameter FIST_HOLD_FRAMES  = 2,
parameter GAP_TOL           = 8,
parameter VOTE_ACQUIRE_MIN  = 4,
parameter VOTE_SWITCH_MIN   = 5,
parameter VOTE_RELEASE_MIN  = 5
```

| 参数 | 作用 | 调整建议 |
|---|---|---|
| `HAND_MISS_TOL` | 短时分割漏检保持帧数 | 闪烁明显可适度增加，离手释放慢则减小 |
| `BOX_SNAP_DELTA` | 手框平滑与快速跟随切换阈值 | 快速移动滞后可减小，静止跳动可增大 |
| `FIST_HOLD_FRAMES` | 拳头清零后的保持帧数 | 松拳假手指明显可增加 |
| `GAP_TOL` | 扫描线允许合并的小黑洞宽度 | 阴影碎裂明显可增加，邻指易粘连则减小 |
| `VOTE_ACQUIRE_MIN` | 首次获取门限 | 默认 4/7，兼顾速度和稳定性 |
| `VOTE_SWITCH_MIN` | 手势切换门限 | 默认 5/7，不建议轻易提高到 6 |
| `VOTE_RELEASE_MIN` | 普通 0 候选释放门限 | 偶发漏检熄灯时保持 5/7 |

显示调试参数：

```verilog
parameter SHOW_SCAN_LINES = 0,
parameter SHOW_HAND_BOX   = 1,
parameter SHOW_SKIN_MASK  = 0
```

## 仓库结构

```text
.
├── rtl/
│   ├── vision_gesture_controller.v   # 顶层集成
│   ├── algorithm/                    # 色彩、曝光、手势与投票算法
│   ├── camera_init/                  # OV5640 与 I²C 初始化
│   ├── sdram/                        # SDRAM 帧缓存控制
│   └── vga/                          # 720p 时序与 HDMI OSD
├── ip/                               # Quartus PLL 生成文件
├── tools/                            # MIF/LUT 生成和离线检查工具
├── tests/                            # 参考算法与工程静态检查
├── docs/                             # 架构、算法、移植和设计资产
├── .github/                          # CI、Release、Issue 与 PR 模板
├── tone_map_high.mif
├── tone_map_low.mif
├── vision_gesture_controller.qpf
└── vision_gesture_controller.qsf
```

## 验证状态

仓库中的自动检查覆盖：

- 两张色调映射 MIF 的长度、地址、端点、单调性和分段锚点；
- RGB565 位复制扩展误差；
- RGB/YCbCr 定点往返量化误差；
- 正常手势、完整拳头和阴影碎裂拳头参考序列；
- 7 帧投票的获取、抗交替误判、切换和普通释放；
- QSF 源文件存在性、模块声明、模块引用和顶层实体一致性；
- 仓库命名、发布文件和 Markdown 本地链接。

这些测试用于验证 RTL 设计意图，**不能替代** Quartus 综合、布局布线、TimeQuest STA、SignalTap 调试和真实板卡测试。

当前公开版本未附带可直接用于任意开发板的 `.sof`。生成二进制前应在目标硬件和真实约束下重新完整编译。

## 已知限制

- 肤色阈值属于传统规则模型，背景颜色、摄像头白平衡和不同光源会影响结果，需要现场标定。
- 当前识别目标为单手、固定 ROI 和 0–5 指数量，不包含手势方向、动态轨迹或多人识别。
- 4 位 LED 无法独立编码 4 指和 5 指。
- 参考 QSF、PLL、SDRAM 参数和摄像头初始化表与当前板卡绑定。
- 传统视觉算法强调低资源和低延迟，不等同于通用深度学习手势识别模型。

## 文档

| 文档 | 内容 |
|---|---|
| [Architecture](docs/ARCHITECTURE.md) | 数据路径、时钟域和模块职责 |
| [Algorithm](docs/ALGORITHM.md) | 图像增强与手势算法优化说明 |
| [Multi-frame Voting](docs/MULTI_FRAME_VOTING.md) | 7 帧投票和时间滞回 |
| [Fist Suppression](docs/FIST_SUPPRESSION.md) | 拳头判定、手框稳定和场景优化 |
| [Porting Guide](docs/PORTING.md) | 更换 FPGA、摄像头和显示接口 |
| [Repository Setup](docs/REPOSITORY_SETUP.md) | GitHub 仓库设置与分支保护 |
| [Release Guide](docs/GITHUB_RELEASE.md) | Tag、自动打包和 GitHub Release |

## 贡献与支持

提交 Issue 或 Pull Request 前请阅读 [CONTRIBUTING.md](CONTRIBUTING.md)。普通使用问题见 [SUPPORT.md](SUPPORT.md)；安全问题请按照 [SECURITY.md](SECURITY.md) 通过 GitHub Private Security Advisory 报告。

## 许可证

原创 RTL、脚本和文档按 [MIT License](LICENSE) 发布。`ip/` 中由 Intel/Altera 工具生成的文件及相关元数据仍受各自许可条款约束，详见 [NOTICE](NOTICE)。

## 引用

研究、课程设计或论文中使用本项目时，可通过仓库中的 [`CITATION.cff`](CITATION.cff) 生成标准引用信息。

---

<div align="center">

**Keywords:** FPGA · Verilog · RTL · computer vision · image processing · hand gesture recognition · OV5640 · SDRAM · HDMI · TMDS · Cyclone IV · Intel Quartus · hardware acceleration · multi-frame voting · embedded systems

</div>