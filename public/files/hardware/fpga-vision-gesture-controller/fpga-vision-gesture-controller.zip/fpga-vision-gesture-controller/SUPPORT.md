# Support

## Questions and integration help

Use GitHub Discussions for architecture, porting, algorithm tuning, and board-integration questions when Discussions is enabled. Use an issue only for reproducible defects or concrete feature proposals.

Before requesting support, include:

- FPGA device and development board;
- Quartus version and operating system;
- camera, SDRAM, and video-output configuration;
- exact commit or release version;
- relevant compiler messages, waveforms, screenshots, or SignalTap captures;
- steps already attempted.

## Scope

Community support is best-effort. The reference design is not certified for medical, life-support, automotive safety, industrial safety, or other regulated use. Production integrators are responsible for verification, timing closure, electrical compliance, security analysis, and regulatory assessment.

Security-sensitive reports must follow [SECURITY.md](SECURITY.md), not a public issue.
