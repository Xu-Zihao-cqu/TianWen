# Changelog

All notable repository changes are documented here. The project follows Semantic Versioning for public releases.

## [1.0.0] - 2026-07-11

### Added
- Public, generic project identity: **FPGA Vision Gesture Controller**.
- Generic Quartus revision and top-level entity: `vision_gesture_controller`.
- Seven-frame temporal voting documentation and regression coverage.
- GitHub Actions checks and automated tag releases, Dependabot, issue templates, pull-request template, security policy, governance, support guidance, citation metadata, release checklist, and bilingual README.
- Architecture, board-porting, and GitHub repository setup documentation.

### Changed
- Moved `gesture_recognizer.v` from the generated `output_files/` directory into `rtl/algorithm/`.
- Normalized documentation and tool paths for a clean source repository.
- Removed editor backups, old compilation artifacts, temporary files, and migration-only notes.

### Compatibility
- Synthesizable behavior is unchanged by the repository rebranding and packaging work.
- The board-specific pin map remains the original EP4CE10F17C8 reference configuration.
