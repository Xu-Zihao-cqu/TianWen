import cv2
import numpy as np
import math
import os

# ----------------------------
# 核心参数
# ----------------------------
THRESHOLD =200
WHITE_POINT = 245
STRENGTH = 2.5

# ----------------------------
# 1. 生成 LUT
# ----------------------------
# 指数 LUT
lut_buggy = np.zeros(256, dtype=np.uint8)
for x in range(256):
    if x <= THRESHOLD:
        lut_buggy[x] = x
    else:
        t = (x - THRESHOLD) / (255 - THRESHOLD)
        y = (1 - math.exp(-STRENGTH * t)) / (1 - math.exp(-STRENGTH))
        value = THRESHOLD + (WHITE_POINT - THRESHOLD) * y
        lut_buggy[x] = np.clip(round(value), 0, 255)

# 有理函数 LUT
lut_correct = np.zeros(256, dtype=np.uint8)
wp_safe = WHITE_POINT if WHITE_POINT < 255 else 254
L = ((255 - THRESHOLD) * (wp_safe - THRESHOLD)) / (255 - wp_safe)

for x in range(256):
    if x <= THRESHOLD:
        lut_correct[x] = x
    else:
        x_prime = x - THRESHOLD
        y_prime = x_prime / (1.0 + (x_prime / L))
        value = THRESHOLD + y_prime
        lut_correct[x] = np.clip(round(value), 0, 255)

# ----------------------------
# 2. 读取与处理
# ----------------------------
img = cv2.imread("./source/test1.png")
if img is None:
    print("错误：找不到文件，请确认路径为 ./source/test1.png")
    exit()

ycrcb = cv2.cvtColor(img, cv2.COLOR_BGR2YCrCb)
Y, Cr, Cb = cv2.split(ycrcb)

result_buggy = cv2.cvtColor(cv2.merge([cv2.LUT(Y, lut_buggy), Cr, Cb]), cv2.COLOR_YCrCb2BGR)
result_correct = cv2.cvtColor(cv2.merge([cv2.LUT(Y, lut_correct), Cr, Cb]), cv2.COLOR_YCrCb2BGR)

# ----------------------------
# 3. 拼接与显示
# ----------------------------
scale_percent = 50
dim = (int(img.shape[1] * scale_percent / 100), int(img.shape[0] * scale_percent / 100))

img_resized = cv2.resize(img, dim, interpolation=cv2.INTER_AREA)
buggy_resized = cv2.resize(result_buggy, dim, interpolation=cv2.INTER_AREA)
correct_resized = cv2.resize(result_correct, dim, interpolation=cv2.INTER_AREA)

for i, title in [(img_resized, 'Original'), (buggy_resized, 'Buggy Exp'), (correct_resized, 'Corrected')]:
    cv2.putText(i, title, (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 255), 2)

comparison_img = np.hstack((img_resized, buggy_resized, correct_resized))

# ----------------------------
# 4. 保存与退出逻辑
# ----------------------------
if not os.path.exists("./result"):
    os.makedirs("./result")

try:
    cv2.imshow("Tone Mapping Comparison", comparison_img)
    print("窗口已显示，请按任意键退出...")
    cv2.waitKey(0)
finally:
    cv2.destroyAllWindows()
    cv2.imwrite("./result/01_错误处理结果.jpg", result_buggy)
    cv2.imwrite("./result/02_正确处理结果.jpg", result_correct)
    cv2.imwrite("./result/03_拼接对比图.jpg", comparison_img)
    print("处理完成！结果已保存在 ./result/ 文件夹下。")