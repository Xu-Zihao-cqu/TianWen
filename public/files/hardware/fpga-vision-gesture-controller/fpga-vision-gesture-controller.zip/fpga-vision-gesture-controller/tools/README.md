# Tools

## Tone-map generation

```bash
python3 tools/generate_tone_maps.py
```

This regenerates the root `tone_map_high.mif` and `tone_map_low.mif` files used by Quartus. `generate_tone_maps_compat.py` is retained as a compatibility entry point.

## Offline comparison

`compare_tone_mapping.py` uses OpenCV and NumPy to compare tone-mapping curves on `tools/source/test1.png`. These optional dependencies are not required for RTL checks or Quartus compilation.

The `result/` images are representative offline outputs and are not part of the FPGA build.
