#!/usr/bin/env python3
# -*- coding:utf-8 -*-

def generate_mif(filename="tone_map.mif"):
    # ==========================================================
    # 核心参数
    # ==========================================================
    THRESHOLD = 200     # 开始压缩的亮度阈值（建议 180~210）
    WHITE_POINT = 245   # 极限最高亮度输出值（必须小于 255，建议 240~250）
    
    # 提前计算平滑系数 L，保证导数连续且不过冲
    # 公式推导自：y = x / (1 + x/L)
    if WHITE_POINT >= 255:
        WHITE_POINT = 254 # 防止分母为0

    L = ((255 - THRESHOLD) * (WHITE_POINT - THRESHOLD)) / (255 - WHITE_POINT)

    def rational_shoulder(x):
        # 如果亮度低于阈值，保持原样（线性直通，无失真）
        if x <= THRESHOLD:
            return x
        
        # 如果高于阈值，使用有理函数进行平滑压缩
        x_prime = x - THRESHOLD
        y_prime = x_prime / (1.0 + (x_prime / L))
        out = THRESHOLD + y_prime
        
        # 钳位保护
        if out > 255:
            out = 255
            
        return int(round(out))

    # ==========================================================
    # 写入 MIF 文件
    # ==========================================================
    with open(filename, "w") as f:
        f.write("WIDTH=8;\n")
        f.write("DEPTH=256;\n\n")
        f.write("ADDRESS_RADIX=UNS;\n")
        f.write("DATA_RADIX=UNS;\n\n")
        f.write("CONTENT BEGIN\n")

        for addr in range(256):
            value = rational_shoulder(addr)
            
            # 严格安全检查：压暗算法输出绝不能大于输入！
            if value > addr:
                print(f"[警告] 算法异常: 输入 {addr}, 输出 {value}")
                
            f.write(f"    {addr:3d} : {value:3d};\n")

        f.write("END;\n")

    print("-----------------------------------------")
    print("MIF 文件生成成功，Bug 已修复！")
    print(f"输出文件  : {filename}")
    print(f"压缩阈值  : {THRESHOLD}")
    print(f"最高输出点: {WHITE_POINT}")
    print("-----------------------------------------")

if __name__ == "__main__":
    generate_mif()