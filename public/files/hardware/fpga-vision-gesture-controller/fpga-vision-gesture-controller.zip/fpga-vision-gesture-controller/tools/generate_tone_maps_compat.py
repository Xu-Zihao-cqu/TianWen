#!/usr/bin/env python3
"""Compatibility entry point for the v2 piecewise tone-map generator."""
from generate_tone_maps import main


if __name__ == "__main__":
    main()
