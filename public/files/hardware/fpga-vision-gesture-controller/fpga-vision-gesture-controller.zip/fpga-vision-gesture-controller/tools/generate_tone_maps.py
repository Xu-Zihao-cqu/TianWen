#!/usr/bin/env python3
"""Regenerate the FPGA tone-map MIF files used by the optimized pipeline.

The v2 curves are piecewise rather than global gamma curves:
- highlight compression keeps shadows (0..96) unchanged;
- low-light lift keeps the black floor (0..8) and highlights (192..255) unchanged.
This reduces the washed-out/dim look seen with full-range gamma correction.
"""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def make_high_curve() -> list[int]:
    values: list[int] = []
    black_anchor = 96
    gamma = 1.18
    span = 255 - black_anchor
    for x in range(256):
        if x <= black_anchor or x == 255:
            y = x
        else:
            u = (x - black_anchor) / span
            y = round(black_anchor + span * (u ** gamma))
        values.append(max(0, min(255, y)))
    return values


def make_low_curve() -> list[int]:
    values: list[int] = []
    black_anchor = 8
    white_anchor = 192
    gamma = 0.82
    span = white_anchor - black_anchor
    for x in range(256):
        if x <= black_anchor or x >= white_anchor:
            y = x
        else:
            u = (x - black_anchor) / span
            y = round(black_anchor + span * (u ** gamma))
        values.append(max(0, min(255, y)))
    return values


def write_mif(path: Path, values: list[int]) -> None:
    lines = [
        "WIDTH=8;", "DEPTH=256;", "ADDRESS_RADIX=UNS;",
        "DATA_RADIX=UNS;", "CONTENT BEGIN",
    ]
    lines.extend(f"    {address} : {value};" for address, value in enumerate(values))
    lines.extend(["END;", ""])
    path.write_text("\n".join(lines), encoding="ascii")


def main() -> None:
    high = make_high_curve()
    low = make_low_curve()
    for base in (ROOT, ROOT / "tools"):
        write_mif(base / "tone_map_high.mif", high)
        write_mif(base / "tone_map_low.mif", low)
    print("Generated piecewise tone_map_high.mif and tone_map_low.mif")


if __name__ == "__main__":
    main()
