# Security Policy

## Supported versions

Security fixes are applied to the latest public release and the default development branch.

## Reporting a vulnerability

Do not open a public issue for a vulnerability. Use GitHub's **Private vulnerability reporting / Security Advisory** feature and include:

- affected revision or release;
- hardware and toolchain configuration;
- reproduction steps;
- impact and attack assumptions;
- any proposed mitigation.

This FPGA reference design is not certified for medical, life-support, automotive safety, or other safety-critical deployment. Integrators must perform their own threat modeling, functional-safety analysis, electrical validation, and regulatory assessment.
