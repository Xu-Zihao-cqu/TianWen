## Summary

Describe the problem and the implementation.

## Change type

- [ ] RTL algorithm
- [ ] Board/constraints
- [ ] Camera or memory interface
- [ ] Tooling/tests
- [ ] Documentation

## Verification

- [ ] `make check` passes
- [ ] Quartus clean compile completed, or not applicable
- [ ] TimeQuest reviewed, or not applicable
- [ ] Board-level test completed, or not applicable

Provide tool versions, hardware configuration, logs, reports, screenshots, or waveforms as appropriate.

## Compatibility and risk

Describe clock-domain, reset, latency, resource, pinout, and backward-compatibility impact.
