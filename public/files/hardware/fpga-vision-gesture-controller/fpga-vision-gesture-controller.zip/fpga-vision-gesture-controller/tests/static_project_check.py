#!/usr/bin/env python3
"""Static consistency checks that do not require a Verilog compiler."""
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
PROJECT_NAME = "vision_gesture_controller"
QSF = ROOT / f"{PROJECT_NAME}.qsf"
FORBIDDEN_NAMES = ("xzh" + "3907_", "xzh" + "_2024", "dental" + "_lamp_ctrl")

errors: list[str] = []

# The legacy namespace must be absent from every path and retained file.
for path in [ROOT, *ROOT.rglob("*")]:
    if any(name in path.name for name in FORBIDDEN_NAMES):
        errors.append(f"Legacy prefix remains in path: {path.relative_to(ROOT)}")
    if path.is_file():
        try:
            data = path.read_bytes()
        except OSError as exc:
            errors.append(f"Cannot read file: {path.relative_to(ROOT)}: {exc}")
            continue
        if any(name.encode("ascii") in data for name in FORBIDDEN_NAMES):
            errors.append(f"Legacy prefix remains in content: {path.relative_to(ROOT)}")

text = QSF.read_text(encoding="utf-8", errors="ignore")
source_paths = re.findall(
    r"set_global_assignment\s+-name\s+VERILOG_FILE\s+([^\s]+)", text
)
if not source_paths:
    errors.append("No Verilog sources found in QSF")

all_modules: dict[str, Path] = {}
source_modules: dict[str, list[str]] = {}


def strip_comments_and_strings(src: str) -> str:
    src = re.sub(r"/\*.*?\*/", "", src, flags=re.S)
    src = re.sub(r"//.*", "", src)
    src = re.sub(r'"(?:\\.|[^"\\])*"', '""', src)
    return src


for rel in source_paths:
    path = ROOT / rel
    if not path.is_file():
        errors.append(f"Missing QSF source: {rel}")
        continue

    raw = path.read_text(encoding="utf-8", errors="ignore")
    clean = strip_comments_and_strings(raw)
    modules = re.findall(r"\bmodule\s+([A-Za-z_][A-Za-z0-9_$]*)", clean)
    source_modules[rel] = modules

    if not modules and "`define" not in clean:
        errors.append(f"No module declaration or configuration macros: {rel}")

    # For normal one-file-per-module sources, the primary module must follow
    # the renamed filename. Files may still contain helper modules afterward.
    if modules and modules[0] != path.stem:
        errors.append(
            f"Primary module/file mismatch: {modules[0]} vs {path.name} ({rel})"
        )

    for module in modules:
        if module in all_modules:
            errors.append(f"Duplicate module {module}: {all_modules[module]} and {rel}")
        all_modules[module] = path

    keyword_pairs = [
        (r"\bmodule\b", r"\bendmodule\b", "module"),
        (r"\bfunction\b", r"\bendfunction\b", "function"),
        (r"\bcase(?:x|z)?\b", r"\bendcase\b", "case"),
        (r"\bbegin\b", r"\bend\b", "begin/end"),
    ]
    for opening, closing, label in keyword_pairs:
        a = len(re.findall(opening, clean))
        b = len(re.findall(closing, clean))
        if a != b:
            errors.append(f"Unbalanced {label} in {rel}: {a} vs {b}")

    for left, right, label in [
        ("(", ")", "parentheses"),
        ("[", "]", "brackets"),
        ("{", "}", "braces"),
    ]:
        if clean.count(left) != clean.count(right):
            errors.append(
                f"Unbalanced {label} in {rel}: "
                f"{clean.count(left)} vs {clean.count(right)}"
            )

# Top-level assignment and project revision must match the renamed project.
top_match = re.search(
    r"set_global_assignment\s+-name\s+TOP_LEVEL_ENTITY\s+(\S+)", text
)
if not top_match:
    errors.append("TOP_LEVEL_ENTITY missing")
else:
    top = top_match.group(1)
    if top not in all_modules:
        errors.append(f"Top-level module not declared: {top}")
    if top != PROJECT_NAME:
        errors.append(f"Unexpected top-level entity: {top}; expected {PROJECT_NAME}")

qpf = (ROOT / f"{PROJECT_NAME}.qpf").read_text(encoding="utf-8", errors="ignore")
revision = re.search(r'PROJECT_REVISION\s*=\s*"([^"]+)"', qpf)
if not revision or revision.group(1) != PROJECT_NAME:
    errors.append(f"PROJECT_REVISION does not match {PROJECT_NAME}")

# Confirm all declared project modules use legal Verilog identifiers and that
# their known instantiations still refer to declared names after the rename.
module_names = sorted(all_modules, key=len, reverse=True)
if module_names:
    known_instantiation = re.compile(
        r"\b(" + "|".join(map(re.escape, module_names)) + r")\b"
        r"\s*(?:#\s*\([^;]*?\)\s*)?[A-Za-z_][A-Za-z0-9_$]*\s*\(",
        flags=re.S,
    )
    for rel in source_paths:
        path = ROOT / rel
        if not path.is_file():
            continue
        clean = strip_comments_and_strings(path.read_text(encoding="utf-8", errors="ignore"))
        for ref in known_instantiation.findall(clean):
            if ref not in all_modules:
                errors.append(f"Instantiated module is not declared: {ref} ({rel})")

# MIF files must contain exactly 256 ordered 8-bit entries.
for name in ("tone_map_high.mif", "tone_map_low.mif"):
    mif_path = ROOT / name
    if not mif_path.is_file():
        errors.append(f"Missing MIF file: {name}")
        continue
    mif = mif_path.read_text(encoding="ascii")
    pairs = [(int(a), int(v)) for a, v in re.findall(r"^\s*(\d+)\s*:\s*(\d+)\s*;", mif, re.M)]
    if len(pairs) != 256 or [a for a, _ in pairs] != list(range(256)):
        errors.append(f"Invalid MIF addressing: {name}")
    if any(v < 0 or v > 255 for _, v in pairs):
        errors.append(f"Out-of-range MIF data: {name}")


# Repository hygiene: generated Quartus results and editor backups are not source.
for forbidden in ("db", "incremental_db", "output_files", "simulation"):
    if (ROOT / forbidden).exists():
        errors.append(f"Generated directory committed: {forbidden}")
for backup in ROOT.rglob("*.bak"):
    errors.append(f"Backup file committed: {backup.relative_to(ROOT)}")

if errors:
    print("Static project check FAILED:")
    for error in errors:
        print(" -", error)
    sys.exit(1)

print(
    f"Static project check passed: {len(source_paths)} QSF Verilog files, "
    f"{len(all_modules)} modules, generic naming and project hygiene verified."
)
