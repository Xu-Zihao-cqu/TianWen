#!/usr/bin/env python3
"""Lightweight reference checks for the optimized fixed-point algorithms.

These tests do not replace Quartus synthesis/timing analysis. They validate LUT
properties and the arithmetic choices made in the synthesizable RTL.
"""
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[1]


def read_mif(name: str) -> list[int]:
    text = (ROOT / name).read_text(encoding="ascii")
    pairs = [(int(a), int(v)) for a, v in re.findall(r"^\s*(\d+)\s*:\s*(\d+)\s*;", text, re.M)]
    assert len(pairs) == 256, (name, len(pairs))
    assert [a for a, _ in pairs] == list(range(256))
    return [v for _, v in pairs]


def rgb_to_ycbcr(r: int, g: int, b: int) -> tuple[int, int, int]:
    clamp = lambda x: max(0, min(255, x))
    y = clamp((77*r + 150*g + 29*b + 128) >> 8)
    cb = clamp((-43*r - 85*g + 128*b + 32768 + 128) >> 8)
    cr = clamp((128*r - 107*g - 21*b + 32768 + 128) >> 8)
    return y, cb, cr


def ycbcr_to_rgb(y: int, cb: int, cr: int) -> tuple[int, int, int]:
    clamp = lambda x: max(0, min(255, x))
    r = clamp((y*256 + (cr-128)*359 + 128) >> 8)
    g = clamp((y*256 - (cb-128)*88 - (cr-128)*183 + 128) >> 8)
    b = clamp((y*256 + (cb-128)*454 + 128) >> 8)
    return r, g, b


def test_tone_maps() -> None:
    high = read_mif("tone_map_high.mif")
    low = read_mif("tone_map_low.mif")
    for curve in (high, low):
        assert curve[0] == 0 and curve[255] == 255
        assert all(a <= b for a, b in zip(curve, curve[1:]))
    assert all(high[x] <= x for x in range(256))
    assert all(low[x] >= x for x in range(256))
    assert high[128] < 128 < low[128]
    # V2 piecewise anchors preserve shadows/black floor and highlights.
    assert high[:97] == list(range(97))
    assert low[:9] == list(range(9))
    assert low[192:] == list(range(192, 256))
    assert high[128] >= 118 and low[128] <= 142


def test_rgb565_replication() -> None:
    for v in range(32):
        replicated = (v << 3) | (v >> 2)
        ideal = round(v * 255 / 31)
        assert abs(replicated - ideal) <= 1
    for v in range(64):
        replicated = (v << 2) | (v >> 4)
        ideal = round(v * 255 / 63)
        assert abs(replicated - ideal) <= 1


def test_color_round_trip() -> None:
    max_error = 0
    total_error = 0
    samples = 0
    for r in range(0, 256, 17):
        for g in range(0, 256, 17):
            for b in range(0, 256, 17):
                rr, gg, bb = ycbcr_to_rgb(*rgb_to_ycbcr(r, g, b))
                errors = (abs(rr-r), abs(gg-g), abs(bb-b))
                max_error = max(max_error, *errors)
                total_error += sum(errors)
                samples += 3
    # Integer coefficients and 8-bit chroma introduce small quantization error.
    assert max_error <= 3, max_error
    assert total_error / samples < 0.9, total_error / samples


def fist_evidence(counts: list[int], skins: list[int], palm_skin: int,
                  width: int) -> tuple[bool, bool]:
    """Return (strong_fist, weak_fragment_fist) for the RTL reference model."""
    assert len(counts) == len(skins) == 5
    dense = [skin * 8 >= width * 3 for skin in skins]
    low_count_dense = [count <= 2 and d for count, d in zip(counts, dense)]
    fragment_dense = [count >= 3 and skin * 2 >= width
                      for count, skin in zip(counts, skins)]
    palm_like = [skin * 4 >= palm_skin * 3 for skin in skins]
    near_palm = [skin * 8 >= palm_skin * 7 for skin in skins]
    palm_dense = palm_skin * 2 >= width
    candidate = sorted(counts)[-2]

    strong = (
        palm_dense
        and candidate <= 2
        and sum(palm_like) >= 3
        and sum(low_count_dense) >= 3
    )
    weak = (
        palm_dense
        and candidate <= 3
        and sum(near_palm) >= 3
        and sum(fragment_dense) >= 2
    )
    return strong, weak


def fragmented_fist_suppressed(weak_sequence: list[bool]) -> list[bool]:
    """Reference the RTL's two-consecutive-frame weak-fist confirmation."""
    streak = False
    suppressed = []
    for weak in weak_sequence:
        confirmed = weak and streak
        suppressed.append(confirmed)
        streak = weak
    return suppressed


def multiframe_vote(candidates: list[int], acquire_min: int = 4,
                    switch_min: int = 5, release_min: int = 5) -> list[int]:
    """Reference the RTL's seven-frame vote with temporal hysteresis."""
    history = [0] * 6
    stable = 0
    outputs: list[int] = []

    for candidate in candidates:
        assert 0 <= candidate <= 5
        window = [candidate, *history]
        votes = [window.count(value) for value in range(6)]

        # Start with the current stable result. Strictly-greater comparisons
        # make ties retain the current LED state.
        voted = stable
        best_votes = votes[stable]
        for value in range(6):
            if value != stable and votes[value] > best_votes:
                best_votes = votes[value]
                voted = value

        history = [candidate, *history[:5]]

        if stable == 0:
            if voted != 0 and best_votes >= acquire_min:
                stable = voted
        elif voted != stable:
            if voted == 0 and best_votes >= release_min:
                stable = 0
            elif voted != 0 and best_votes >= switch_min:
                stable = voted
        outputs.append(stable)

    return outputs


def test_fist_suppression_reference() -> None:
    # Solid fist: strong evidence is immediate.
    strong, weak = fist_evidence(
        [1, 1, 1, 1, 1], [96, 105, 110, 108, 102], 116, 150
    )
    assert strong

    # Shadow-split fist is weak evidence and requires two consecutive frames.
    strong, weak = fist_evidence(
        [3, 4, 3, 2, 3], [100, 101, 105, 100, 99], 112, 150
    )
    assert not strong and weak
    assert fragmented_fist_suppressed([weak]) == [False]
    assert fragmented_fist_suppressed([weak, weak]) == [False, True]
    assert fragmented_fist_suppressed([weak, False, weak]) == [False, False, False]

    # One/two-finger gestures are sparse above a dense palm and must not be suppressed.
    assert fist_evidence([1, 1, 1, 1, 1], [18, 22, 25, 28, 32], 104, 150) == (False, False)
    assert fist_evidence([2, 2, 2, 2, 1], [35, 40, 44, 48, 52], 110, 160) == (False, False)

    # Three/four/five fingers can be dense near the camera. Their upper occupancy
    # must still remain below the stricter 7/8-palm weak-fist threshold or retain
    # a high second-largest segment count.
    assert fist_evidence([3, 3, 3, 3, 2], [70, 76, 82, 88, 92], 116, 160) == (False, False)
    assert fist_evidence([4, 4, 4, 4, 3], [92, 100, 108, 114, 118], 132, 170) == (False, False)
    assert fist_evidence([5, 5, 5, 4, 4], [108, 116, 124, 130, 136], 148, 190) == (False, False)


def test_multiframe_vote_hysteresis() -> None:
    # Four agreeing frames acquire a new gesture from the all-off state.
    assert multiframe_vote([2, 2, 2]) == [0, 0, 0]
    assert multiframe_vote([2, 2, 2, 2])[-1] == 2

    # Alternating one-frame errors never reach the 5/7 switch threshold.
    sequence = [2, 2, 2, 2, 2, 2, 2, 3, 2, 3, 2, 3, 2, 3]
    voted = multiframe_vote(sequence)
    assert voted[3:] == [2] * (len(sequence) - 3)

    # A real gesture transition still switches after five supporting frames.
    sequence = [2] * 7 + [3] * 5
    voted = multiframe_vote(sequence)
    assert voted[-2] == 2 and voted[-1] == 3

    # Up to four ordinary zero candidates are treated as dropouts; five of
    # seven are required to release the stable LED state.
    sequence = [2] * 7 + [0, 0, 0, 0]
    assert multiframe_vote(sequence)[-1] == 2
    sequence.append(0)
    assert multiframe_vote(sequence)[-1] == 0


def skin_pixel(y: int, cb: int, cr: int) -> bool:
    core = 45 <= y <= 235 and 80 <= cb <= 125 and 134 <= cr <= 176 and cr > cb + 14
    shadow = 35 <= y < 45 and 82 <= cb <= 130 and 132 <= cr <= 182 and cr > cb + 10
    highlight = 235 < y <= 245 and 88 <= cb <= 132 and 128 <= cr <= 172 and cr > cb + 6
    return core or shadow or highlight


def test_luminance_gated_skin_extensions() -> None:
    assert skin_pixel(120, 105, 150)
    assert skin_pixel(40, 110, 145)       # shadow extension
    assert skin_pixel(240, 118, 136)      # highlight desaturation extension
    assert not skin_pixel(120, 130, 138)  # relaxed chroma is not enabled at normal luma
    assert not skin_pixel(20, 110, 150)   # very dark noise remains rejected


if __name__ == "__main__":
    test_tone_maps()
    test_rgb565_replication()
    test_color_round_trip()
    test_fist_suppression_reference()
    test_multiframe_vote_hysteresis()
    test_luminance_gated_skin_extensions()
    print("All algorithm reference tests passed.")
