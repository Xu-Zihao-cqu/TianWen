#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
VERSION="$(tr -d '[:space:]' < "$ROOT/VERSION")"
NAME="fpga-vision-gesture-controller-v${VERSION}"
OUT="$ROOT/release"
mkdir -p "$OUT"
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
mkdir -p "$TMP/$NAME"
rsync -a --exclude='.git/' --exclude='release/' --exclude='db/' \
  --exclude='incremental_db/' --exclude='output_files/' --exclude='simulation/' \
  --exclude='__pycache__/' --exclude='.pytest_cache/' --exclude='*.py[cod]' \
  --exclude='*.bak' --exclude='~$*' --exclude='.DS_Store' \
  "$ROOT/" "$TMP/$NAME/"
(cd "$TMP" && zip -qr "$OUT/$NAME.zip" "$NAME")
sha256sum "$OUT/$NAME.zip" > "$OUT/SHA256SUMS"
echo "Created $OUT/$NAME.zip"
