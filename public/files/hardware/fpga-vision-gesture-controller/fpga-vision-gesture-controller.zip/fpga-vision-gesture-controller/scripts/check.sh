#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
python3 tests/test_algorithm_reference.py
python3 tests/static_project_check.py
