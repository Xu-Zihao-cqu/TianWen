# Contributing

Thank you for contributing to FPGA Vision Gesture Controller.

## Development workflow

1. Create a focused branch from the latest default branch.
2. Keep RTL changes small and document clock-domain, reset, latency, and resource implications.
3. Add or update a reference test for algorithm changes whenever practical.
4. Run `make check` before opening a pull request.
5. Do not commit Quartus-generated databases, programming files, editor backups, or local workspace settings.

## RTL requirements

- Preserve synthesizability under Intel Quartus.
- Use explicit widths and reset behavior.
- Document any new clock-domain crossing.
- Avoid changing board pin assignments in the same pull request as algorithm work unless the change is specifically a board-porting contribution.
- Describe expected timing and pipeline latency changes.

## Pull requests

A pull request should state the problem, implementation, verification performed, hardware/tool version used, and any known limitations. Screenshots or SignalTap captures are encouraged for board-level changes.

By contributing, you agree that your contribution may be distributed under the repository license, subject to any third-party notices already present in the relevant files.
