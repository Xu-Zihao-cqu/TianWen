<div align="center">

# FPGA Vision Gesture Controller

**A real-time FPGA computer-vision, hand-gesture recognition, and control reference design in Verilog RTL**

[![Repository checks](https://github.com/Xu-Zihao-cqu/fpga-vision-gesture-controller/actions/workflows/ci.yml/badge.svg)](https://github.com/Xu-Zihao-cqu/fpga-vision-gesture-controller/actions/workflows/ci.yml)
![HDL](https://img.shields.io/badge/HDL-Verilog-2f74c0?style=flat-square)
![FPGA](https://img.shields.io/badge/FPGA-Cyclone%20IV%20E-005ca9?style=flat-square)
![Video](https://img.shields.io/badge/Video-720p%20HDMI-0a7f5a?style=flat-square)
![License](https://img.shields.io/badge/License-MIT-yellow?style=flat-square)

[简体中文](README.md) · [Architecture](docs/ARCHITECTURE.md) · [Algorithm](docs/ALGORITHM.md) · [Porting Guide](docs/PORTING.md) · [Contributing](CONTRIBUTING.md)

</div>

![Real-time hand gesture recognition demo](docs/assets/demo-gesture-3.jpg)

## Overview

FPGA Vision Gesture Controller is a **fully hardware-based, real-time vision control system** for embedded human–machine interaction. It captures video from an OV5640 camera and performs RGB/YCbCr color conversion, adaptive luminance analysis, piecewise tone mapping, skin-color segmentation, hand-region extraction, finger-count estimation, fist suppression, and multi-frame voting directly in FPGA logic. Processed 1280 × 720 video is buffered through SDRAM and displayed over HDMI together with a stable 4-bit control output.

The design uses conventional computer vision and fixed-point RTL. It does not require an embedded CPU, operating system, neural-network accelerator, or software inference framework. It is suitable as a reference platform for:

- FPGA computer vision and image processing
- Verilog hand gesture recognition
- Touchless switching, mode selection, and level control
- Smart lighting, equipment control, and embedded HMI terminals
- OV5640, SDRAM, HDMI/TMDS, and digital-design education
- Lightweight hardware acceleration on resource-constrained FPGAs

The repository includes a reference implementation for the Intel/Altera Cyclone IV E `EP4CE10F17C8`. Algorithm blocks and board-level interfaces are separated so that the design can be ported to other FPGA platforms by updating clocking, pin assignments, memory interfaces, and video output logic.

## Highlights

| Capability | Implementation |
|---|---|
| Real-time video pipeline | OV5640 DVP → FPGA image processing → SDRAM → 720p HDMI |
| Pure-RTL gesture recognition | YCbCr skin model, region statistics, and multi-scanline segment counting |
| Lighting adaptation | Center-weighted metering, dark/bright pixel ratios, mode hysteresis, and gradual tone mapping |
| Stable control output | 7-frame sliding vote: 4/7 acquisition, 5/7 switching, and 5/7 ordinary release |
| Fast fist release | Strong fist evidence clears immediately; fragmented shadow fists require two-frame confirmation |
| Short dropout tolerance | Hand-box smoothing, fast-motion snap tracking, and short-frame hold |
| Visual debugging | HDMI OSD, hand bounding box, optional scanlines, and optional skin mask |
| Repository engineering | GitHub Actions, static checks, reference-model tests, release scripts, and project documentation |

## System Architecture

The main README uses a **generic data-flow diagram** to explain the design at a glance. The detailed board-level diagram under `docs/assets/system-block-diagram.pdf` includes the reference board, SDRAM channels, and application-specific wiring, so it is retained as an engineering document rather than used as the primary overview image.

```mermaid
flowchart LR
    CAM[OV5640 Camera<br/>8-bit DVP] --> CAP[DVP Capture<br/>RGB565]
    CAP --> RGB[RGB565 → RGB888]

    RGB --> CSC1[RGB → YCbCr]
    CSC1 --> STATS[Exposure Statistics]
    CSC1 --> GEST[Gesture Recognition]
    STATS --> TONE[Adaptive Tone Mapping]
    GEST --> TONE
    TONE --> CSC2[YCbCr → RGB]

    GEST --> VOTE[7-frame Voting<br/>Temporal Hysteresis]
    VOTE --> CTRL[4-bit Control Output]

    CSC2 --> FB[SDRAM Frame Buffer]
    FB --> DISP[720p Timing + OSD]
    CTRL --> DISP
    DISP --> TMDS[TMDS / HDMI]
```

The implementation is organized around three main clock domains:

- The camera pixel-clock domain captures video and executes the vision pipeline.
- The SDRAM controller domain performs frame-buffer read and write operations.
- The HDMI pixel-clock domain generates display timing and OSD graphics.

Frame-level gesture state is transferred to the display domain through register synchronization, while pixel data crosses clock domains through the SDRAM frame buffer.

- [Detailed architecture and clock-domain description](docs/ARCHITECTURE.md)
- [Reference board-level system diagram (PDF)](docs/assets/system-block-diagram.pdf)
- [Editable system diagram source (Visio)](docs/assets/system-block-diagram.vsdx)

<details>
<summary><strong>View the current reference application</strong></summary>

> The following image illustrates one possible mapping from hand gestures to device levels. The vision core is application-independent and can instead control relays, menus, operating modes, actuators, or other digital interfaces.

![Reference use case](docs/assets/reference-use-case-overview-v3.png)

</details>

## Core Algorithms

### 1. Fixed-Point Color Conversion

The RGB565 camera stream is expanded to RGB888 by bit replication and then converted to YCbCr:

```text
RGB565 → RGB888 → YCbCr
```

- Bit replication preserves more of the available 8-bit dynamic range than simple zero filling.
- RGB/YCbCr transforms use fixed-point integer coefficients, consistent rounding, and 0–255 saturation.
- Luma `Y` is used for exposure analysis, while `Cb` and `Cr` are used for skin-color classification.

Gesture recognition is evaluated before tone mapping, so display enhancement does not feed back into the segmentation thresholds.

### 2. Center-Weighted Metering and Adaptive Tone Mapping

`image_stats.v` samples the center region at a reduced spatial rate and accumulates:

- Luminance sum and valid sample count
- Dark-pixel ratio
- Highlight-pixel ratio

The RTL avoids frame-level division by comparing `ΣY` directly against `sample_count × threshold`. Entry and exit thresholds are intentionally different, and a new exposure mode must persist for two consecutive frames before being accepted. This temporal hysteresis prevents mode chatter near lighting boundaries.

`adaptive_tone_mapping.v` selects one of three operating modes:

| Mode | Behavior |
|---|---|
| Normal | Pass the Y channel through |
| Highlight compression | Preserve shadows while compressing mid-to-high luminance |
| Low-light enhancement | Preserve black level and highlights while lifting low and mid luminance |

Two 256-entry MIF lookup tables store the base tone curves. The selected curve is blended with the original Y value at 25%, 50%, 75%, or 100% strength. Blend strength changes by no more than one step per frame to avoid abrupt whole-frame brightness changes.

### 3. Luminance-Constrained Skin Segmentation

Hand detection runs inside a configurable region of interest. The base skin model combines:

```text
Y range + Cb range + Cr range + minimum (Cr - Cb)
```

A conservative chrominance range is used under normal lighting. Limited extensions are enabled only in constrained shadow and highlight regions to compensate for specular reflection, hand-back shadows, and local desaturation without globally widening the classifier.

The binary skin stream passes through a horizontal 3-tap majority filter:

```text
skin_filtered = majority(skin[x-2], skin[x-1], skin[x])
```

This removes isolated noise pixels and fills one-pixel holes with only a few registers and simple combinational logic.

### 4. Streaming Hand-Region Extraction and Box Stabilization

The design does not store a full binary mask frame. Instead, it evaluates each row as pixels arrive:

1. Measure the number and horizontal span of skin pixels in the current row.
2. Mark a row valid when skin count and occupancy exceed configurable limits.
3. Allow short invalid-row gaps so that shadow-fragmented regions remain connected.
4. Select the largest valid row band in the frame as the hand candidate.
5. Reject noise and narrow arm-like regions using minimum area, width, height, and relaxed aspect-ratio constraints.
6. Smooth small boundary changes with a 1/2 previous-frame blend.
7. Snap directly to the new box when movement exceeds `BOX_SNAP_DELTA` to avoid lag during fast motion.
8. Retain the last valid box for up to `HAND_MISS_TOL` frames to tolerate motion blur and short segmentation dropouts.

This streaming method avoids an additional full-frame mask buffer and is well suited to resource-constrained FPGA devices.

### 5. Multi-Scanline Finger-Count Estimation

The recognizer derives six horizontal scanlines from the stabilized hand box:

- Five upper scanlines estimate finger segments.
- A sixth scanline near 5/8 of the box height estimates palm density.

Run-length logic counts valid skin segments on each upper scanline. Dark gaps no wider than `GAP_TOL` are merged to reduce fragmentation caused by highlights and shadows. After each upper line produces a segment count from 0 to 5, the frame-level candidate is the **second-largest** of the five values:

```text
candidate = second_largest(line_count[0..4])
```

This choice is more robust than a conventional median when lower scanlines merge into the palm and undercount an open hand. It is also safer than taking the maximum because one noisy scanline cannot determine the result by itself.

### 6. Fist Suppression

A closed fist is distinguished from an open hand using segment count, upper-region skin density, and palm-reference density.

**Strong fist evidence** requires several upper scanlines to have density close to the palm line while the second-largest segment count remains low. This condition clears the gesture immediately for responsive shutoff.

**Fragmented-shadow fist evidence** allows multiple segments caused by shadows, but requires a stronger upper-to-palm density match and two consecutive confirming frames before clearing. This suppresses shadow-induced fist misclassification while reducing false shutdowns for nearby three-to-five-finger poses.

After a fist event, `FIST_HOLD_FRAMES` briefly holds the zero state so that transitional fragments do not immediately become false fingers as the hand opens.

### 7. Seven-Frame Voting with Temporal Hysteresis

The frame-level candidate does not drive the LEDs directly. It enters a 7-frame sliding window that counts votes for candidates 0 through 5. Different thresholds are used for acquisition, switching, and release:

| State transition | Default threshold | Purpose |
|---|---:|---|
| 0 → 1–5 fingers | 4/7 | Responsive initial acquisition |
| 1–5 fingers → another gesture | 5/7 | Reject boundary jitter and isolated misclassification |
| 1–5 fingers → ordinary 0 | 5/7 | Prevent brief segmentation loss from turning the output off |
| Equal vote counts | Keep current state | Avoid bias toward zero or a smaller finger count |

The decision rule can be summarized as:

```text
window ← newest_candidate + previous_6_candidates
winner ← highest_vote_candidate, tie keeps stable_state

if stable_state == 0:
    acquire winner only when votes >= 4
else:
    switch to another gesture only when votes >= 5
    release to ordinary zero only when votes >= 5
```

A confirmed fist and a genuinely missing hand that exceeds the configured tolerance still use fast-clear paths and are not delayed by the ordinary voting threshold.

Further reading:

- [Image and gesture algorithm notes](docs/ALGORITHM.md)
- [Multi-frame voting](docs/MULTI_FRAME_VOTING.md)
- [Fist suppression and real-scene tuning](docs/FIST_SUPPRESSION.md)

## Control Output Mapping

The 4-bit LED output is **active low**.

| Stable result | `led[3:0]` | Visible state |
|---:|:---:|---|
| 0 / no hand / fist | `1111` | All LEDs off |
| 1 finger | `1110` | 1 LED on |
| 2 fingers | `1100` | 2 LEDs on |
| 3 fingers | `1000` | 3 LEDs on |
| 4 fingers | `0000` | 4 LEDs on |
| 5 fingers | `0000` | 4 LEDs on |

Because the current reference platform exposes only four LED bits, four- and five-finger gestures share the all-on code. A different actuator interface—relay, PWM, DAC, MCU bus, or wider GPIO—can replace the top-level output mapping without changing the vision core.

## Reference Hardware

| Item | Reference configuration |
|---|---|
| FPGA | Intel/Altera Cyclone IV E `EP4CE10F17C8` |
| Camera | OV5640, 8-bit DVP, RGB565 |
| Image size | 1280 × 720 |
| Frame buffer | 16-bit SDRAM |
| Video output | 720p HDMI/TMDS |
| Control output | 4-bit active-low LED |
| Quartus project | `vision_gesture_controller.qpf` |
| Top-level module | `vision_gesture_controller` |

> The pin assignments, PLL configuration, and electrical standards in `vision_gesture_controller.qsf` target the current reference board. Before porting the design, verify the input clock, camera interface, SDRAM timing, TMDS pins, and I/O voltage standards for the destination hardware.

## Quick Start

### 1. Clone the Repository

```bash
git clone https://github.com/Xu-Zihao-cqu/fpga-vision-gesture-controller.git
cd fpga-vision-gesture-controller
```

### 2. Run Checks That Do Not Require Quartus

```bash
python3 tests/test_algorithm_reference.py
python3 tests/static_project_check.py
```

Or run the combined target:

```bash
make check
```

### 3. Open the Quartus Project

```text
vision_gesture_controller.qpf
```

With the Quartus command-line tools installed:

```bash
quartus_sh --flow compile vision_gesture_controller
```

A full compilation creates `db/`, `incremental_db/`, and `output_files/`. These generated directories are excluded by `.gitignore` and should not be committed.

### 4. Validate on Hardware

A recommended bring-up sequence is:

1. Verify PLL lock and all clock frequencies.
2. Verify OV5640 I²C initialization and DVP data capture.
3. Verify SDRAM write, read, timing, and clock-domain crossing behavior.
4. Verify 720p HDMI/TMDS output.
5. Verify the hand box, finger count, fist clear, and LED mapping.
6. Test normal light, backlight, overexposure, low light, and fast motion.

See [RELEASE_CHECKLIST.md](RELEASE_CHECKLIST.md) for the complete release checklist.

## Key Parameters

The main tuning parameters are located in `rtl/algorithm/gesture_recognizer.v`:

```verilog
parameter HAND_MISS_TOL     = 2,
parameter BOX_SNAP_DELTA    = 48,
parameter FIST_HOLD_FRAMES  = 2,
parameter GAP_TOL           = 8,
parameter VOTE_ACQUIRE_MIN  = 4,
parameter VOTE_SWITCH_MIN   = 5,
parameter VOTE_RELEASE_MIN  = 5
```

| Parameter | Purpose | Tuning guidance |
|---|---|---|
| `HAND_MISS_TOL` | Frames to hold through a temporary segmentation miss | Increase slightly if the output flickers; decrease if hand-removal release is too slow |
| `BOX_SNAP_DELTA` | Threshold between box smoothing and direct tracking | Decrease if fast motion lags; increase if the box jitters while stationary |
| `FIST_HOLD_FRAMES` | Zero-state hold after fist detection | Increase if false fingers appear while opening the fist |
| `GAP_TOL` | Maximum dark-gap width merged on a scanline | Increase for shadow fragmentation; decrease if adjacent fingers merge |
| `VOTE_ACQUIRE_MIN` | Initial gesture acquisition threshold | Default 4/7 balances response and stability |
| `VOTE_SWITCH_MIN` | Gesture switching threshold | Default 5/7; increasing to 6/7 usually adds noticeable latency |
| `VOTE_RELEASE_MIN` | Ordinary zero-candidate release threshold | Keep at 5/7 when occasional misses otherwise turn the output off |

Display-debug parameters:

```verilog
parameter SHOW_SCAN_LINES = 0,
parameter SHOW_HAND_BOX   = 1,
parameter SHOW_SKIN_MASK  = 0
```

## Repository Layout

```text
.
├── rtl/
│   ├── vision_gesture_controller.v   # Top-level integration
│   ├── algorithm/                    # Color, exposure, gesture, and voting algorithms
│   ├── camera_init/                  # OV5640 and I²C initialization
│   ├── sdram/                        # SDRAM frame-buffer controller
│   └── vga/                          # 720p timing and HDMI OSD
├── ip/                               # Quartus-generated PLL files
├── tools/                            # MIF/LUT generation and offline checks
├── tests/                            # Reference algorithm and project static checks
├── docs/                             # Architecture, algorithm, porting, and design assets
├── .github/                          # CI, release, issue, and pull-request templates
├── tone_map_high.mif
├── tone_map_low.mif
├── vision_gesture_controller.qpf
└── vision_gesture_controller.qsf
```

## Verification Status

The automated repository checks cover:

- Length, address range, endpoints, monotonicity, and piecewise anchors of both tone-mapping MIFs
- RGB565 bit-replication expansion error
- Fixed-point RGB/YCbCr round-trip quantization error
- Reference sequences for normal gestures, strong fists, and fragmented-shadow fists
- Seven-frame voting acquisition, alternating-error rejection, switching, and ordinary release
- QSF source-file existence, module declarations, module references, and top-level entity consistency
- Repository naming, release contents, and local Markdown links

These checks validate the intended RTL behavior, but they **do not replace** Quartus synthesis, fitting, TimeQuest static timing analysis, SignalTap debugging, or hardware testing.

The public release does not include a `.sof` intended for arbitrary development boards. Generate board-specific binaries only after a full compile with verified pin assignments and timing constraints for the target hardware.

## Known Limitations

- The skin classifier is a rule-based model. Background color, camera white balance, and illumination spectrum can affect recognition and may require on-site calibration.
- The current recognizer targets one hand, a fixed ROI, and a 0–5 finger count. It does not classify hand orientation, dynamic trajectories, or multiple users.
- The 4-bit LED interface cannot encode four and five fingers independently.
- The reference QSF, PLL, SDRAM parameters, and camera initialization table are tied to the current hardware platform.
- The traditional-vision approach is optimized for low resource use and low latency; it is not a general-purpose deep-learning gesture-recognition model.

## Documentation

| Document | Description |
|---|---|
| [Architecture](docs/ARCHITECTURE.md) | Data path, clock domains, and module responsibilities |
| [Algorithm](docs/ALGORITHM.md) | Image enhancement and gesture algorithm design notes |
| [Multi-frame Voting](docs/MULTI_FRAME_VOTING.md) | Seven-frame voting and temporal hysteresis |
| [Fist Suppression](docs/FIST_SUPPRESSION.md) | Fist detection, hand-box stabilization, and scene tuning |
| [Porting Guide](docs/PORTING.md) | Porting to another FPGA, camera, or display interface |
| [Repository Setup](docs/REPOSITORY_SETUP.md) | GitHub repository settings and branch protection |
| [Release Guide](docs/GITHUB_RELEASE.md) | Tags, automated packaging, and GitHub Releases |

## Contributing and Support

Read [CONTRIBUTING.md](CONTRIBUTING.md) before opening an issue or pull request. For normal usage questions, see [SUPPORT.md](SUPPORT.md). Security concerns should be reported according to [SECURITY.md](SECURITY.md), preferably through a GitHub Private Security Advisory.

## License

Original RTL, scripts, and documentation are released under the [MIT License](LICENSE). Intel/Altera-generated files and associated metadata under `ip/` remain subject to their respective licensing terms; see [NOTICE](NOTICE).

## Citation

For research, coursework, or publications that use this project, standard citation metadata is available in [`CITATION.cff`](CITATION.cff).

---

<div align="center">

**Keywords:** FPGA · Verilog · RTL · computer vision · image processing · hand gesture recognition · OV5640 · SDRAM · HDMI · TMDS · Cyclone IV · Intel Quartus · hardware acceleration · multi-frame voting · embedded systems

</div>